============= Mod Manager ========== Requires the download of unrealpak program.

Vers.0.5

Rebuilt the entire way the extractor recreates the folder structure. It now uses the unpaked data folder from game to find each json file and then places the file in the correct folder for extraction. This should eliminate any issues with importing json mods that were packed at a folder other than data. Uasset mods are still extracted based off file structure of mod So when creating them the folder structure should contain the data folder in the PAK file.
sample_mod_name\data\BP\Objects\World\Items\Deployables\Extractors\BP_Extractor.uasset

Streamlined the extraction process to help eliminate possible errors from faulty mods.

Extensive testing with as many pak files/mod folders as I could download. 

Researching the possibility of extracting items json at a more line by line instead of item only. This would allow better compatability when they update a part of an item. As it is now extraction is at a per item level. Each json file has rows of items and if any setting in an item is changed then the whole item is extracted. I designed is this way as every json file structure is based on a single row with items listed. Makes an extraction process the same for all files, simplifying the process.

Vers.0.4

Changed the way mods were Extracted to help remove issues. 

Fixed issue with Extracting from a PAK file with no data folder.

Fixed bug I found when importing a mod folder with files that are not part of original game.

Total rewrite of parsing/json text formating. Modded files should be same format as originals.

Fixed issues with dialogs in json.

Added image only support. This will display the image in the mod folder called ImageOnly.png. added some in the mod manager folder for examples.
Paste the ImageOnlyFade over your image in your photo editor to give your image a nice fade in.


Vers.0.3

Fixed import folder bug causing duplicates when importing a mod folder.

Total Revamp of UI to go with Icarus theme.

Vers.0.2

Features: Auto update non uasset mods to current week and adds them to the game. Can merge mutiple mods into 1. 

Setup: 
When you first run it there will be a popup asking you to update settings and it looks for an unpacked data folder from game. So you may get a file not found message. This is normal. Once running select Edit from the main menu at top and click Settings. Here you need to select the Content folder for Icarus. It shows you just above the location it normaly is in. After That you need to select the UnrealPak.exe file that you downloaded from the discord Tools section. Then click save and close settings.*** you now need to exit program and restart it so it can load the settings data!! ***

Once you restart the program it may notify you your data folder is outdated. Click ok and it should unpak the data folder from the game. If it doesnt you can just click Update data folder on the right hand side.

Very important!! DO NOT change the folders that are created with the Mod Manager! It will create a data folder from the games data.pak file and each mod that is added will have a *.EXMod file in the extracted mods folder and a corrisponding folder with the mods name that contains the mods files. 

The User Interface: 
   The list on the left is all the extracted mods that have been added to the mod managed. The list on the lower right is a list of currently installed mods in the games mods folder. Once you click on an extracted mod the Add Mod to Game button will be enabled and a list of all the files the mod uses will be shown as well as the info from the readme.txt file if the mod has one. This helps when checking for compatibility of mods. If they contain the same file they are not compatible but can be merged into one mod using this program. At the bottom of the screen is the log info that explains what is going on.

How it works:
   To add a mod to the manager you click on Extract Mod from Folder. Select your mods folder and click select folder. Then give it a unique name(no spaces!) and click Add/Create. This will use the files in the extracted data folder to compare the files in your mod and extract only the modified items and create a new single file that is added to the mod manager. This file never needs updating. You just need to update the data folder after every game update. Repeat this for each mod you want to add to the manager. To add a mod to game just select the Mod on the left and click the button Add Mod to Game. This will take the extracted mod data and reimport it into the updated data files from the game and then repack it and place in the games mods folder. To remove mods from the games mods folder just click on the Remove All Mods From Game. This just deletes the PAK files in the games mods folder.

Folders used:
   The mod manager copies the folder from any added mod to its own folder. This allows mods that also contain uasset files to still use them when the program Paks the mod. You should also see a folder called data. This is the extracted data folder from the game. It contains all the updated json files from the game. Its important that you update your data folder anytime there is a game update. Just run the program and you should get a notification that there is an update and then select Edit and then Update data folder. All Extracted mods are in the extracted mods folder.

Extracted Mods:
   These are single files that contain all the modified json for the mod. The structure is standard json and lists ModName and then an array of files that have changes and then the items modified as a json array. You could edit these just like the json files in the mod but they will only contain the items that have been originaly moddified when you extracted the mod. All the extracted mods are in the Extracted mods folder.

Create a merged mod from several other mods:
   To add several mods to game make sure the Mods to Install list is clear, if not click the Clear List button. Double click the Extracted mods from the list on the left with the least priority mod you want to add. Continue adding mods from least priority to highest priority. The last mod you add has the highest priority and will be merged last. Once you have all the mods added you want click on the install All Listed Mods button and it will begin to merge each mod back into the updated json files in order from top to bottom. This also copies any UASSET files in the same order and adds them to the mod. Once all mods have been added it creates a Folder called IMM_Merged_Mod and paks this and places it into your games mods folder and your ready to play. This IMM_Merged_Mod folder can also be added to mod manager by clicking the Extract Mod from Folder button and selecting this folder then give it a unique name and add/create it. Now you dont need to merge the mod again as its a mod all on its own.






