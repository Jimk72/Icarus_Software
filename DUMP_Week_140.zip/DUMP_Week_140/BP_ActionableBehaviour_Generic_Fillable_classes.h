// BlueprintGeneratedClass BP_ActionableBehaviour_Generic_Fillable.BP_ActionableBehaviour_Generic_Fillable_C
// Size: 0x328 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Generic_Fillable_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct UCapsuleComponent* HitCollider; // 0x318(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* OwningPlayer; // 0x320(0x08)

	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Generic_Fillable.BP_ActionableBehaviour_Generic_Fillable_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Generic_Fillable.BP_ActionableBehaviour_Generic_Fillable_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Generic_Fillable.BP_ActionableBehaviour_Generic_Fillable_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Generic_Fillable(int32_t EntryPoint); // Function BP_ActionableBehaviour_Generic_Fillable.BP_ActionableBehaviour_Generic_Fillable_C.ExecuteUbergraph_BP_ActionableBehaviour_Generic_Fillable // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

