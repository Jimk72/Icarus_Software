// BlueprintGeneratedClass BP_Animal_Bench.BP_Animal_Bench_C
// Size: 0x9d8 (Inherited: 0x9c0)
struct ABP_Animal_Bench_C : ABP_ProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9c0(0x08)
	struct UStaticMeshComponent* StaticMesh3; // 0x9c8(0x08)
	struct UStaticMeshComponent* StaticMesh2; // 0x9d0(0x08)

	void ReceiveBeginPlay(); // Function BP_Animal_Bench.BP_Animal_Bench_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Animal_Bench(int32_t EntryPoint); // Function BP_Animal_Bench.BP_Animal_Bench_C.ExecuteUbergraph_BP_Animal_Bench // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

