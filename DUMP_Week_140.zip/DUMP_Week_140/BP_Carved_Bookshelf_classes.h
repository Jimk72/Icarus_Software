// BlueprintGeneratedClass BP_Carved_Bookshelf.BP_Carved_Bookshelf_C
// Size: 0x761 (Inherited: 0x761)
struct ABP_Carved_Bookshelf_C : ABP_DeployableBase_C {
};

