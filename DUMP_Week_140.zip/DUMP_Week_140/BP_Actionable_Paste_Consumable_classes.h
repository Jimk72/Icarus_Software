// BlueprintGeneratedClass BP_Actionable_Paste_Consumable.BP_Actionable_Paste_Consumable_C
// Size: 0x380 (Inherited: 0x380)
struct UBP_Actionable_Paste_Consumable_C : UBP_Actionable_Bandage_Consumable_C {
};

