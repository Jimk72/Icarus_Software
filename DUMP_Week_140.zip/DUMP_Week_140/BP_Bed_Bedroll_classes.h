// BlueprintGeneratedClass BP_Bed_Bedroll.BP_Bed_Bedroll_C
// Size: 0x7a8 (Inherited: 0x7a0)
struct ABP_Bed_Bedroll_C : ABP_BedBase_C {
	struct UGFurComponent* GFur; // 0x7a0(0x08)
};

