// BlueprintGeneratedClass BP_CaveWorm_Drop.BP_CaveWorm_Drop_C
// Size: 0x3a8 (Inherited: 0x398)
struct ABP_CaveWorm_Drop_C : ABP_Overflow_Bag_C {
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x398(0x08)
	struct UDecayableComponent* Decayable; // 0x3a0(0x08)
};

