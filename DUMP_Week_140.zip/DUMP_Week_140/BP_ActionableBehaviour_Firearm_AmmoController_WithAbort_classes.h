// BlueprintGeneratedClass BP_ActionableBehaviour_Firearm_AmmoController_WithAbort.BP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C
// Size: 0xe18 (Inherited: 0xe18)
struct UBP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C : UBP_ActionableBehaviour_Firearm_AmmoController_Base_C {

	void CanAbortReload(bool& CanAbort); // Function BP_ActionableBehaviour_Firearm_AmmoController_WithAbort.BP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C.CanAbortReload // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
};

