// BlueprintGeneratedClass BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C
// Size: 0x334 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Shear_Wool_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct USurvivalCharacterState* SurvivalStateRef; // 0x318(0x08)
	struct UFMODEvent* FMODEvent_Eat; // 0x320(0x08)
	struct UFMODEvent* FMODEvent_Drink; // 0x328(0x08)
	float TraceDistance; // 0x330(0x04)

	int32_t CalculateDurabilityDamage(); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.CalculateDurabilityDamage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PlaySwing(struct AIcarusPlayerCharacterSurvival* Target Player); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.PlaySwing // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PlayConsumeSound(struct AIcarusMountCharacter* Mount, struct UFMODEvent* Sound); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.PlayConsumeSound // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void PlaySwingAnimation(struct AIcarusPlayerCharacterSurvival* Player); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.PlaySwingAnimation // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Shear_Wool(int32_t EntryPoint); // Function BP_ActionableBehaviour_Shear_Wool.BP_ActionableBehaviour_Shear_Wool_C.ExecuteUbergraph_BP_ActionableBehaviour_Shear_Wool // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

