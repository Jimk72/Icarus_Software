// BlueprintGeneratedClass BP_Anvil_Bench_T3.BP_Anvil_Bench_T3_C
// Size: 0x9d8 (Inherited: 0x9d8)
struct ABP_Anvil_Bench_T3_C : ABP_ToggleableProcessorBase_C {
};

