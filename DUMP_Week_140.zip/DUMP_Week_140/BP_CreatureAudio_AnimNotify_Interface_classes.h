// BlueprintGeneratedClass BP_CreatureAudio_AnimNotify_Interface.BP_CreatureAudio_AnimNotify_Interface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_CreatureAudio_AnimNotify_Interface_C : UInterface {

	void OnVocalisationAnimNotify(enum class EAIVocalisationType VocalisationType); // Function BP_CreatureAudio_AnimNotify_Interface.BP_CreatureAudio_AnimNotify_Interface_C.OnVocalisationAnimNotify // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnFootstepAnimNotify(enum class ECreatureFootstepType FootstepType, enum class ECreatureFootstepDirection FootstepDirection); // Function BP_CreatureAudio_AnimNotify_Interface.BP_CreatureAudio_AnimNotify_Interface_C.OnFootstepAnimNotify // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

