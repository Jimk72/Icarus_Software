// BlueprintGeneratedClass BP_Boss_Spline_Path.BP_Boss_Spline_Path_C
// Size: 0x240 (Inherited: 0x220)
struct ABP_Boss_Spline_Path_C : AActor {
	struct USplineComponent* Spline; // 0x220(0x08)
	struct TArray<struct FBossSplinePathConnection> PathLinks; // 0x228(0x10)
	struct FName SelfActorTag; // 0x238(0x08)

	void ClearDebug(); // Function BP_Boss_Spline_Path.BP_Boss_Spline_Path_C.ClearDebug // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void DebugConnections(); // Function BP_Boss_Spline_Path.BP_Boss_Spline_Path_C.DebugConnections // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UserConstructionScript(); // Function BP_Boss_Spline_Path.BP_Boss_Spline_Path_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

