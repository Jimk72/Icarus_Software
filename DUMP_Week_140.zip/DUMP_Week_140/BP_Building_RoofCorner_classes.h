// BlueprintGeneratedClass BP_Building_RoofCorner.BP_Building_RoofCorner_C
// Size: 0xbe0 (Inherited: 0xbe0)
struct ABP_Building_RoofCorner_C : ABP_Building_Ramp_C {
};

