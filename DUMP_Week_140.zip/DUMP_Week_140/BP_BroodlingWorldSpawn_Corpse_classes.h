// BlueprintGeneratedClass BP_BroodlingWorldSpawn_Corpse.BP_BroodlingWorldSpawn_Corpse_C
// Size: 0x780 (Inherited: 0x780)
struct ABP_BroodlingWorldSpawn_Corpse_C : ABP_GOAP_Corpse_C {

	void OnSkinnedStateUpdated(); // Function BP_BroodlingWorldSpawn_Corpse.BP_BroodlingWorldSpawn_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

