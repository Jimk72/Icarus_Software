// BlueprintGeneratedClass BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C
// Size: 0x340 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Feed_Mount_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct AIcarusPlayerCharacterSurvival* OwningPlayer; // 0x318(0x08)
	struct USurvivalCharacterState* SurvivalStateRef; // 0x320(0x08)
	int32_t UnitsOfWaterToConsume; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)
	struct UFMODEvent* FMODEvent_Eat; // 0x330(0x08)
	struct UFMODEvent* FMODEvent_Drink; // 0x338(0x08)

	void PlayConsumeSound(struct ACharacter* Character, struct UFMODEvent* Sound); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.PlayConsumeSound // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Owner_PlayEatSound(struct ACharacter* Character); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.Owner_PlayEatSound // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Owner_PlayDrinkSound(struct ACharacter* Character); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.Owner_PlayDrinkSound // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Feed_Mount(int32_t EntryPoint); // Function BP_ActionableBehaviour_Feed_Mount.BP_ActionableBehaviour_Feed_Mount_C.ExecuteUbergraph_BP_ActionableBehaviour_Feed_Mount // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

