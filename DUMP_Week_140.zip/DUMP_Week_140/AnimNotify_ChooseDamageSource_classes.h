// BlueprintGeneratedClass AnimNotify_ChooseDamageSource.AnimNotify_ChooseDamageSource_C
// Size: 0x48 (Inherited: 0x40)
struct UAnimNotify_ChooseDamageSource_C : UAnimNotify_PlayMontageNotify {
	struct FName DamageSourceSocketName; // 0x40(0x08)

	struct FString GetNotifyName(); // Function AnimNotify_ChooseDamageSource.AnimNotify_ChooseDamageSource_C.GetNotifyName // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fcdea0
};

