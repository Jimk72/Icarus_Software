// BlueprintGeneratedClass BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C
// Size: 0x46e (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Fishing_Rod_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	bool ButtonPressed; // 0x318(0x01)
	bool TimerStarted; // 0x319(0x01)
	bool WaterEventFired; // 0x31a(0x01)
	bool LureInWater; // 0x31b(0x01)
	bool CompletedMinigame; // 0x31c(0x01)
	bool IsInspectingFish; // 0x31d(0x01)
	bool IsFiring; // 0x31e(0x01)
	char pad_31F[0x1]; // 0x31f(0x01)
	float MinigameReactionTimer; // 0x320(0x04)
	float ThrowOffset; // 0x324(0x04)
	float DrawPower; // 0x328(0x04)
	float MinFishingTimer; // 0x32c(0x04)
	float MaxFishingTimer; // 0x330(0x04)
	float WaterRaytraceTimer; // 0x334(0x04)
	float GroundRaytraceDistance; // 0x338(0x04)
	float LastFireDrawPower; // 0x33c(0x04)
	struct FRangedWeaponData RangedWeaponData; // 0x340(0xd0)
	struct FTimerHandle MinigameTimer; // 0x410(0x08)
	struct AIcarusPlayerCharacter* OwningPlayer; // 0x418(0x08)
	struct ABP_SkeletalItem_Fishing_Rod_C* Rod; // 0x420(0x08)
	struct UUMG_UserInterface_C* UserInterface; // 0x428(0x08)
	struct FMulticastInlineDelegate InspectionStateChanged; // 0x430(0x10)
	float DefaultDistance; // 0x440(0x04)
	float DistanceIncrement; // 0x444(0x04)
	bool HasSetDefault; // 0x448(0x01)
	bool HasSetupIncrement; // 0x449(0x01)
	char pad_44A[0x2]; // 0x44a(0x02)
	struct FVector TargetLureLocation; // 0x44c(0x0c)
	struct FMulticastInlineDelegate FishAdded; // 0x458(0x10)
	float LureMovementDetectRadius; // 0x468(0x04)
	bool IsFishInGoldenZone; // 0x46c(0x01)
	bool CanCancelInspect; // 0x46d(0x01)

	void Grant Experience(struct FItemData Fish); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Grant Experience // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ShouldPlayReelingAnimation(bool& ShouldPlay); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ShouldPlayReelingAnimation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetStatAdjustedDurability(int32_t DurabilityLoss, int32_t& RodDurabilityLoss, int32_t& LureDurabilityLoss); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.GetStatAdjustedDurability // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetupIncrementDistance(float Current Progress); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.SetupIncrementDistance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetupFishMovement(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.SetupFishMovement // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CheckMovementValidity(bool& IsValid); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.CheckMovementValidity // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FishMovement(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.FishMovement // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ResetIfLureIsTooClose(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ResetIfLureIsTooClose // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReelLogic(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ReelLogic // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnFishLost(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.OnFishLost // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnFishCaught(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.OnFishCaught // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FishingMinigameLogic(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.FishingMinigameLogic // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FishingTimerEnd(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.FishingTimerEnd // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FishingTimerStart(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.FishingTimerStart // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void IsFullyCasted(bool& FullyCasted); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.IsFullyCasted // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetFishingRod(struct ABP_SkeletalItem_Fishing_Rod_C*& BP Skeletal Item Fishing Rod); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.GetFishingRod // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void Completed Reaction(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Completed Reaction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ResetIfLureIsTooFar(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ResetIfLureIsTooFar // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ResetIfLureOnRod(bool& IsLureOffRod); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ResetIfLureOnRod // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ToggleCatchFishUI(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ToggleCatchFishUI // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void IsLureInWater(bool& InWater); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.IsLureInWater // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void LocalOrServer(bool& Local, bool& Server); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.LocalOrServer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetCurrentDrawPercentage(float& Percentage); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.GetCurrentDrawPercentage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void DoThrow(float Power); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.DoThrow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Setup // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Server_Reel(bool Reel); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_Reel // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Server_QuickReel(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_QuickReel // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Reel(bool Reel); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Reel // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_GrantFish(struct AIcarusPlayerCharacterSurvival* Fisher); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_GrantFish // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Reset Timer(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Reset Timer // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CheckForWater(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.CheckForWater // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Multicast_PostThrow(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Multicast_PostThrow // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_RequestThrow(float Power); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_RequestThrow // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FishToInventory(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.FishToInventory // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Multicast_InspectFish(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Multicast_InspectFish // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ResetMinigame(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ResetMinigame // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ResetOnLureDistance(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ResetOnLureDistance // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_SetLureProgress(float CurrentProgress, bool IsInGoldenZone); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_SetLureProgress // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnActionAborted(enum class EActionableEventType EventType); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.OnActionAborted // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void SetUpdateProgress(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.SetUpdateProgress // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Server_ResetTargetLocation(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_ResetTargetLocation // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_DeliverFish(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Server_DeliverFish // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Multicast_FinishInspect(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.Multicast_FinishInspect // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void EndInspectingMontage(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.EndInspectingMontage // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Fishing_Rod(int32_t EntryPoint); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.ExecuteUbergraph_BP_ActionableBehaviour_Fishing_Rod // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
	void FishAdded__DelegateSignature(); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.FishAdded__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void InspectionStateChanged__DelegateSignature(bool IsInspecting); // Function BP_ActionableBehaviour_Fishing_Rod.BP_ActionableBehaviour_Fishing_Rod_C.InspectionStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

