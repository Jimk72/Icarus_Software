// BlueprintGeneratedClass BP_Animal_Trap_Medium.BP_Animal_Trap_Medium_C
// Size: 0x7c8 (Inherited: 0x7c8)
struct ABP_Animal_Trap_Medium_C : ABP_Animal_Trap_Base_C {
};

