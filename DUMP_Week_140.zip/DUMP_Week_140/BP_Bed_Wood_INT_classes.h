// BlueprintGeneratedClass BP_Bed_Wood_INT.BP_Bed_Wood_INT_C
// Size: 0x7a8 (Inherited: 0x7a0)
struct ABP_Bed_Wood_INT_C : ABP_BedBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7a0(0x08)

	void ReceiveBeginPlay(); // Function BP_Bed_Wood_INT.BP_Bed_Wood_INT_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Bed_Wood_INT(int32_t EntryPoint); // Function BP_Bed_Wood_INT.BP_Bed_Wood_INT_C.ExecuteUbergraph_BP_Bed_Wood_INT // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

