// BlueprintGeneratedClass BP_Breakable_Clay_Var2.BP_Breakable_Clay_Var2_C
// Size: 0x440 (Inherited: 0x400)
struct ABP_Breakable_Clay_Var2_C : ABP_Breakable_Rock_Base_C {
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_01; // 0x400(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_08; // 0x408(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_07; // 0x410(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_06; // 0x418(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_05; // 0x420(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_04; // 0x428(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_03; // 0x430(0x08)
	struct UStaticMeshComponent* SM_Breakable_Clay_Var2_02; // 0x438(0x08)
};

