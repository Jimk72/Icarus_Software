// BlueprintGeneratedClass BP_Deep_Mining_Ice_Borer.BP_Deep_Mining_Ice_Borer_C
// Size: 0x7f0 (Inherited: 0x7e0)
struct ABP_Deep_Mining_Ice_Borer_C : ABP_Drill_Base_C {
	struct UNiagaraComponent* NS_BiofuelBurn; // 0x7e0(0x08)
	struct UNiagaraComponent* NS_DeepDrilling; // 0x7e8(0x08)

	void ActiveStateUpdated(); // Function BP_Deep_Mining_Ice_Borer.BP_Deep_Mining_Ice_Borer_C.ActiveStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

