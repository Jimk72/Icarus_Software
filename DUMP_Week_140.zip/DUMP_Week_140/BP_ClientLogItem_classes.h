// BlueprintGeneratedClass BP_ClientLogItem.BP_ClientLogItem_C
// Size: 0x58 (Inherited: 0x28)
struct UBP_ClientLogItem_C : UObject {
	struct FIcarusLogEntry LogEntry; // 0x28(0x30)
};

