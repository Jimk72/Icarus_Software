// BlueprintGeneratedClass BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C
// Size: 0x160 (Inherited: 0x110)
struct UBP_AISpawnBehaviour_TrappedCreatures_C : UAISpawnBehaviour {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x110(0x08)
	struct FVector SpawnLocation; // 0x118(0x0c)
	bool UseFallbackSpawnPoint; // 0x124(0x01)
	bool DebugIgnoreZoneCheck; // 0x125(0x01)
	char pad_126[0x2]; // 0x126(0x02)
	struct UEnvQuery* SpawnEQS; // 0x128(0x08)
	struct AActor* SuccessfullySpawnedAI; // 0x130(0x08)
	struct FVector SpawnScale; // 0x138(0x0c)
	float CleanupLifespan; // 0x144(0x04)
	struct AAIController* DummyAIQuerier; // 0x148(0x08)
	bool YumYum; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct UObject* ChosenTrap; // 0x158(0x08)

	bool GetNextAIToSpawn(struct FAISetupEnum& AISetup, struct TSoftClassPtr<UObject>& ActorClass); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.GetNextAIToSpawn // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	bool IsLocationWithinAffectedTerrainZone(struct UObject* WorldContextObject, struct FVector WorldLocation); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.IsLocationWithinAffectedTerrainZone // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool TrySpawnAI(struct UObject* WorldContextObject); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.TrySpawnAI // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void TrySpawnAsync(struct AActor* AroundTrap); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.TrySpawnAsync // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.QueryFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CleanupAI(struct AActor* AI); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.CleanupAI // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void DoSpawn(struct UObject* Context, struct FVector SpawnLocation); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.DoSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_AISpawnBehaviour_TrappedCreatures(int32_t EntryPoint); // Function BP_AISpawnBehaviour_TrappedCreatures.BP_AISpawnBehaviour_TrappedCreatures_C.ExecuteUbergraph_BP_AISpawnBehaviour_TrappedCreatures // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

