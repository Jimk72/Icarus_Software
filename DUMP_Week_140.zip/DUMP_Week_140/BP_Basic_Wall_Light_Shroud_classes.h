// BlueprintGeneratedClass BP_Basic_Wall_Light_Shroud.BP_Basic_Wall_Light_Shroud_C
// Size: 0x820 (Inherited: 0x80c)
struct ABP_Basic_Wall_Light_Shroud_C : ABP_Light_Electric_Base_C {
	char pad_80C[0x4]; // 0x80c(0x04)
	struct UBP_IcarusSpotLight_C* BP_IcarusSpotLight1; // 0x810(0x08)
	struct UPointLightComponent* PointLight1; // 0x818(0x08)
};

