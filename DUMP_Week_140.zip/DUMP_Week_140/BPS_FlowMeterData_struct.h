// UserDefinedStruct BPS_FlowMeterData.BPS_FlowMeterData
// Size: 0x14 (Inherited: 0x00)
struct FBPS_FlowMeterData {
	enum class EIcarusResourceType NetworkType_13_B1F3E32349B8231855C52F831CF6DA2F; // 0x00(0x01)
	bool ValidNetwork_1_B22F06814CD2759B2FB3C085ED146FD7; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t Supply_4_3911CC804B4ED7AF856AB3B180E4C646; // 0x04(0x04)
	int32_t Demand_6_7E258CC846BE9D3C07781AAB6D715A40; // 0x08(0x04)
	int32_t CurrentStored_8_B1AA8E544AFCF03539CBF9AAD305767D; // 0x0c(0x04)
	int32_t MaxStorage_10_F05AC00D44B761846C63509ED56D677C; // 0x10(0x04)
};

