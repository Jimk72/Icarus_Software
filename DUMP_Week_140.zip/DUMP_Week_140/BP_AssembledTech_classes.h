// BlueprintGeneratedClass BP_AssembledTech.BP_AssembledTech_C
// Size: 0x5a0 (Inherited: 0x580)
struct ABP_AssembledTech_C : AStaticItem {
	struct UBoxComponent* Box; // 0x580(0x08)
	struct UStaticMeshComponent* StaticMesh3; // 0x588(0x08)
	struct UStaticMeshComponent* StaticMesh2; // 0x590(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x598(0x08)
};

