// BlueprintGeneratedClass BPI_Bowl.BPI_Bowl_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_Bowl_C : UInterface {

	void SetBowlColorIndex(int32_t ColorIndex); // Function BPI_Bowl.BPI_Bowl_C.SetBowlColorIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

