// BlueprintGeneratedClass BP_Advanced_Aquarium.BP_Advanced_Aquarium_C
// Size: 0x850 (Inherited: 0x850)
struct ABP_Advanced_Aquarium_C : ABP_Aquarium_C {
};

