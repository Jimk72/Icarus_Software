// BlueprintGeneratedClass BP_CollectionShipBeacon.BP_CollectionShipBeacon_C
// Size: 0x780 (Inherited: 0x761)
struct ABP_CollectionShipBeacon_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UCameraComponent* Camera; // 0x770(0x08)
	struct UStaticMeshComponent* Cube; // 0x778(0x08)

	void DoLaunchCollectionShip(); // Function BP_CollectionShipBeacon.BP_CollectionShipBeacon_C.DoLaunchCollectionShip // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_CollectionShipBeacon.BP_CollectionShipBeacon_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ServerLaunchCollectionShip(); // Function BP_CollectionShipBeacon.BP_CollectionShipBeacon_C.ServerLaunchCollectionShip // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_CollectionShipBeacon(int32_t EntryPoint); // Function BP_CollectionShipBeacon.BP_CollectionShipBeacon_C.ExecuteUbergraph_BP_CollectionShipBeacon // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

