// AnimBlueprintGeneratedClass 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C
// Size: 0x1184 (Inherited: 0x2c0)
struct U3RD_MAL_MountedAnimBP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2; // 0x2c8(0x118)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x3e0(0x158)
	struct FAnimNode_Root AnimGraphNode_Root_3; // 0x538(0x30)
	struct FAnimNode_ControlRig AnimGraphNode_ControlRig_2; // 0x568(0x368)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x8d0(0x80)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // 0x950(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_2; // 0xa68(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0xa98(0x80)
	struct FAnimNode_ControlRig AnimGraphNode_ControlRig; // 0xb18(0x368)
	struct FAnimNode_Root AnimGraphNode_Root; // 0xe80(0x30)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer_2; // 0xeb0(0xb0)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer; // 0xf60(0xb0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x1010(0xc0)
	struct FVector __CustomProperty_RelativeFeetOffset_F17B49B14661E62C569CBAA56F4B29C5; // 0x10d0(0x0c)
	float __CustomProperty_VerletStrength_6654F16B430AA80A67797180F44F704C; // 0x10dc(0x04)
	struct FVector __CustomProperty_LookAtDirection_6654F16B430AA80A67797180F44F704C; // 0x10e0(0x0c)
	bool __CustomProperty_DoLookAt_6654F16B430AA80A67797180F44F704C; // 0x10ec(0x01)
	char pad_10ED[0x3]; // 0x10ed(0x03)
	struct FVector __CustomProperty_HandSpaceTargetLocation_6654F16B430AA80A67797180F44F704C; // 0x10f0(0x0c)
	struct FVector __CustomProperty_RelativeHandsOffset_6654F16B430AA80A67797180F44F704C; // 0x10fc(0x0c)
	float __CustomProperty_SpineCurlAmount_6654F16B430AA80A67797180F44F704C; // 0x1108(0x04)
	float MountSpeed; // 0x110c(0x04)
	float AnimDelta; // 0x1110(0x04)
	struct FRotator LookRot; // 0x1114(0x0c)
	float AimPitch; // 0x1120(0x04)
	float AimYaw; // 0x1124(0x04)
	struct ACharacter* MountCharacterRef; // 0x1128(0x08)
	struct FVector LookAtLocation; // 0x1130(0x0c)
	float SmoothDirection; // 0x113c(0x04)
	struct FRotator LastRotation; // 0x1140(0x0c)
	float TurnRate; // 0x114c(0x04)
	struct FVector RelativeFeetOffset; // 0x1150(0x0c)
	struct FVector RelativeHandsOffset; // 0x115c(0x0c)
	struct FVector HandsTargetLocation; // 0x1168(0x0c)
	struct FVector LookAtDirection; // 0x1174(0x0c)
	float VerletStrength; // 0x1180(0x04)

	void VehicleLowerBody(struct FPoseLink LowerInPose, struct FPoseLink& VehicleLowerBody); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.VehicleLowerBody // (HasOutParms|BlueprintCallable) // @ game+0x1fcdea0
	void VehicleUpperBody(struct FPoseLink UpperInPose, struct FPoseLink& VehicleUpperBody); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.VehicleUpperBody // (HasOutParms|BlueprintCallable) // @ game+0x1fcdea0
	void AnimGraph(struct FPoseLink& AnimGraph); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateTurnRate(); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.UpdateTurnRate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_3RD_MAL_MountedAnimBP_AnimGraphNode_ControlRig_6654F16B430AA80A67797180F44F704C(); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_3RD_MAL_MountedAnimBP_AnimGraphNode_ControlRig_6654F16B430AA80A67797180F44F704C // (BlueprintEvent) // @ game+0x1fcdea0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_3RD_MAL_MountedAnimBP(int32_t EntryPoint); // Function 3RD_MAL_MountedAnimBP.3RD_MAL_MountedAnimBP_C.ExecuteUbergraph_3RD_MAL_MountedAnimBP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

