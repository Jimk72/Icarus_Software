// BlueprintGeneratedClass BP_Carved_WardrobeNarrow_A.BP_Carved_WardrobeNarrow_A_C
// Size: 0x77a (Inherited: 0x77a)
struct ABP_Carved_WardrobeNarrow_A_C : ABP_DeployableContainerBase_C {
};

