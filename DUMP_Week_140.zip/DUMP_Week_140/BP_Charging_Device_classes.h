// BlueprintGeneratedClass BP_Charging_Device.BP_Charging_Device_C
// Size: 0xa68 (Inherited: 0x771)
struct ABP_Charging_Device_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_771[0x7]; // 0x771(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x778(0x08)
	struct UStaticMeshComponent* Proxy_CaveSpotLight; // 0x780(0x08)
	struct UStaticMeshComponent* Proxy_CaveLight; // 0x788(0x08)
	struct USkeletalMeshComponent* Proxy_Battery_Latern; // 0x790(0x08)
	struct USkeletalMeshComponent* Proxy_Lava_Hunter_Backpack; // 0x798(0x08)
	struct USkeletalMeshComponent* Proxy_Icebox_Backpack; // 0x7a0(0x08)
	struct USkeletalMeshComponent* Proxy_Battery; // 0x7a8(0x08)
	struct USkeletalMeshComponent* Proxy_Torch; // 0x7b0(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_13; // 0x7b8(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_12; // 0x7c0(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_11; // 0x7c8(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_09; // 0x7d0(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_08; // 0x7d8(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_07; // 0x7e0(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_06; // 0x7e8(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_05; // 0x7f0(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_04; // 0x7f8(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_03; // 0x800(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_02; // 0x808(0x08)
	struct UStaticMeshComponent* SM_DEP_Powered_Charger_Light_01; // 0x810(0x08)
	struct USceneComponent* Lights; // 0x818(0x08)
	struct UFMODAudioComponent* ChargingAudio; // 0x820(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x828(0x08)
	struct UCameraComponent* Camera; // 0x830(0x08)
	float EnergyPerSecond; // 0x838(0x04)
	float DividedFlowRate; // 0x83c(0x04)
	bool Is Recharging; // 0x840(0x01)
	char pad_841[0x7]; // 0x841(0x07)
	struct FItemData RechargingItem; // 0x848(0x1f0)
	struct FItemsStaticRowHandle CachedItemStatic; // 0xa38(0x18)
	struct USceneComponent* Array Element; // 0xa50(0x08)
	struct TArray<struct UStaticMeshComponent*> LightMeshes; // 0xa58(0x10)

	void UpdateLightStatus(); // Function BP_Charging_Device.BP_Charging_Device_C.UpdateLightStatus // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_RechargingItem(); // Function BP_Charging_Device.BP_Charging_Device_C.OnRep_RechargingItem // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_Is Recharging(); // Function BP_Charging_Device.BP_Charging_Device_C.OnRep_Is Recharging // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Set Filling Effects(bool bIsRechargingItems); // Function BP_Charging_Device.BP_Charging_Device_C.Set Filling Effects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ActorsRequiringEnergy(int32_t& NumActors); // Function BP_Charging_Device.BP_Charging_Device_C.ActorsRequiringEnergy // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Charging_Device.BP_Charging_Device_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ShouldEnergyFlow(struct UInventory* Inventory, int32_t Location); // Function BP_Charging_Device.BP_Charging_Device_C.ShouldEnergyFlow // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ShouldEnergyFlowDelayed(); // Function BP_Charging_Device.BP_Charging_Device_C.ShouldEnergyFlowDelayed // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void RechargeObject(); // Function BP_Charging_Device.BP_Charging_Device_C.RechargeObject // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void IcarusBeginPlay(); // Function BP_Charging_Device.BP_Charging_Device_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_Charging_Device.BP_Charging_Device_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void OnItemChanged(struct UInventory* Inventory, int32_t Location); // Function BP_Charging_Device.BP_Charging_Device_C.OnItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Charging_Device(int32_t EntryPoint); // Function BP_Charging_Device.BP_Charging_Device_C.ExecuteUbergraph_BP_Charging_Device // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

