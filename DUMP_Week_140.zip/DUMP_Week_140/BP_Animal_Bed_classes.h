// BlueprintGeneratedClass BP_Animal_Bed.BP_Animal_Bed_C
// Size: 0x778 (Inherited: 0x761)
struct ABP_Animal_Bed_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UGFurComponent* GFur; // 0x770(0x08)

	void IcarusBeginPlay(); // Function BP_Animal_Bed.BP_Animal_Bed_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Animal_Bed(int32_t EntryPoint); // Function BP_Animal_Bed.BP_Animal_Bed_C.ExecuteUbergraph_BP_Animal_Bed // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

