// BlueprintGeneratedClass BPQ_Common_Launch.BPQ_Common_Launch_C
// Size: 0x3a0 (Inherited: 0x390)
struct ABPQ_Common_Launch_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x398(0x08)

	bool Check(); // Function BPQ_Common_Launch.BPQ_Common_Launch_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Setup(bool bFirstTime); // Function BPQ_Common_Launch.BPQ_Common_Launch_C.Setup // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Launch(struct AIcarusRocket* Dropship); // Function BPQ_Common_Launch.BPQ_Common_Launch_C.Launch // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BPQ_Common_Launch(int32_t EntryPoint); // Function BPQ_Common_Launch.BPQ_Common_Launch_C.ExecuteUbergraph_BPQ_Common_Launch // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

