// BlueprintGeneratedClass BP_Carved_Lamp.BP_Carved_Lamp_C
// Size: 0x820 (Inherited: 0x80c)
struct ABP_Carved_Lamp_C : ABP_Light_Electric_Base_C {
	char pad_80C[0x4]; // 0x80c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x810(0x08)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x818(0x08)

	void ReceiveBeginPlay(); // Function BP_Carved_Lamp.BP_Carved_Lamp_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Carved_Lamp(int32_t EntryPoint); // Function BP_Carved_Lamp.BP_Carved_Lamp_C.ExecuteUbergraph_BP_Carved_Lamp // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

