// BlueprintGeneratedClass BP_Composter_Electric.BP_Composter_Electric_C
// Size: 0x9f0 (Inherited: 0x9e4)
struct ABP_Composter_Electric_C : ABP_ResourceNetworkProcessor_C {
	char pad_9E4[0x4]; // 0x9e4(0x04)
	struct UNiagaraComponent* Niagara; // 0x9e8(0x08)
};

