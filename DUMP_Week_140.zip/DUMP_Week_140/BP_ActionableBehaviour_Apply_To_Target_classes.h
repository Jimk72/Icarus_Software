// BlueprintGeneratedClass BP_ActionableBehaviour_Apply_To_Target.BP_ActionableBehaviour_Apply_To_Target_C
// Size: 0x380 (Inherited: 0x368)
struct UBP_ActionableBehaviour_Apply_To_Target_C : UBP_ActionableBehaviour_Hold_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x368(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* Owning_Player; // 0x370(0x08)
	struct AIcarusCharacter* TargetCharacter; // 0x378(0x08)

	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Apply_To_Target.BP_ActionableBehaviour_Apply_To_Target_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Apply_To_Target.BP_ActionableBehaviour_Apply_To_Target_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void CompleteHold(bool Success); // Function BP_ActionableBehaviour_Apply_To_Target.BP_ActionableBehaviour_Apply_To_Target_C.CompleteHold // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_Apply_To_Target.BP_ActionableBehaviour_Apply_To_Target_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Apply_To_Target(int32_t EntryPoint); // Function BP_ActionableBehaviour_Apply_To_Target.BP_ActionableBehaviour_Apply_To_Target_C.ExecuteUbergraph_BP_ActionableBehaviour_Apply_To_Target // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

