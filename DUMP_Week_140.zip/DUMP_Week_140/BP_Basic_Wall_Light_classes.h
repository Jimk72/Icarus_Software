// BlueprintGeneratedClass BP_Basic_Wall_Light.BP_Basic_Wall_Light_C
// Size: 0x828 (Inherited: 0x80c)
struct ABP_Basic_Wall_Light_C : ABP_Light_Electric_Base_C {
	char pad_80C[0x4]; // 0x80c(0x04)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x810(0x08)
	struct UPointLightComponent* PointLight_Bot; // 0x818(0x08)
	struct UPointLightComponent* PointLight_Top; // 0x820(0x08)
};

