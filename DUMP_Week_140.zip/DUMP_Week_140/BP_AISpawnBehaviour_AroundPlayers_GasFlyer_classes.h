// BlueprintGeneratedClass BP_AISpawnBehaviour_AroundPlayers_GasFlyer.BP_AISpawnBehaviour_AroundPlayers_GasFlyer_C
// Size: 0x150 (Inherited: 0x148)
struct UBP_AISpawnBehaviour_AroundPlayers_GasFlyer_C : UBP_AISpawnBehaviour_AroundPlayers_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x148(0x08)

	void GetAdditionalFlyerSpawnLocation(struct FVector Around, struct FVector& OutLocation, bool& Success); // Function BP_AISpawnBehaviour_AroundPlayers_GasFlyer.BP_AISpawnBehaviour_AroundPlayers_GasFlyer_C.GetAdditionalFlyerSpawnLocation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void TrySpawnAsync(struct AActor* AroundPlayer); // Function BP_AISpawnBehaviour_AroundPlayers_GasFlyer.BP_AISpawnBehaviour_AroundPlayers_GasFlyer_C.TrySpawnAsync // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void DoSpawn(struct UObject* Context, struct FVector SpawnLocation); // Function BP_AISpawnBehaviour_AroundPlayers_GasFlyer.BP_AISpawnBehaviour_AroundPlayers_GasFlyer_C.DoSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BP_AISpawnBehaviour_AroundPlayers_GasFlyer.BP_AISpawnBehaviour_AroundPlayers_GasFlyer_C.QueryFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_AISpawnBehaviour_AroundPlayers_GasFlyer(int32_t EntryPoint); // Function BP_AISpawnBehaviour_AroundPlayers_GasFlyer.BP_AISpawnBehaviour_AroundPlayers_GasFlyer_C.ExecuteUbergraph_BP_AISpawnBehaviour_AroundPlayers_GasFlyer // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

