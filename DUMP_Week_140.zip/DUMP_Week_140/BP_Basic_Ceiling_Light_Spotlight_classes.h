// BlueprintGeneratedClass BP_Basic_Ceiling_Light_Spotlight.BP_Basic_Ceiling_Light_Spotlight_C
// Size: 0x820 (Inherited: 0x80c)
struct ABP_Basic_Ceiling_Light_Spotlight_C : ABP_Light_Electric_Base_C {
	char pad_80C[0x4]; // 0x80c(0x04)
	struct UPointLightComponent* PointLight1; // 0x810(0x08)
	struct UBP_IcarusSpotLight_C* BP_IcarusSpotLight1; // 0x818(0x08)
};

