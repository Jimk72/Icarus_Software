// BlueprintGeneratedClass BP_CookingStation.BP_CookingStation_C
// Size: 0x9e0 (Inherited: 0x9c0)
struct ABP_CookingStation_C : ABP_ProcessorBase_C {
	struct UStaticMeshComponent* SM_DEP_Bench_Cooking_Proxy_Wood1; // 0x9c0(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Cooking_Proxy_Meat3; // 0x9c8(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Cooking_Proxy_Meat2; // 0x9d0(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Cooking_Proxy_Meat1; // 0x9d8(0x08)

	void UserConstructionScript(); // Function BP_CookingStation.BP_CookingStation_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

