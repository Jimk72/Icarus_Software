// BlueprintGeneratedClass BP_Animal_Trap_Small.BP_Animal_Trap_Small_C
// Size: 0x7d0 (Inherited: 0x7c8)
struct ABP_Animal_Trap_Small_C : ABP_Animal_Trap_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7c8(0x08)

	void ReceiveBeginPlay(); // Function BP_Animal_Trap_Small.BP_Animal_Trap_Small_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Animal_Trap_Small(int32_t EntryPoint); // Function BP_Animal_Trap_Small.BP_Animal_Trap_Small_C.ExecuteUbergraph_BP_Animal_Trap_Small // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

