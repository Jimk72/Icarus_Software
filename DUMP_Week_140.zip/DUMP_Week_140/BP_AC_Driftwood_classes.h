// BlueprintGeneratedClass BP_AC_Driftwood.BP_AC_Driftwood_C
// Size: 0x3d8 (Inherited: 0x3cc)
struct ABP_AC_Driftwood_C : ABP_ResourceNodeBase_C {
	char pad_3CC[0x4]; // 0x3cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)

	void ReceiveBeginPlay(); // Function BP_AC_Driftwood.BP_AC_Driftwood_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_AC_Driftwood(int32_t EntryPoint); // Function BP_AC_Driftwood.BP_AC_Driftwood_C.ExecuteUbergraph_BP_AC_Driftwood // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

