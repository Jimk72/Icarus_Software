// BlueprintGeneratedClass BPC_Recipe_Proxy.BPC_Recipe_Proxy_C
// Size: 0x111 (Inherited: 0xb0)
struct UBPC_Recipe_Proxy_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct TMap<struct USceneComponent*, struct FTagQueriesRowHandle> RecipeSetup; // 0xb8(0x50)
	struct USceneComponent* DefaultProxy; // 0x108(0x08)
	bool bDeviceActive; // 0x110(0x01)

	void Set Proxy Visibility(struct USceneComponent* InComponent, bool Visibility); // Function BPC_Recipe_Proxy.BPC_Recipe_Proxy_C.Set Proxy Visibility // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Setup(struct TMap<struct USceneComponent*, struct FTagQueriesRowHandle> RecipeSetup, struct USceneComponent* DefaultProxy); // Function BPC_Recipe_Proxy.BPC_Recipe_Proxy_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateProxies(); // Function BPC_Recipe_Proxy.BPC_Recipe_Proxy_C.UpdateProxies // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Processor Updated(struct FProcessingItem Item); // Function BPC_Recipe_Proxy.BPC_Recipe_Proxy_C.Processor Updated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ProcessorStateUpdated(bool bIsActive); // Function BPC_Recipe_Proxy.BPC_Recipe_Proxy_C.ProcessorStateUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BPC_Recipe_Proxy(int32_t EntryPoint); // Function BPC_Recipe_Proxy.BPC_Recipe_Proxy_C.ExecuteUbergraph_BPC_Recipe_Proxy // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

