// BlueprintGeneratedClass BioLabInventoryListItemData.BioLabInventoryListItemData_C
// Size: 0x218 (Inherited: 0x28)
struct UBioLabInventoryListItemData_C : UObject {
	struct FItemData ItemData; // 0x28(0x1f0)
};

