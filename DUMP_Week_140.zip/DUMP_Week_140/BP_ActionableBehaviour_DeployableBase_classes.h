// BlueprintGeneratedClass BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C
// Size: 0xc62 (Inherited: 0x480)
struct UBP_ActionableBehaviour_DeployableBase_C : UBP_ActionableBehaviour_SimplePlaceWithVariants_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct ABP_DeployablePreview_C* PreviewActor; // 0x488(0x08)
	bool CurrentPlacementValid; // 0x490(0x01)
	char pad_491[0x7]; // 0x491(0x07)
	struct FDeployableData DeployableData; // 0x498(0xa8)
	struct UDeployableComponent* DeployableComponent; // 0x540(0x08)
	char pad_548[0x8]; // 0x548(0x08)
	struct FTransform CachedPreviewTransform; // 0x550(0x30)
	float UpwardsFacingLimit; // 0x580(0x04)
	bool IsRotating; // 0x584(0x01)
	char pad_585[0xb]; // 0x585(0x0b)
	struct FTransform PlayerPlacementTransform; // 0x590(0x30)
	struct FRotator DesiredLocalDeployableRotation; // 0x5c0(0x0c)
	char pad_5CC[0x4]; // 0x5cc(0x04)
	struct FTransform DeployablePlacementTransform; // 0x5d0(0x30)
	struct AActor* FoundationActor; // 0x600(0x08)
	bool SnapRotationToBuildingGrid; // 0x608(0x01)
	char pad_609[0x3]; // 0x609(0x03)
	float AngleSnapAmount; // 0x60c(0x04)
	struct AActor* ClassToSnapTo; // 0x610(0x08)
	bool ActorSnapValid; // 0x618(0x01)
	char pad_619[0x7]; // 0x619(0x07)
	struct AActor* SnapActor; // 0x620(0x08)
	struct FItemData ItemData; // 0x628(0x1f0)
	struct FName SnapSocket; // 0x818(0x08)
	bool DebugDeployment; // 0x820(0x01)
	char pad_821[0x7]; // 0x821(0x07)
	struct FItemData SpawnedItem; // 0x828(0x1f0)
	struct FHitResult LastDeployAttemptTrace; // 0xa18(0x88)
	struct UFMODEvent* FMODEvent_DeployFail; // 0xaa0(0x08)
	bool TriedToShowRadialMenu; // 0xaa8(0x01)
	char pad_AA9[0x3]; // 0xaa9(0x03)
	int32_t SelectedVariantIndex; // 0xaac(0x04)
	struct FDeployableSetup DeployableSetup; // 0xab0(0x198)
	bool SnapOverridePressed; // 0xc48(0x01)
	char pad_C49[0x7]; // 0xc49(0x07)
	struct TArray<struct TSoftClassPtr<UObject>> BlacklistedFoundationClasses; // 0xc50(0x10)
	bool IsPreviewActorSheltered; // 0xc60(0x01)
	bool IsPreviewActorOutsidePlaceOnly; // 0xc61(0x01)

	void CustomDeploymentCheck(struct AActor* HitActor, bool& ValidPlacement, struct FText& Reason); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.CustomDeploymentCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BlueprintDeploy(struct FTransform DeployTransform, struct AActor* FoundationActor, struct FItemData ItemData, int32_t VarientIndex); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.BlueprintDeploy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void HandleInvalidPlacementText(bool InvalidPlacement, struct FText InvalidReason); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.HandleInvalidPlacementText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_SelectedVariantIndex(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnRep_SelectedVariantIndex // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateReplicatedShelter(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.UpdateReplicatedShelter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetOwnerRotation(struct FRotator& OutRotation); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetOwnerRotation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	void IsHitActorBlacklisted(struct AActor* HitActor, bool& IsBlacklisted); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.IsHitActorBlacklisted // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateDeployableSetup(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.UpdateDeployableSetup // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetContextMenuItems(struct TArray<struct FContextMenuItemData>& MenuItems); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetContextMenuItems // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PlayDeployFailSound(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.PlayDeployFailSound // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetPreviewMeshPlacement(struct FVector AttemptedPlacePosition, struct FVector PlacePositionNormal, struct AActor* HitFloorActor, struct FTransform& OutPreviewTransform, struct FName& OutSnapSocket, struct AActor*& OutSnapActor, bool& OutActorSnapValid); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetPreviewMeshPlacement // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void TryDeploy(struct FHitResult InHit); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.TryDeploy // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ShouldActionCameraTrace(enum class EActionableEventType ActionableType, enum class EActionableTrigger ActionableTrigger, bool& ShouldTrace); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.ShouldActionCameraTrace // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool GetPreviewActorOverlappingComponents(struct TArray<struct UPrimitiveComponent*>& OutComponents); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetPreviewActorOverlappingComponents // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void DEBUG_DisplayDeploymentFailureMessage(struct FString Message, float Duration); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.DEBUG_DisplayDeploymentFailureMessage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FindValidSocketOnActors(struct TArray<struct AActor*>& Actors, struct FVector TraceLocation, struct TArray<struct FName>& SocketsAndTags, bool& Found, struct FTransform& SocketTransform, struct AActor*& SnapActor, struct FName& SnapSocket); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.FindValidSocketOnActors // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetFoundationActorDepth(struct AActor* Foundation, int32_t& ActorDepth); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetFoundationActorDepth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PlayDeployedSound(struct ADeployable* Deployable); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.PlayDeployedSound // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetPreviewStaticMeshAsset(int32_t PreviewVariantIndex, struct TSoftObjectPtr<UStaticMesh>& StaticMeshAsset); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetPreviewStaticMeshAsset // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool IsDestroyed(struct AActor* Actor); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.IsDestroyed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool DoTrace(struct FHitResult& OutHit); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.DoTrace // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	struct TArray<enum class EObjectTypeQuery> GetObjectTraceChannels(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetObjectTraceChannels // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	void GetTraceIgnoreActors(struct TArray<struct AActor*>& OutIgnoreActors); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetTraceIgnoreActors // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	bool PerformLineTrace(struct FVector TraceStart, struct FVector TraceEnd, bool TraceComplex, struct TArray<struct AActor*>& IgnoreActors, struct FHitResult& OutHit); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.PerformLineTrace // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FindClosestSocketPointOnActor(struct AActor* InActor, struct TArray<struct FName>& SocketsAndTags, struct FVector Origin, struct UActorComponent*& OutComponent, struct FTransform& OutTransform, struct FName& OutSocket, bool& FoundPoint); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.FindClosestSocketPointOnActor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateMeshVisibility(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.UpdateMeshVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetTraceDistance(float& TraceDistance); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.GetTraceDistance // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateMeshPreview(struct FHitResult Hit, bool DidHit); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.UpdateMeshPreview // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnDeploy(struct ADeployable* SpawnedDeployable); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnDeploy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CheckValidPlacement(struct FHitResult InHit, bool& IsValidPlacement, struct FText& InvalidReason); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.CheckValidPlacement // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Update Preview Material(bool ValidPlacement); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.Update Preview Material // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnLoaded_F2A5421C4D141CEB2D751992D50E6C36(struct UObject* Loaded); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnLoaded_F2A5421C4D141CEB2D751992D50E6C36 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnLoaded_CEA16C5D424F96B896AF2BB339E5C750(struct UObject* Loaded); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnLoaded_CEA16C5D424F96B896AF2BB339E5C750 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnLoaded_948E897349D7ED52413C2997A58E4378(struct UObject* Loaded); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnLoaded_948E897349D7ED52413C2997A58E4378 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void TickCameraTraceHit(struct FHitResult Hit, bool DidHit); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.TickCameraTraceHit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnActionCameraTraceHit(struct FHitResult Hit); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnActionCameraTraceHit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Server_ValidateAndDeploy(struct FHitResult InHit, struct FTransform DeployTransform, struct AActor* FoundationActor, struct FItemData ItemData, int32_t VariantIndex); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.Server_ValidateAndDeploy // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_BeginRotationMode(struct FHitResult Hit, struct FTransform Transform, struct FRotator PlayerRotation); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.Server_BeginRotationMode // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Multi_BeginRotationMode(struct FTransform DeployableTransform, struct FRotator RelativeRotation, struct FTransform PlayerTransform, struct AActor* FoundationActor); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.Multi_BeginRotationMode // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void InvalidPlacementText(bool ValidPlacement, struct FText InvalidReason); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.InvalidPlacementText // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnContextMenuSegmentHighlightChanged(struct UUMG_ContextMenu_Radial_Item_C* Segment); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OnContextMenuSegmentHighlightChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OpenRadialMenu(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.OpenRadialMenu // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void MenuItemSelected(struct FName ItemIdentifier, int32_t ItemPayload); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.MenuItemSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ChangePreviewItem(int32_t VariantIndex); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.ChangePreviewItem // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SpawnPreviewMesh(int32_t PreviewVariantIndex); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.SpawnPreviewMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PreloadDeployables(); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.PreloadDeployables // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_NotifyVariantChanged(int32_t SelectedVariantIndex); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.Server_NotifyVariantChanged // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateRotationState(bool IsRotating); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.UpdateRotationState // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_UpdateRotationState(bool IsRotating); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.Server_UpdateRotationState // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_DeployableBase(int32_t EntryPoint); // Function BP_ActionableBehaviour_DeployableBase.BP_ActionableBehaviour_DeployableBase_C.ExecuteUbergraph_BP_ActionableBehaviour_DeployableBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

