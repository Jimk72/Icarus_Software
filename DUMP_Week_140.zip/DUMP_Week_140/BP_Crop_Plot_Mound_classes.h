// BlueprintGeneratedClass BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C
// Size: 0x890 (Inherited: 0x871)
struct ABP_Crop_Plot_Mound_C : ABP_Crop_Plot_Base_C {
	char pad_871[0x7]; // 0x871(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x878(0x08)
	struct UFarmableComponent* Farmable; // 0x880(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x888(0x08)

	void SetSoilState(bool bWet); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.SetSoilState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void HarvestResource(struct AActor* HarvestingActor, struct UStaticMeshComponent*& StaticMeshComponent, bool bUsingSickle, struct UInventory* NonPlayerInventoryX, bool& Harvested); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.HarvestResource // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void IcarusBeginPlay(); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Check(); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.Check // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Crop_Plot_Mound(int32_t EntryPoint); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.ExecuteUbergraph_BP_Crop_Plot_Mound // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

