// BlueprintGeneratedClass BP_Advanced_Kitchen_Bench.BP_Advanced_Kitchen_Bench_C
// Size: 0x9e4 (Inherited: 0x9e4)
struct ABP_Advanced_Kitchen_Bench_C : ABP_ResourceNetworkProcessor_C {

	void UserConstructionScript(); // Function BP_Advanced_Kitchen_Bench.BP_Advanced_Kitchen_Bench_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

