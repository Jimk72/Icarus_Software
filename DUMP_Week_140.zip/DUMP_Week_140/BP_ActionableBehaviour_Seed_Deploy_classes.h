// BlueprintGeneratedClass BP_ActionableBehaviour_Seed_Deploy.BP_ActionableBehaviour_Seed_Deploy_C
// Size: 0xc62 (Inherited: 0xc62)
struct UBP_ActionableBehaviour_Seed_Deploy_C : UBP_ActionableBehaviour_DeployableBase_C {

	void CustomDeploymentCheck(struct AActor* HitActor, bool& ValidPlacement, struct FText& Reason); // Function BP_ActionableBehaviour_Seed_Deploy.BP_ActionableBehaviour_Seed_Deploy_C.CustomDeploymentCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BlueprintDeploy(struct FTransform DeployTransform, struct AActor* FoundationActor, struct FItemData ItemData, int32_t VarientIndex); // Function BP_ActionableBehaviour_Seed_Deploy.BP_ActionableBehaviour_Seed_Deploy_C.BlueprintDeploy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

