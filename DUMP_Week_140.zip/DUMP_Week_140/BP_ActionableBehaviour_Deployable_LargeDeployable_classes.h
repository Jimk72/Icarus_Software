// BlueprintGeneratedClass BP_ActionableBehaviour_Deployable_LargeDeployable.BP_ActionableBehaviour_Deployable_LargeDeployable_C
// Size: 0xc62 (Inherited: 0xc62)
struct UBP_ActionableBehaviour_Deployable_LargeDeployable_C : UBP_ActionableBehaviour_DeployableBase_C {

	void OnDeploy(struct ADeployable* SpawnedDeployable); // Function BP_ActionableBehaviour_Deployable_LargeDeployable.BP_ActionableBehaviour_Deployable_LargeDeployable_C.OnDeploy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

