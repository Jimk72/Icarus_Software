// BlueprintGeneratedClass BP_Actionable_Shovel.BP_Actionable_Shovel_C
// Size: 0x451 (Inherited: 0x3a0)
struct UBP_Actionable_Shovel_C : UBP_ActionableBehaviour_Generic_Melee_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	float SnowClearThresholdDegrees; // 0x3a8(0x04)
	char pad_3AC[0x4]; // 0x3ac(0x04)
	struct TSet<struct UPhysicalMaterial*> DigHolePhysMaterials; // 0x3b0(0x50)
	struct TMap<struct UPhysicalMaterial*, struct FItemRewardsRowHandle> CollectResourceMap; // 0x400(0x50)
	bool bCorrectTrigger; // 0x450(0x01)

	void GetResourceRewardRow(struct UPhysicalMaterial*& GroundMaterial, bool& Found, struct FItemRewardsRowHandle& RewardRow); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.GetResourceRewardRow // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CollectResource(struct FItemRewardsRowHandle RowHandle); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.CollectResource // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnActionHitEvent(struct AActor* Invoking Actor, struct UPrimitiveComponent* OverlappedComponent , struct FHitResult& SweepResult); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.OnActionHitEvent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Actionable_Shovel(int32_t EntryPoint); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.ExecuteUbergraph_BP_Actionable_Shovel // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

