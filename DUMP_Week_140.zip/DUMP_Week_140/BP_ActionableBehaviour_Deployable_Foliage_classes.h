// BlueprintGeneratedClass BP_ActionableBehaviour_Deployable_Foliage.BP_ActionableBehaviour_Deployable_Foliage_C
// Size: 0xc70 (Inherited: 0xc62)
struct UBP_ActionableBehaviour_Deployable_Foliage_C : UBP_ActionableBehaviour_DeployableBase_C {
	char pad_C62[0x6]; // 0xc62(0x06)
	struct UFLODRecord* PlacementRecord; // 0xc68(0x08)

	void OnDeploy(struct ADeployable* SpawnedDeployable); // Function BP_ActionableBehaviour_Deployable_Foliage.BP_ActionableBehaviour_Deployable_Foliage_C.OnDeploy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CheckValidPlacement(struct FHitResult InHit, bool& IsValidPlacement, struct FText& InvalidReason); // Function BP_ActionableBehaviour_Deployable_Foliage.BP_ActionableBehaviour_Deployable_Foliage_C.CheckValidPlacement // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetPreviewStaticMeshAsset(int32_t PreviewVariantIndex, struct TSoftObjectPtr<UStaticMesh>& StaticMeshAsset); // Function BP_ActionableBehaviour_Deployable_Foliage.BP_ActionableBehaviour_Deployable_Foliage_C.GetPreviewStaticMeshAsset // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

