// BlueprintGeneratedClass BP_CrosshairInterface.BP_CrosshairInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_CrosshairInterface_C : UInterface {

	void GetCrosshairAimAlpha(float& AimAlpha); // Function BP_CrosshairInterface.BP_CrosshairInterface_C.GetCrosshairAimAlpha // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void WantsShowCrosshair(bool& bShowCrosshair); // Function BP_CrosshairInterface.BP_CrosshairInterface_C.WantsShowCrosshair // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void WantsBowMode(bool& bWantsBowMode); // Function BP_CrosshairInterface.BP_CrosshairInterface_C.WantsBowMode // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

