// BlueprintGeneratedClass BP_CaveInstance.BP_CaveInstance_C
// Size: 0x280 (Inherited: 0x220)
struct ABP_CaveInstance_C : ACave {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UBP_CaveComponent_C* BP_CaveComponent; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	bool Debug; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct TArray<struct UBP_CaveEntranceComponent_C*> Entrances; // 0x240(0x10)
	struct TArray<struct UBoxComponent*> Volumes; // 0x250(0x10)
	struct TArray<struct FPrefabTransform> VolumeData; // 0x260(0x10)
	struct TArray<struct FPrefabTransform> EntranceData; // 0x270(0x10)

	float GetCurrentSpelunkingDepth(); // Function BP_CaveInstance.BP_CaveInstance_C.GetCurrentSpelunkingDepth // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	float GetSpelunkingDepthFromLocation(struct FVector Location); // Function BP_CaveInstance.BP_CaveInstance_C.GetSpelunkingDepthFromLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	void UserConstructionScript(); // Function BP_CaveInstance.BP_CaveInstance_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_CaveInstance.BP_CaveInstance_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_CaveInstance(int32_t EntryPoint); // Function BP_CaveInstance.BP_CaveInstance_C.ExecuteUbergraph_BP_CaveInstance // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

