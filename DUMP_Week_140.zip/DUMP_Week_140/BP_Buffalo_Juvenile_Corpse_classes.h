// BlueprintGeneratedClass BP_Buffalo_Juvenile_Corpse.BP_Buffalo_Juvenile_Corpse_C
// Size: 0x788 (Inherited: 0x780)
struct ABP_Buffalo_Juvenile_Corpse_C : ABP_GOAP_Corpse_C {
	struct UGFurComponent* GFur; // 0x780(0x08)

	void OnSkinnedStateUpdated(); // Function BP_Buffalo_Juvenile_Corpse.BP_Buffalo_Juvenile_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

