// BlueprintGeneratedClass BP_ActionableBehaviour_Deployable_BeaconTool.BP_ActionableBehaviour_Deployable_BeaconTool_C
// Size: 0xe60 (Inherited: 0xc62)
struct UBP_ActionableBehaviour_Deployable_BeaconTool_C : UBP_ActionableBehaviour_DeployableBase_C {
	char pad_C62[0x6]; // 0xc62(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc68(0x08)
	struct FItemData BeaconItemData; // 0xc70(0x1f0)

	void BlueprintDeploy(struct FTransform DeployTransform, struct AActor* FoundationActor, struct FItemData ItemData, int32_t VarientIndex); // Function BP_ActionableBehaviour_Deployable_BeaconTool.BP_ActionableBehaviour_Deployable_BeaconTool_C.BlueprintDeploy // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CustomDeploymentCheck(struct AActor* HitActor, bool& ValidPlacement, struct FText& Reason); // Function BP_ActionableBehaviour_Deployable_BeaconTool.BP_ActionableBehaviour_Deployable_BeaconTool_C.CustomDeploymentCheck // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnDeploy(struct ADeployable* SpawnedDeployable); // Function BP_ActionableBehaviour_Deployable_BeaconTool.BP_ActionableBehaviour_Deployable_BeaconTool_C.OnDeploy // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Deployable_BeaconTool.BP_ActionableBehaviour_Deployable_BeaconTool_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Deployable_BeaconTool(int32_t EntryPoint); // Function BP_ActionableBehaviour_Deployable_BeaconTool.BP_ActionableBehaviour_Deployable_BeaconTool_C.ExecuteUbergraph_BP_ActionableBehaviour_Deployable_BeaconTool // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

