// BlueprintGeneratedClass BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C
// Size: 0x380 (Inherited: 0x368)
struct UBP_Actionable_Bandage_Consumable_C : UBP_ActionableBehaviour_Hold_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x368(0x08)
	struct TArray<struct UObject*> StoredMontages; // 0x370(0x10)

	void EndHold(bool Success); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.EndHold // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool CanHold(); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.CanHold // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void OnLoaded_2B8B2B624CE5F97DAE6892B748390F73(struct UObject* Loaded); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.OnLoaded_2B8B2B624CE5F97DAE6892B748390F73 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CompleteHold(bool Success); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.CompleteHold // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Server_StartHold(struct AActor* ActorStatedHoldOn); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.Server_StartHold // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Multicast_Bandage(); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.Multicast_Bandage // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Multicast_StopBandaging(); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.Multicast_StopBandaging // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Actionable_Bandage_Consumable(int32_t EntryPoint); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.ExecuteUbergraph_BP_Actionable_Bandage_Consumable // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

