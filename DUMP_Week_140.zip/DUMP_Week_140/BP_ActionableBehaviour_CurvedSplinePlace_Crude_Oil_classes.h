// BlueprintGeneratedClass BP_ActionableBehaviour_CurvedSplinePlace_Crude_Oil.BP_ActionableBehaviour_CurvedSplinePlace_Crude_Oil_C
// Size: 0x560 (Inherited: 0x560)
struct UBP_ActionableBehaviour_CurvedSplinePlace_Crude_Oil_C : UBP_ActionableBehaviour_CurvedSplinePlace_C {
};

