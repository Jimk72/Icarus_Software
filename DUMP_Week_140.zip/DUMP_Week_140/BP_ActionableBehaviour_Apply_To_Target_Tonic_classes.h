// BlueprintGeneratedClass BP_ActionableBehaviour_Apply_To_Target_Tonic.BP_ActionableBehaviour_Apply_To_Target_Tonic_C
// Size: 0x380 (Inherited: 0x380)
struct UBP_ActionableBehaviour_Apply_To_Target_Tonic_C : UBP_ActionableBehaviour_Apply_To_Target_C {
};

