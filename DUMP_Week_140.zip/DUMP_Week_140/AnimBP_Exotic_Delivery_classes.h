// AnimBlueprintGeneratedClass AnimBP_Exotic_Delivery.AnimBP_Exotic_Delivery_C
// Size: 0x659 (Inherited: 0x2c0)
struct UAnimBP_Exotic_Delivery_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x2f8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x320(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x348(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x370(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x398(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x418(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x448(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x4c8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x4f8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x578(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x5a8(0xb0)
	bool Landed; // 0x658(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AnimBP_Exotic_Delivery.AnimBP_Exotic_Delivery_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function AnimBP_Exotic_Delivery.AnimBP_Exotic_Delivery_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_AnimBP_Exotic_Delivery(int32_t EntryPoint); // Function AnimBP_Exotic_Delivery.AnimBP_Exotic_Delivery_C.ExecuteUbergraph_AnimBP_Exotic_Delivery // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

