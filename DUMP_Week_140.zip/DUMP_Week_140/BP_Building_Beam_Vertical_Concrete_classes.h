// BlueprintGeneratedClass BP_Building_Beam_Vertical_Concrete.BP_Building_Beam_Vertical_Concrete_C
// Size: 0xc78 (Inherited: 0xc70)
struct ABP_Building_Beam_Vertical_Concrete_C : ABP_Building_Beam_Vertical_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc70(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Beam_Vertical_Concrete.BP_Building_Beam_Vertical_Concrete_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Building_Beam_Vertical_Concrete(int32_t EntryPoint); // Function BP_Building_Beam_Vertical_Concrete.BP_Building_Beam_Vertical_Concrete_C.ExecuteUbergraph_BP_Building_Beam_Vertical_Concrete // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

