// BlueprintGeneratedClass BP_Building_Floor_Half_2.BP_Building_Floor_Half_1_C
// Size: 0xbe0 (Inherited: 0xbe0)
struct ABP_Building_Floor_Half_1_C : ABP_Building_Floor_C {

	void GetBlockingBypass(struct ABP_Building_Base_C* BuildingClass, struct TArray<struct FVectorPair>& BlockingPreRotate, struct FTransform GridSpaceTransform, struct TArray<struct FVectorPair>& BypassBlocking); // Function BP_Building_Floor_Half_2.BP_Building_Floor_Half_1_C.GetBlockingBypass // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

