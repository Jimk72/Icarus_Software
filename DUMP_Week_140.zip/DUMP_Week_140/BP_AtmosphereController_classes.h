// BlueprintGeneratedClass BP_AtmosphereController.BP_AtmosphereController_C
// Size: 0x6c0 (Inherited: 0x2c0)
struct ABP_AtmosphereController_C : AIcarusActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct UPostProcessComponent* PostProcess_GL; // 0x2c8(0x08)
	struct UPostProcessComponent* PostProcess_CF; // 0x2d0(0x08)
	struct UPostProcessComponent* PostProcess_Fire; // 0x2d8(0x08)
	struct UPostProcessComponent* PostProcess_SandStorm; // 0x2e0(0x08)
	struct UPostProcessComponent* PostProcess_Base; // 0x2e8(0x08)
	struct UPostProcessComponent* PostProcess_WL; // 0x2f0(0x08)
	struct UPostProcessComponent* PostProcess_AC; // 0x2f8(0x08)
	struct UPostProcessComponent* PostProcess_DC; // 0x300(0x08)
	struct UPostProcessComponent* PostProcess_LC; // 0x308(0x08)
	struct USceneComponent* PostProcesss; // 0x310(0x08)
	struct UStaticMeshComponent* Sphere; // 0x318(0x08)
	struct UStaticMeshComponent* SunPos; // 0x320(0x08)
	struct UStaticMeshComponent* SM_PlanetCard6; // 0x328(0x08)
	struct UStaticMeshComponent* SM_PlanetCard5; // 0x330(0x08)
	struct UStaticMeshComponent* SM_PlanetCard4; // 0x338(0x08)
	struct UStaticMeshComponent* SM_PlanetCard3; // 0x340(0x08)
	struct UStaticMeshComponent* SM_PlanetCard2; // 0x348(0x08)
	struct UStaticMeshComponent* SM_PlanetCard1; // 0x350(0x08)
	struct UStaticMeshComponent* SM_PlanetCard; // 0x358(0x08)
	struct USceneComponent* SkyPlanets; // 0x360(0x08)
	struct UBP_CaveLightController_C* BP_CaveLightController; // 0x368(0x08)
	struct UVolumetricCloudComponent* VolumetricCloud; // 0x370(0x08)
	struct USkyAtmosphereComponent* SkyAtmosphere; // 0x378(0x08)
	struct UStaticMeshComponent* SkySphere; // 0x380(0x08)
	struct UDirectionalLightComponent* MoonLight; // 0x388(0x08)
	struct USceneComponent* MoonOffset; // 0x390(0x08)
	struct USceneComponent* Moon; // 0x398(0x08)
	struct UDirectionalLightComponent* SunLight; // 0x3a0(0x08)
	struct UExponentialHeightFogComponent* ExponentialHeightFog; // 0x3a8(0x08)
	struct USkyLightComponent* SkyLight; // 0x3b0(0x08)
	struct UChildActorComponent* WindDirectionalSource; // 0x3b8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3c0(0x08)
	int32_t StartHour; // 0x3c8(0x04)
	float StartMinute; // 0x3cc(0x04)
	struct UCurveFloat* CurveWeatherWind; // 0x3d0(0x08)
	bool Enabled; // 0x3d8(0x01)
	char pad_3D9[0x3]; // 0x3d9(0x03)
	float SnowcapHeight; // 0x3dc(0x04)
	float SunRoll; // 0x3e0(0x04)
	float RainAmountCF; // 0x3e4(0x04)
	float StormAmountCF; // 0x3e8(0x04)
	float RainAmountLC; // 0x3ec(0x04)
	float StormAmountLC; // 0x3f0(0x04)
	float RainAmountDC; // 0x3f4(0x04)
	float StormAmountDC; // 0x3f8(0x04)
	float RainAmountAC; // 0x3fc(0x04)
	float StormAmountAC; // 0x400(0x04)
	float RainAmountWL; // 0x404(0x04)
	float StormAmountWL; // 0x408(0x04)
	bool Debug_Wind; // 0x40c(0x01)
	enum class EBiomes CurrentBiome; // 0x40d(0x01)
	char pad_40E[0x2]; // 0x40e(0x02)
	float TransitionValue; // 0x410(0x04)
	bool SpineTransition; // 0x414(0x01)
	char pad_415[0x3]; // 0x415(0x03)
	struct UCurveFloat* CurveNightSky; // 0x418(0x08)
	float FogOffset; // 0x420(0x04)
	float SunDirection; // 0x424(0x04)
	struct UCurveFloat* CurveSunIntensity; // 0x428(0x08)
	struct UCurveFloat* CurveSkylightIntensity; // 0x430(0x08)
	struct UCurveLinearColor* CurveSunColour; // 0x438(0x08)
	bool AutoTransition; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct UCurveFloat* TimeScaleCurve; // 0x448(0x08)
	float MoonRoll; // 0x450(0x04)
	float FogHeight; // 0x454(0x04)
	struct UCurveFloat* CurveMoonIntensity; // 0x458(0x08)
	float WeatherVal_Rain; // 0x460(0x04)
	float WeatherVal_SandStorm; // 0x464(0x04)
	float WeatherVal_Snow; // 0x468(0x04)
	float WeatherVal_Cloudy; // 0x46c(0x04)
	float WeatherVal_Thunder; // 0x470(0x04)
	char pad_474[0x4]; // 0x474(0x04)
	struct UMaterialInstanceDynamic* DynamicCloudMaterial; // 0x478(0x08)
	float WeatherVal_SnowStorm; // 0x480(0x04)
	char pad_484[0x4]; // 0x484(0x04)
	struct FBiomesEnum PlayerBiome; // 0x488(0x10)
	struct FBiomesEnum PlayerNewBiome; // 0x498(0x10)
	struct UTexture* CloudMap; // 0x4a8(0x08)
	float DropshipOverride; // 0x4b0(0x04)
	float WeatherVal_WindSpeed; // 0x4b4(0x04)
	float WeatherVal_WindStrength; // 0x4b8(0x04)
	float WeatherVal_WindMaxGustAmount; // 0x4bc(0x04)
	float WeatherVal_WindMinGustAmount; // 0x4c0(0x04)
	char pad_4C4[0x4]; // 0x4c4(0x04)
	struct UCurveFloat* CurveContactShadow; // 0x4c8(0x08)
	float WeatherVal_Debris; // 0x4d0(0x04)
	float OverrideWindSpeed; // 0x4d4(0x04)
	float OverrideWindStrength; // 0x4d8(0x04)
	bool UpdateWeather; // 0x4dc(0x01)
	char pad_4DD[0x3]; // 0x4dd(0x03)
	struct UCurveFloat* CloudCoverageFogCurve; // 0x4e0(0x08)
	struct FMulticastInlineDelegate SunLightDirection; // 0x4e8(0x10)
	struct FMulticastInlineDelegate SunLightColor; // 0x4f8(0x10)
	float WeatherVal_FogDensity; // 0x508(0x04)
	float WeatherVal_FogExtinction; // 0x50c(0x04)
	struct FLinearColor Color_2; // 0x510(0x10)
	float Intensity_2; // 0x520(0x04)
	struct FRotator SunDirection_2; // 0x524(0x0c)
	struct UCurveFloat* CaveLightCurve; // 0x530(0x08)
	struct TArray<struct AWT_CaveVolume_C*> CaveVolumesInUse; // 0x538(0x10)
	float CaveInfluence; // 0x548(0x04)
	char pad_54C[0x4]; // 0x54c(0x04)
	struct UCurveFloat* CurvePlanetSunDirection; // 0x550(0x08)
	struct FRotator WindRotation; // 0x558(0x0c)
	bool useWeatherMan; // 0x564(0x01)
	char pad_565[0x3]; // 0x565(0x03)
	struct UCurveLinearColor* LocalFogTimeOfDay; // 0x568(0x08)
	struct UCurveFloat* CurveShadowCascades; // 0x570(0x08)
	float ImpassableSnowOffset; // 0x578(0x04)
	float SunBrightness; // 0x57c(0x04)
	float MoonThreshold; // 0x580(0x04)
	struct FLinearColor MoonLightColor; // 0x584(0x10)
	bool Use Sun Atmosphere for moon; // 0x594(0x01)
	bool UseLowShadowSettings; // 0x595(0x01)
	bool OverrideLightSettings; // 0x596(0x01)
	bool WeathermanActive; // 0x597(0x01)
	float RealTimeThisFrame; // 0x598(0x04)
	float TimeTotalThisFrame; // 0x59c(0x04)
	float WeatherVal_Ash; // 0x5a0(0x04)
	float WeatherVal_Embers; // 0x5a4(0x04)
	float WeatherVal_Smoke; // 0x5a8(0x04)
	float WeatherVal_AcidRain; // 0x5ac(0x04)
	float WeatherVal_Hail; // 0x5b0(0x04)
	float RainAmountGL; // 0x5b4(0x04)
	float StormAmountGL; // 0x5b8(0x04)
	struct FVector CurrentBloomSettings; // 0x5bc(0x0c)
	bool BloomActive; // 0x5c8(0x01)
	char pad_5C9[0x7]; // 0x5c9(0x07)
	struct TMap<struct FAtmospheresEnum, struct FIcarusAtmosphere> AtmosphereData; // 0x5d0(0x50)
	struct TMap<struct FAtmospheresEnum, float> AtmosphereInfluence; // 0x620(0x50)
	struct TMap<struct FAtmospheresEnum, struct UPostProcessComponent*> PostProcessing; // 0x670(0x50)

	void ForceSetAtmosphere(struct FAtmospheresEnum Atmosphere); // Function BP_AtmosphereController.BP_AtmosphereController_C.ForceSetAtmosphere // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetAtmosphereInfluence(struct FAtmospheresEnum Atmosphere, float& Influence); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetAtmosphereInfluence // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateCaveInfluence(float Influence); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateCaveInfluence // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetOvercastScatterring(float& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetOvercastScatterring // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void CheckShadowQualitySetting(); // Function BP_AtmosphereController.BP_AtmosphereController_C.CheckShadowQualitySetting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetSkylightIntensity(float& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetSkylightIntensity // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetFogTintPerBiome(struct FLinearColor& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetFogTintPerBiome // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	struct FVector GetBloomSettingsPerBiome(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetBloomSettingsPerBiome // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetMoonBrightnessPerBiome(float& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetMoonBrightnessPerBiome // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetSunBrightnessPerBiome(float& OutBrightness); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetSunBrightnessPerBiome // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetSunColorPerBiome(struct FLinearColor& OutColor); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetSunColorPerBiome // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateBloomSettings(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateBloomSettings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	struct FAtmospheresEnum GetAtmosphereType(struct FBiomesEnum Biome); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetAtmosphereType // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	float GetCurrentTimeRealTime(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeRealTime // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	float GetCurrentTimeNormalized(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeNormalized // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	float GetCurrentTimeTotal(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeTotal // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void FogTimeOfDay(); // Function BP_AtmosphereController.BP_AtmosphereController_C.FogTimeOfDay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void RemoveCaveVolume(struct AWT_CaveVolume_C* Volume); // Function BP_AtmosphereController.BP_AtmosphereController_C.RemoveCaveVolume // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void AddCaveVolume(struct AWT_CaveVolume_C* Volume); // Function BP_AtmosphereController.BP_AtmosphereController_C.AddCaveVolume // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void WeatherVisualUpdated(); // Function BP_AtmosphereController.BP_AtmosphereController_C.WeatherVisualUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void LinearBiomeTransition(struct FBiomesEnum PlayerNewBiome); // Function BP_AtmosphereController.BP_AtmosphereController_C.LinearBiomeTransition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void TransitionWeather(struct FBiomesEnum FromBiome, struct FBiomesEnum ToBiome, float Amount); // Function BP_AtmosphereController.BP_AtmosphereController_C.TransitionWeather // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Get Dist Fog Scale(struct FVector& Scale); // Function BP_AtmosphereController.BP_AtmosphereController_C.Get Dist Fog Scale // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetCloudCoverage(float& Coverage, float& CoverageNoClamp); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCloudCoverage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateCloudCoverage(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateCloudCoverage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void MoonSetRotation(); // Function BP_AtmosphereController.BP_AtmosphereController_C.MoonSetRotation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateBiomeMPCs(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateBiomeMPCs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateWeatherMPCs(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateWeatherMPCs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SkylightSetProperties(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SkylightSetProperties // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void FogSetProperties(); // Function BP_AtmosphereController.BP_AtmosphereController_C.FogSetProperties // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SunSetProperties(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunSetProperties // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SunSetRotation(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunSetRotation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	float GetBiomeInfluence(struct FBiomesEnum Biome); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetBiomeInfluence // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void Transition Biome(struct FBiomesEnum FromBiome, struct FBiomesEnum ToBiome, float Amount); // Function BP_AtmosphereController.BP_AtmosphereController_C.Transition Biome // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CycleBiome(); // Function BP_AtmosphereController.BP_AtmosphereController_C.CycleBiome // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ForceSetBiome(struct FBiomesEnum Biome); // Function BP_AtmosphereController.BP_AtmosphereController_C.ForceSetBiome // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Fog Track Player(); // Function BP_AtmosphereController.BP_AtmosphereController_C.Fog Track Player // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdatePostProcessing(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdatePostProcessing // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateWind(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateWind // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetTerrainDetails(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SetTerrainDetails // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void EditorReset(); // Function BP_AtmosphereController.BP_AtmosphereController_C.EditorReset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Update Atmosphere Settings(); // Function BP_AtmosphereController.BP_AtmosphereController_C.Update Atmosphere Settings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetCurrentTimeOfDay(float& Total, float& Normalized, float& Realtime); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeOfDay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UserConstructionScript(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CheckBiome(); // Function BP_AtmosphereController.BP_AtmosphereController_C.CheckBiome // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_AtmosphereController.BP_AtmosphereController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveTick(float DeltaSeconds); // Function BP_AtmosphereController.BP_AtmosphereController_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void SlowTickUpdates(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SlowTickUpdates // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_AtmosphereController(int32_t EntryPoint); // Function BP_AtmosphereController.BP_AtmosphereController_C.ExecuteUbergraph_BP_AtmosphereController // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
	void SunLightColor__DelegateSignature(struct FLinearColor Color, float Intensity, float CaveCover); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunLightColor__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SunLightDirection__DelegateSignature(struct FRotator SunDirection); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunLightDirection__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

