// BlueprintGeneratedClass BP_Breakable_Scoria_Var2.BP_Breakable_Scoria_Var2_C
// Size: 0x428 (Inherited: 0x400)
struct ABP_Breakable_Scoria_Var2_C : ABP_Breakable_Rock_Base_C {
	struct UStaticMeshComponent* SM_Breakable_Scoria_01_Var2; // 0x400(0x08)
	struct UStaticMeshComponent* SM_Breakable_Scoria_05_Var2; // 0x408(0x08)
	struct UStaticMeshComponent* SM_Breakable_Scoria_04_Var2; // 0x410(0x08)
	struct UStaticMeshComponent* SM_Breakable_Scoria_03_Var2; // 0x418(0x08)
	struct UStaticMeshComponent* SM_Breakable_Scoria_02_Var2; // 0x420(0x08)
};

