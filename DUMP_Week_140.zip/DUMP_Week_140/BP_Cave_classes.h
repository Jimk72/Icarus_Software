// BlueprintGeneratedClass BP_Cave.BP_Cave_C
// Size: 0x388 (Inherited: 0x220)
struct ABP_Cave_C : ACave {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UChildActorComponent* WT_CaveVoid; // 0x228(0x08)
	struct UBoxComponent* TriggerVolume; // 0x230(0x08)
	struct UBP_CaveEntranceComponent_C* Entrance; // 0x238(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x240(0x08)
	struct FName CollisionProfile; // 0x248(0x08)
	struct UCurveFloat* EntranceDistanceCurve; // 0x250(0x08)
	bool Debug; // 0x258(0x01)
	char pad_259[0x7]; // 0x259(0x07)
	struct TArray<struct UBP_CaveEntranceComponent_C*> Entrances; // 0x260(0x10)
	struct TArray<struct FTransform> CachedLocations; // 0x270(0x10)
	struct FTimerHandle CaveUpdateTimerHandle; // 0x280(0x08)
	float ActiveUpdateFrequency; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct TSet<struct UPrimitiveComponent*> LocalPlayerOverlaps; // 0x290(0x50)
	float CaveVoidScale; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct TMap<struct FString, struct FFCaveVolumeCache> CachedVolumeCaches; // 0x2e8(0x50)
	struct TArray<struct UBoxComponent*> NewVolume; // 0x338(0x10)
	struct TArray<struct FTransform> CachedVoidChildTransforms; // 0x348(0x10)
	struct TArray<struct FTransform> CachedEntranceTransforms; // 0x358(0x10)
	struct TArray<struct UBP_CaveEntranceComponent_C*> EntranceRefs; // 0x368(0x10)
	float SpelunkingDepth; // 0x378(0x04)
	char pad_37C[0x4]; // 0x37c(0x04)
	struct AController* LocalPlayerController; // 0x380(0x08)

	float GetCurrentSpelunkingDepth(); // Function BP_Cave.BP_Cave_C.GetCurrentSpelunkingDepth // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	float GetSpelunkingDepthFromLocation(struct FVector Location); // Function BP_Cave.BP_Cave_C.GetSpelunkingDepthFromLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	void IsLocalPlayer(struct AActor* InActor, bool& Local); // Function BP_Cave.BP_Cave_C.IsLocalPlayer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CacheLocalPlayerController(); // Function BP_Cave.BP_Cave_C.CacheLocalPlayerController // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void NewFunction_1(); // Function BP_Cave.BP_Cave_C.NewFunction_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PlayerOverlapValidation(); // Function BP_Cave.BP_Cave_C.PlayerOverlapValidation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateOverlapState(); // Function BP_Cave.BP_Cave_C.UpdateOverlapState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool HasCacheChanged(struct TMap<struct FString, struct FFCaveVolumeCache> NewCachedVolumeCaches, struct TArray<struct FTransform>& NewCachedVoidChildTransform, struct TArray<struct FTransform>& CachedEntranceTransform); // Function BP_Cave.BP_Cave_C.HasCacheChanged // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool CacheValues(); // Function BP_Cave.BP_Cave_C.CacheValues // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	float GetEntranceDepthForAtmos(struct FVector Location); // Function BP_Cave.BP_Cave_C.GetEntranceDepthForAtmos // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	float GetSpelunkingDepth(struct FVector Location); // Function BP_Cave.BP_Cave_C.GetSpelunkingDepth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fcdea0
	void OnOverlapEnd(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor); // Function BP_Cave.BP_Cave_C.OnOverlapEnd // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnOverlapBegin(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor); // Function BP_Cave.BP_Cave_C.OnOverlapBegin // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Refresh(); // Function BP_Cave.BP_Cave_C.Refresh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UserConstructionScript(); // Function BP_Cave.BP_Cave_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_Cave.BP_Cave_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void OnChildComponentBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Cave.BP_Cave_C.OnChildComponentBeginOverlap // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnChildComponentEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_Cave.BP_Cave_C.OnChildComponentEndOverlap // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_Cave.BP_Cave_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void CaveUpdate(); // Function BP_Cave.BP_Cave_C.CaveUpdate // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void StartUpdateTimer(); // Function BP_Cave.BP_Cave_C.StartUpdateTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Cave(int32_t EntryPoint); // Function BP_Cave.BP_Cave_C.ExecuteUbergraph_BP_Cave // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

