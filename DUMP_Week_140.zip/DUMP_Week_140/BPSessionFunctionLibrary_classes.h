// BlueprintGeneratedClass BPSessionFunctionLibrary.BPSessionFunctionLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UBPSessionFunctionLibrary_C : UBlueprintFunctionLibrary {

	void CalculateProspectState(struct FProspectInfo& ProspectInfo, struct AIcarusPlayerController* Target, struct UObject* __WorldContext, enum class E_ProspectState& ProspectState); // Function BPSessionFunctionLibrary.BPSessionFunctionLibrary_C.CalculateProspectState // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void HaveJoinedProspect(struct FString UserID, struct TArray<struct FAssociatedMemberInfo>& Members, int32_t ChrSlot, struct UObject* __WorldContext, bool& AssignedToProspect, enum class EProspectLocation& Status); // Function BPSessionFunctionLibrary.BPSessionFunctionLibrary_C.HaveJoinedProspect // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void HasSettled(struct AIcarusPlayerController* Target, struct FFProspectServerInfo& FProspectServerInfo, struct UObject* __WorldContext, bool& Settled); // Function BPSessionFunctionLibrary.BPSessionFunctionLibrary_C.HasSettled // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ProspectInfoIsValid(struct FFProspectServerInfo Server Prospect Info, bool RequiresSession, struct UObject* __WorldContext, bool& Valid); // Function BPSessionFunctionLibrary.BPSessionFunctionLibrary_C.ProspectInfoIsValid // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

