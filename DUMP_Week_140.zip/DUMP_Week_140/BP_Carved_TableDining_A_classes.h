// BlueprintGeneratedClass BP_Carved_TableDining_A.BP_Carved_TableDining_A_C
// Size: 0x761 (Inherited: 0x761)
struct ABP_Carved_TableDining_A_C : ABP_DeployableBase_C {
};

