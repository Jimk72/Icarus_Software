// BlueprintGeneratedClass BP_Actionable_Behaviour_Water_Bucket.BP_Actionable_Behaviour_Water_Bucket_C
// Size: 0x32c (Inherited: 0x32c)
struct UBP_Actionable_Behaviour_Water_Bucket_C : UBP_Actionable_Behaviour_WateringCan_C {
};

