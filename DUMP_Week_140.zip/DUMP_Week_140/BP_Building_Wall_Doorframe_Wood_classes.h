// BlueprintGeneratedClass BP_Building_Wall_Doorframe_Wood.BP_Building_Wall_Doorframe_Wood_C
// Size: 0xbe8 (Inherited: 0xbd8)
struct ABP_Building_Wall_Doorframe_Wood_C : ABP_Building_Wall_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd8(0x08)
	struct UBP_WeatherAudioComponent_Window_C* BP_WeatherAudioComponent_Window; // 0xbe0(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Wall_Doorframe_Wood.BP_Building_Wall_Doorframe_Wood_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Building_Wall_Doorframe_Wood(int32_t EntryPoint); // Function BP_Building_Wall_Doorframe_Wood.BP_Building_Wall_Doorframe_Wood_C.ExecuteUbergraph_BP_Building_Wall_Doorframe_Wood // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

