// BlueprintGeneratedClass BP_Animal_Trap_Base.BP_Animal_Trap_Base_C
// Size: 0x7c8 (Inherited: 0x761)
struct ABP_Animal_Trap_Base_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x770(0x08)
	struct USceneComponent* Scene; // 0x778(0x08)
	struct UBoxComponent* CaptureZone; // 0x780(0x08)
	struct UInventory* InventoryRef; // 0x788(0x08)
	struct FAISetupRowHandle Creature; // 0x790(0x18)
	int32_t Level; // 0x7a8(0x04)
	bool bTrapActive; // 0x7ac(0x01)
	char pad_7AD[0x3]; // 0x7ad(0x03)
	float AttractionRadius; // 0x7b0(0x04)
	char pad_7B4[0x4]; // 0x7b4(0x04)
	struct TArray<struct FAISetupRowHandle> ValidCaptureList; // 0x7b8(0x10)

	void CanCaptureAnimal(struct UObject* Creature, bool& CanCapture); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.CanCaptureAnimal // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void CaptureAnimal(struct UObject* Object); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.CaptureAnimal // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ToggleTrapActive(); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.ToggleTrapActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReleaseCreature(); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.ReleaseCreature // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_bActive(); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.OnRep_bActive // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BndEvt__BP_AnimalTrap_Base_CaptureZone_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.BndEvt__BP_AnimalTrap_Base_CaptureZone_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1fcdea0
	void IcarusBeginPlay(); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Animal_Trap_Base(int32_t EntryPoint); // Function BP_Animal_Trap_Base.BP_Animal_Trap_Base_C.ExecuteUbergraph_BP_Animal_Trap_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

