// BlueprintGeneratedClass BP_ChatboxItem.BP_ChatboxItem_C
// Size: 0x80 (Inherited: 0x28)
struct UBP_ChatboxItem_C : UObject {
	enum class EChatMessageType MessageType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString Message; // 0x30(0x10)
	struct FIcarusPlayerChatMessage PlayerMessage; // 0x40(0x40)
};

