// BlueprintGeneratedClass BP_Chicken_Corpse.BP_Chicken_Corpse_C
// Size: 0x784 (Inherited: 0x780)
struct ABP_Chicken_Corpse_C : ABP_GOAP_Corpse_C {
	int32_t ChickenColourIndex; // 0x780(0x04)

	void UpdateCosmeticMaterials(); // Function BP_Chicken_Corpse.BP_Chicken_Corpse_C.UpdateCosmeticMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void IsSkeletonUpdated(); // Function BP_Chicken_Corpse.BP_Chicken_Corpse_C.IsSkeletonUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnSkinnedStateUpdated(); // Function BP_Chicken_Corpse.BP_Chicken_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

