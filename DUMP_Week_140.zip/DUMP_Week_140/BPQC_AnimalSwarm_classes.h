// BlueprintGeneratedClass BPQC_AnimalSwarm.BPQC_AnimalSwarm_C
// Size: 0x1c4 (Inherited: 0xb0)
struct UBPQC_AnimalSwarm_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	float TimeBetweenSpawns; // 0xb8(0x04)
	float TimeBetweenSpawnsMultiplier; // 0xbc(0x04)
	int32_t MaxCreatures; // 0xc0(0x04)
	struct FAISetupRowHandle Creature; // 0xc4(0x18)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct TArray<struct ABP_IcarusNPCGOAPCharacter_C*> NPCs; // 0xe0(0x10)
	struct FRandomStream Random Stream; // 0xf0(0x08)
	struct AActor* Target; // 0xf8(0x08)
	struct FMulticastInlineDelegate CreatureKilled; // 0x100(0x10)
	struct FVector Item; // 0x110(0x0c)
	bool Player Max Number Scaling; // 0x11c(0x01)
	char pad_11D[0x3]; // 0x11d(0x03)
	float AdditionalCreaturesPerPlayer; // 0x120(0x04)
	int32_t Hard Creature Limit; // 0x124(0x04)
	struct TArray<struct FAISetupRowHandle> Creatures; // 0x128(0x10)
	struct AActor* SpawnTarget; // 0x138(0x08)
	float MinPlayerDistance; // 0x140(0x04)
	float MinDistance; // 0x144(0x04)
	float MaxDistance; // 0x148(0x04)
	float Spacing; // 0x14c(0x04)
	enum class EEnvQueryRunMode RunMode; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct UEnvQuery* QueryTemplate; // 0x158(0x08)
	int32_t LevelBonus; // 0x160(0x04)
	char pad_164[0xc]; // 0x164(0x0c)
	struct FTransform SpawnTransformOverride; // 0x170(0x30)
	struct FRotator SpawnRotation; // 0x1a0(0x0c)
	struct FEpicCreaturesRowHandle EpicCreature; // 0x1ac(0x18)

	void SetLevelBonus(int32_t LevelBonus); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.SetLevelBonus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetTimeBetweenSpawnsMultiplier(float TimeBetweenSpawnsMultiplier); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.SetTimeBetweenSpawnsMultiplier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Configure Distances(float MinPlayerDistance, float MinDistance, float MaxDistance, float Spacing); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.Configure Distances // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateSpawnTarget(struct TArray<struct AActor*>& SpawnTargets); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.UpdateSpawnTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Get Creature(struct FAISetupRowHandle& Creature); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.Get Creature // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void SetupMultiCreature(float TimeBetweenSpawns, int32_t MaxCreatures, struct TArray<struct FAISetupRowHandle>& Creature); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.SetupMultiCreature // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetupMultiplayerScaling(bool Player Max Number Scaling, float AdditionalCreaturesPerPlayer, int32_t HardLimit); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.SetupMultiplayerScaling // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetMaxCreatures(int32_t& ScaledNumber); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.GetMaxCreatures // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	bool CanSpawn(); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.CanSpawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateTarget(struct AActor* Target); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.UpdateTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Setup(float TimeBetweenSpawns, int32_t MaxCreatures, struct FAISetupRowHandle Creature); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void AngerNPC(struct AIcarusNPCGOAPCharacter* NPC); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.AngerNPC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveTick(float DeltaSeconds); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void EQSComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.EQSComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnActorDeath(struct UActorState* ActorState); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.OnActorDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SpawnCreature(); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.SpawnCreature // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.OnEndPlay // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void SpawnAtCustomLocation(); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.SpawnAtCustomLocation // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BPQC_AnimalSwarm(int32_t EntryPoint); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.ExecuteUbergraph_BPQC_AnimalSwarm // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
	void CreatureKilled__DelegateSignature(); // Function BPQC_AnimalSwarm.BPQC_AnimalSwarm_C.CreatureKilled__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

