// BlueprintGeneratedClass BP_Actionable_Shovel_Dig.BP_Actionable_Shovel_Dig_C
// Size: 0x5f8 (Inherited: 0x3a0)
struct UBP_Actionable_Shovel_Dig_C : UBP_ActionableBehaviour_Generic_Melee_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	float SnowClearThresholdDegrees; // 0x3a8(0x04)
	char pad_3AC[0x4]; // 0x3ac(0x04)
	struct FItemData GainedResource; // 0x3b0(0x1f0)
	bool bCorrectTrigger; // 0x5a0(0x01)
	char pad_5A1[0x7]; // 0x5a1(0x07)
	struct TSet<struct UPhysicalMaterial*> DigHolePhysMaterials; // 0x5a8(0x50)

	void ApplyDirtMoundModifiers(struct AActor* DirtMound, struct UIcarusStatContainer* ShovelStatContainer); // Function BP_Actionable_Shovel_Dig.BP_Actionable_Shovel_Dig_C.ApplyDirtMoundModifiers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetAdditionalStatsForDugHole(struct UIcarusStatContainer* ShovelStats, struct TArray<struct FIcarusStatReplicated>& HoleAdditionalStats); // Function BP_Actionable_Shovel_Dig.BP_Actionable_Shovel_Dig_C.GetAdditionalStatsForDugHole // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void OnActionHitEvent(struct AActor* Invoking Actor, struct UPrimitiveComponent* OverlappedComponent , struct FHitResult& SweepResult); // Function BP_Actionable_Shovel_Dig.BP_Actionable_Shovel_Dig_C.OnActionHitEvent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_Actionable_Shovel_Dig.BP_Actionable_Shovel_Dig_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Actionable_Shovel_Dig(int32_t EntryPoint); // Function BP_Actionable_Shovel_Dig.BP_Actionable_Shovel_Dig_C.ExecuteUbergraph_BP_Actionable_Shovel_Dig // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

