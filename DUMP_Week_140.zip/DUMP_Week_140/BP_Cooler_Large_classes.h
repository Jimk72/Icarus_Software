// BlueprintGeneratedClass BP_Cooler_Large.BP_Cooler_Large_C
// Size: 0x7b4 (Inherited: 0x771)
struct ABP_Cooler_Large_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_771[0x7]; // 0x771(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x778(0x08)
	struct URectLightComponent* RectLight; // 0x780(0x08)
	struct USceneComponent* Scene_Lights; // 0x788(0x08)
	struct UFMODAudioComponent* ActiveAudio; // 0x790(0x08)
	int32_t LastRangeValue; // 0x798(0x04)
	struct FModifierStatesRowHandle AuraEffect; // 0x79c(0x18)

	void UpdateAuraEffect(bool Active); // Function BP_Cooler_Large.BP_Cooler_Large_C.UpdateAuraEffect // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateThermalComponent(); // Function BP_Cooler_Large.BP_Cooler_Large_C.UpdateThermalComponent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Update Running Effects(bool ReceivingPower); // Function BP_Cooler_Large.BP_Cooler_Large_C.Update Running Effects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnDeviceStartRunning(); // Function BP_Cooler_Large.BP_Cooler_Large_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnDeviceStopRunning(); // Function BP_Cooler_Large.BP_Cooler_Large_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void IcarusBeginPlay(); // Function BP_Cooler_Large.BP_Cooler_Large_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void OnStatContainerUpdated(); // Function BP_Cooler_Large.BP_Cooler_Large_C.OnStatContainerUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Cooler_Large(int32_t EntryPoint); // Function BP_Cooler_Large.BP_Cooler_Large_C.ExecuteUbergraph_BP_Cooler_Large // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

