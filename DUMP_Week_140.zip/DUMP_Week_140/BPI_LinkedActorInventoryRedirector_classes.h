// BlueprintGeneratedClass BPI_LinkedActorInventoryRedirector.BPI_LinkedActorInventoryRedirector_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_LinkedActorInventoryRedirector_C : UInterface {

	void GetRedirectedInventoryComponent(struct UInventoryComponent*& InventoryComponent); // Function BPI_LinkedActorInventoryRedirector.BPI_LinkedActorInventoryRedirector_C.GetRedirectedInventoryComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

