// BlueprintGeneratedClass BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C
// Size: 0x3f0 (Inherited: 0x2f0)
struct ABP_Deep_Mining_Ore_Deposit_C : ABP_Deep_Mining_Ore_Deposit_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f0(0x08)
	struct UHighlightableComponent* Highlightable; // 0x2f8(0x08)
	struct TMap<struct FOreDepositRowHandle, float> RandomDesiredRatios; // 0x300(0x50)
	float CachedTotalWeight; // 0x350(0x04)
	char pad_354[0x4]; // 0x354(0x04)
	struct TMap<struct FOreDepositRowHandle, float> CachedCurrentRatios; // 0x358(0x50)
	struct TArray<struct FVector> TransformsToVector; // 0x3a8(0x10)
	struct AActor* HighestDropship; // 0x3b8(0x08)
	struct UMaterialInterface* NodeMaterial; // 0x3c0(0x08)
	struct FOreDepositRowHandle LocalMaterialType; // 0x3c8(0x18)
	bool IsDesertDeposit; // 0x3e0(0x01)
	bool IsInCave; // 0x3e1(0x01)
	char pad_3E2[0x6]; // 0x3e2(0x06)
	struct UMaterialInterface* RockMaterial; // 0x3e8(0x08)

	void AssignType(); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.AssignType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	struct TSoftObjectPtr<UMaterialInterface> GetNodeMaterial(struct FOreDeposit& OreDeposit); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.GetNodeMaterial // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BiomeUpdated(); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.BiomeUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_LocalMaterialType(); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.OnRep_LocalMaterialType // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnLoaded_86CD52A24289457079E06B9B6B8EE0DB(struct UObject* Loaded); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.OnLoaded_86CD52A24289457079E06B9B6B8EE0DB // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnLoaded_7A08DCE545D5B147504667BA88769DFC(struct UObject* Loaded); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.OnLoaded_7A08DCE545D5B147504667BA88769DFC // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetMaterialType(struct FOreDepositRowHandle Row); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.SetMaterialType // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void IcarusBeginPlay(); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Deep_Mining_Ore_Deposit(int32_t EntryPoint); // Function BP_Deep_Mining_Ore_Deposit.BP_Deep_Mining_Ore_Deposit_C.ExecuteUbergraph_BP_Deep_Mining_Ore_Deposit // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

