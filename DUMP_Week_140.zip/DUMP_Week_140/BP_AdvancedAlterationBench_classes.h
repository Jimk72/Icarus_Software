// BlueprintGeneratedClass BP_AdvancedAlterationBench.BP_AdvancedAlterationBench_C
// Size: 0xbf8 (Inherited: 0xbf8)
struct ABP_AdvancedAlterationBench_C : ABP_AlterationBench_C {

	void ModifyAlterTime(float AlterTickTime, float& ModifiedAlterTickTime); // Function BP_AdvancedAlterationBench.BP_AdvancedAlterationBench_C.ModifyAlterTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
};

