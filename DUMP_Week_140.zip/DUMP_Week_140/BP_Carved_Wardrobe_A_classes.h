// BlueprintGeneratedClass BP_Carved_Wardrobe_A.BP_Carved_Wardrobe_A_C
// Size: 0x77a (Inherited: 0x77a)
struct ABP_Carved_Wardrobe_A_C : ABP_DeployableContainerBase_C {
};

