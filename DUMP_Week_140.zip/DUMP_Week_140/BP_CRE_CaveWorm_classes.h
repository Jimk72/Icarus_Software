// BlueprintGeneratedClass BP_CRE_CaveWorm.BP_CRE_CaveWorm_C
// Size: 0x690 (Inherited: 0x629)
struct ABP_CRE_CaveWorm_C : ABP_FactionBoss_SandWorm_C {
	char pad_629[0x7]; // 0x629(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x630(0x08)
	struct UVocalisationComponent* Vocalisation; // 0x638(0x08)
	struct USceneComponent* LootBagLocation; // 0x640(0x08)
	struct UAudioContextComponent* AudioContext; // 0x648(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_MED_01; // 0x650(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_SML_02; // 0x658(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_MED_06; // 0x660(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_MED_03; // 0x668(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_SML_01; // 0x670(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_SML_05; // 0x678(0x08)
	struct UStaticMeshComponent* SM_ROCK_CF_SML_03; // 0x680(0x08)
	struct UStaticMeshComponent* Cylinder; // 0x688(0x08)

	void DropScales(struct AActor* Causer, int32_t DamageTaken); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.DropScales // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SpawnLootBag(); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.SpawnLootBag // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	enum class EMusicConditionCombatState GetCombatMusicConditionOverride(struct AIcarusPlayerCharacter* TargetPlayer, float Threat); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.GetCombatMusicConditionOverride // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UserConstructionScript(); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveTick(float DeltaSeconds); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void OnActorDeath(struct UActorState* ActorStateIn); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.OnActorDeath // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_CRE_CaveWorm(int32_t EntryPoint); // Function BP_CRE_CaveWorm.BP_CRE_CaveWorm_C.ExecuteUbergraph_BP_CRE_CaveWorm // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

