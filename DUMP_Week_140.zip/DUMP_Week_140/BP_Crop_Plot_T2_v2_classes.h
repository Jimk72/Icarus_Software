// BlueprintGeneratedClass BP_Crop_Plot_T2_v2.BP_Crop_Plot_T2_v2_C
// Size: 0x871 (Inherited: 0x871)
struct ABP_Crop_Plot_T2_v2_C : ABP_Crop_Plot_Base_C {
};

