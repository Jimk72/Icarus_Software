// BlueprintGeneratedClass BP_ActionableBehaviour_Throwable_Grenade.BP_ActionableBehaviour_Throwable_Grenade_C
// Size: 0x471 (Inherited: 0x461)
struct UBP_ActionableBehaviour_Throwable_Grenade_C : UBP_ActionableBehaviour_Throwable_C {
	char pad_461[0x7]; // 0x461(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)
	bool IsPinPulled; // 0x470(0x01)

	void IsCharging(bool& Charging); // Function BP_ActionableBehaviour_Throwable_Grenade.BP_ActionableBehaviour_Throwable_Grenade_C.IsCharging // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void RequestThrow(); // Function BP_ActionableBehaviour_Throwable_Grenade.BP_ActionableBehaviour_Throwable_Grenade_C.RequestThrow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CanThrow(bool& CanThrow); // Function BP_ActionableBehaviour_Throwable_Grenade.BP_ActionableBehaviour_Throwable_Grenade_C.CanThrow // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void OnTraitAnimNotify(struct FAnimNotifyEvent& Notify, struct AActor* AnimInstancePawn); // Function BP_ActionableBehaviour_Throwable_Grenade.BP_ActionableBehaviour_Throwable_Grenade_C.OnTraitAnimNotify // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_ActionableBehaviour_Throwable_Grenade(int32_t EntryPoint); // Function BP_ActionableBehaviour_Throwable_Grenade.BP_ActionableBehaviour_Throwable_Grenade_C.ExecuteUbergraph_BP_ActionableBehaviour_Throwable_Grenade // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

