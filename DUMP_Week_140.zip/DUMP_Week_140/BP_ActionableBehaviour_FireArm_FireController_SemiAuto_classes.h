// BlueprintGeneratedClass BP_ActionableBehaviour_FireArm_FireController_SemiAuto.BP_ActionableBehaviour_FireArm_FireController_SemiAuto_C
// Size: 0xa6c (Inherited: 0xa6c)
struct UBP_ActionableBehaviour_FireArm_FireController_SemiAuto_C : UBP_ActionableBehaviour_FireArm_FireController_Base_C {

	void GetRefireRate(float& RefireRate); // Function BP_ActionableBehaviour_FireArm_FireController_SemiAuto.BP_ActionableBehaviour_FireArm_FireController_SemiAuto_C.GetRefireRate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
};

