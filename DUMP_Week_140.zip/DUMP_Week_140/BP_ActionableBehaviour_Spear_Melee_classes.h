// BlueprintGeneratedClass BP_ActionableBehaviour_Spear_Melee.BP_ActionableBehaviour_Spear_Melee_C
// Size: 0x3a0 (Inherited: 0x3a0)
struct UBP_ActionableBehaviour_Spear_Melee_C : UBP_ActionableBehaviour_Generic_Melee_C {
};

