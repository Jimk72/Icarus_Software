// BlueprintGeneratedClass BP_BaseRVT.BP_BaseRVT_C
// Size: 0x228 (Inherited: 0x228)
struct ABP_BaseRVT_C : ARuntimeVirtualTextureVolume {
};

