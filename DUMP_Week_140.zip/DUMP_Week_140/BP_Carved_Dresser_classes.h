// BlueprintGeneratedClass BP_Carved_Dresser.BP_Carved_Dresser_C
// Size: 0x77a (Inherited: 0x77a)
struct ABP_Carved_Dresser_C : ABP_DeployableContainerBase_C {
};

