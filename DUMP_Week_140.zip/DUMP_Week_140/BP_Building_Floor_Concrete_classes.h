// BlueprintGeneratedClass BP_Building_Floor_Concrete.BP_Building_Floor_Concrete_C
// Size: 0xbf0 (Inherited: 0xbe0)
struct ABP_Building_Floor_Concrete_C : ABP_Building_Floor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbe0(0x08)
	struct UBP_WeatherAudioComponent_Roof_C* BP_WeatherAudioComponent_Roof; // 0xbe8(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Floor_Concrete.BP_Building_Floor_Concrete_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Building_Floor_Concrete(int32_t EntryPoint); // Function BP_Building_Floor_Concrete.BP_Building_Floor_Concrete_C.ExecuteUbergraph_BP_Building_Floor_Concrete // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

