// BlueprintGeneratedClass BP_ActionableBehaviour_Mound_Deploy.BP_ActionableBehaviour_Mound_Deploy_C
// Size: 0xc62 (Inherited: 0xc62)
struct UBP_ActionableBehaviour_Mound_Deploy_C : UBP_ActionableBehaviour_DeployableBase_C {

	void OnDeploy(struct ADeployable* SpawnedDeployable); // Function BP_ActionableBehaviour_Mound_Deploy.BP_ActionableBehaviour_Mound_Deploy_C.OnDeploy // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

