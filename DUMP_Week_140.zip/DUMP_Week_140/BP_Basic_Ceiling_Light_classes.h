// BlueprintGeneratedClass BP_Basic_Ceiling_Light.BP_Basic_Ceiling_Light_C
// Size: 0x818 (Inherited: 0x80c)
struct ABP_Basic_Ceiling_Light_C : ABP_Light_Electric_Base_C {
	char pad_80C[0x4]; // 0x80c(0x04)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x810(0x08)
};

