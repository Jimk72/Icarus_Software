// BlueprintGeneratedClass BP_CriticalHitComponent.BP_CriticalHitComponent_C
// Size: 0x21a (Inherited: 0xb0)
struct UBP_CriticalHitComponent_C : UIcarusCriticalHitComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FTimerHandle ResetTimer; // 0xb8(0x08)
	enum class ECriticalHitStage CurrentStage; // 0xc0(0x01)
	bool HomingMissile; // 0xc1(0x01)
	bool CHRotationLocked; // 0xc2(0x01)
	char pad_C3[0x1]; // 0xc3(0x01)
	struct FVector CachedTargetLocation; // 0xc4(0x0c)
	float CHTargetRotation; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct FCriticalHitSetup CurrentCriticalHitConfig; // 0xd8(0xb0)
	struct UMatineeCameraShake* ProjectileShake; // 0x188(0x08)
	bool ProjStopped; // 0x190(0x01)
	char pad_191[0x3]; // 0x191(0x03)
	float DebugLength; // 0x194(0x04)
	float LuckyBuffer; // 0x198(0x04)
	bool Debug; // 0x19c(0x01)
	bool IgnoreDamage; // 0x19d(0x01)
	char pad_19E[0x2]; // 0x19e(0x02)
	float TargetTimestamp; // 0x1a0(0x04)
	float TransitionSpeed; // 0x1a4(0x04)
	float ProjectileBaseDamage; // 0x1a8(0x04)
	char pad_1AC[0x4]; // 0x1ac(0x04)
	struct AActor* Projectile; // 0x1b0(0x08)
	struct FRotator FacingTargetRotation; // 0x1b8(0x0c)
	bool ProjMissed; // 0x1c4(0x01)
	bool CanUseKillCamAudio; // 0x1c5(0x01)
	bool KillCamAudioApplied; // 0x1c6(0x01)
	char pad_1C7[0x1]; // 0x1c7(0x01)
	struct UFMODEvent* KillCamAudioEvent; // 0x1c8(0x08)
	struct FFMODEventInstance KillCamAudioEventInstance; // 0x1d0(0x08)
	struct FVector TrackingTargetLocation; // 0x1d8(0x0c)
	struct FRotator CachedProjectileRotation; // 0x1e4(0x0c)
	struct FVector CachedProjectileLocation; // 0x1f0(0x0c)
	float TargetFOV; // 0x1fc(0x04)
	float LastProjectileDistance; // 0x200(0x04)
	char pad_204[0x4]; // 0x204(0x04)
	struct AActor* CriticalHitData_Projectile; // 0x208(0x08)
	struct AActor* CriticalHitData_Target; // 0x210(0x08)
	bool KillCamRunning; // 0x218(0x01)
	bool KillcamEnabled; // 0x219(0x01)

	void UpdateCamera(struct FVector InLocation, struct FRotator InRotation, float InFOV, bool ForceUpdate, struct FVector& OutLocation, struct FRotator& OutRotation, float& OutFOV, bool& Return); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateCamera // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool GetIgnoreDamage(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetIgnoreDamage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	bool GetDebug(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetDebug // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	float GetLuckyBuffer(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetLuckyBuffer // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fcdea0
	void OnRep_KillcamEnabled(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.OnRep_KillcamEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateCriticalHitData(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateCriticalHitData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_CriticalHitData_Target(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.OnRep_CriticalHitData_Target // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_CriticalHitData_Projectile(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.OnRep_CriticalHitData_Projectile // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	bool ProjectileToTargetCheck(bool& Force); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ProjectileToTargetCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateTargetFOV(bool Zoom, float ZoomSpeed); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateTargetFOV // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateTargetRotation(bool Rotate, float RotateSpeed); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateTargetRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateTrackingLocation(struct FVector InLocation, float SmoothingSpeed); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateTrackingLocation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void UpdateFacingRotation(struct FVector Start, struct FVector End, float SmoothingSpeed); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateFacingRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	struct FVector GetCriticalLocationOnTarget(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetCriticalLocationOnTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	struct FVector GetTargetCentreLocation(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetTargetCentreLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void UpdateAudio(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.UpdateAudio // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ResetVariables(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ResetVariables // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ProjectileStopped(struct AActor* Projectile, struct AActor* HitActor); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ProjectileStopped // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CancelCriticalHit(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CancelCriticalHit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SwitchToTarget(bool ServerTriggered); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SwitchToTarget // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetTimeScale(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SetTimeScale // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CheckCameraShake(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CheckCameraShake // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CriticalHitSpringArm(float SpringArmYaw, struct FVector TargetLocation, struct FVector PivotOffset, struct FVector CameraOffset, struct FRotator CameraRotationOffset, struct FVector& Location, struct FRotator& Rotation); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CriticalHitSpringArm // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CalculateTargetCamera(struct FCriticalHitSetup Config, struct FVector Location, struct FRotator Rotation, struct FVector& OutLocation, struct FRotator& OutRotation, float& OutFOV); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CalculateTargetCamera // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CalculateProjectileCamera(struct FCriticalHitSetup Config, struct AActor* Projectile, struct FVector& OutLocation, struct FRotator& OutRotation, float& OutFOV); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CalculateProjectileCamera // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void CalculatePlayerCamera(struct FCriticalHitSetup Config, struct AActor* Player, struct FVector& OutLocation, struct FRotator& OutRotation, float& OutFOV); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CalculatePlayerCamera // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetTimeScale(float& TimeScale); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetTimeScale // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void CriticalHitActive(bool& Active); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CriticalHitActive // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void ProcessCriticalHit(struct FPredictProjectilePathParams ProjectilePrediction, struct AActor* Projectile, bool& CriticalHit, struct AActor*& Target); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ProcessCriticalHit // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SwitchToProjectile(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SwitchToProjectile // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SwitchToPlayer(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SwitchToPlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnRep_CriticalHitData(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.OnRep_CriticalHitData // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetProjectile(struct AActor*& Projectile); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetProjectile // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void GetTarget(struct AActor*& Target); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.GetTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
	void SERVER_CancelCriticalHit(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SERVER_CancelCriticalHit // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveTick(float DeltaSeconds); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void CLIENT_SwitchStage(enum class ECriticalHitStage Stage); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.CLIENT_SwitchStage // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnKillcamEnabledApplied(bool Value); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.OnKillcamEnabledApplied // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SERVER_SetKillcamEnabled(bool Enabled); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SERVER_SetKillcamEnabled // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SetupKillcamSetting(); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SetupKillcamSetting // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BP_SetIgnoreDamage(bool bIgnore); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.BP_SetIgnoreDamage // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void BP_SetLuckyBuffer(float NewLuckyBuffer); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.BP_SetLuckyBuffer // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void BP_SetDebug(bool bDebug); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.BP_SetDebug // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void SetCriticalHitConfig(struct FName& Name); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.SetCriticalHitConfig // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_CriticalHitComponent(int32_t EntryPoint); // Function BP_CriticalHitComponent.BP_CriticalHitComponent_C.ExecuteUbergraph_BP_CriticalHitComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

