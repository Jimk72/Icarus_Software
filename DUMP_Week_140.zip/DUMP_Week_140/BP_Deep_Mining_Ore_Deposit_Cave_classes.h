// BlueprintGeneratedClass BP_Deep_Mining_Ore_Deposit_Cave.BP_Deep_Mining_Ore_Deposit_Cave_C
// Size: 0x3f0 (Inherited: 0x3f0)
struct ABP_Deep_Mining_Ore_Deposit_Cave_C : ABP_Deep_Mining_Ore_Deposit_C {
};

