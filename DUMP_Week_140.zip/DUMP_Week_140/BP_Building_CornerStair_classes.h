// BlueprintGeneratedClass BP_Building_CornerStair.BP_Building_CornerStair_C
// Size: 0xc60 (Inherited: 0xc60)
struct ABP_Building_CornerStair_C : ABP_Building_Frame_C {
};

