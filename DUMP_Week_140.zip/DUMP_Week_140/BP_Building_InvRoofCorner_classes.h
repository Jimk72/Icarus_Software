// BlueprintGeneratedClass BP_Building_InvRoofCorner.BP_Building_InvRoofCorner_C
// Size: 0xbe0 (Inherited: 0xbe0)
struct ABP_Building_InvRoofCorner_C : ABP_Building_Ramp_C {
};

