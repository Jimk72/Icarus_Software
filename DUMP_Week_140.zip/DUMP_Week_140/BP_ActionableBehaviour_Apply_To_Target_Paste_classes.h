// BlueprintGeneratedClass BP_ActionableBehaviour_Apply_To_Target_Paste.BP_ActionableBehaviour_Apply_To_Target_Paste_C
// Size: 0x380 (Inherited: 0x380)
struct UBP_ActionableBehaviour_Apply_To_Target_Paste_C : UBP_ActionableBehaviour_Apply_To_Target_C {
};

