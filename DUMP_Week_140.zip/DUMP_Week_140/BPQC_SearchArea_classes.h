// BlueprintGeneratedClass BPQC_SearchArea.BPQC_SearchArea_C
// Size: 0xf8 (Inherited: 0xb0)
struct UBPQC_SearchArea_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct FMapSearchAreaRowHandle SearchArea; // 0xb8(0x18)
	struct UUMG_RadarSquare_C* Widget; // 0xd0(0x08)
	bool bAutoAdd; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	int32_t Radius; // 0xdc(0x04)
	struct UIcarusMapIconComponent* ParentIcon; // 0xe0(0x08)
	struct FLinearColor SearchAreaColor; // 0xe8(0x10)

	void AttemptInitialise(); // Function BPQC_SearchArea.BPQC_SearchArea_C.AttemptInitialise // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BPQC_SearchArea.BPQC_SearchArea_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void AddSearchArea(struct FMapSearchAreaRowHandle SearchArea, int32_t Radius); // Function BPQC_SearchArea.BPQC_SearchArea_C.AddSearchArea // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void RemoveSearchArea(); // Function BPQC_SearchArea.BPQC_SearchArea_C.RemoveSearchArea // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BPQC_SearchArea.BPQC_SearchArea_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BPQC_SearchArea(int32_t EntryPoint); // Function BPQC_SearchArea.BPQC_SearchArea_C.ExecuteUbergraph_BPQC_SearchArea // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

