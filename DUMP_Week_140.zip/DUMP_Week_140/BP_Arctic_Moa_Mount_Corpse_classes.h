// BlueprintGeneratedClass BP_Arctic_Moa_Mount_Corpse.BP_Arctic_Moa_Mount_Corpse_C
// Size: 0x790 (Inherited: 0x788)
struct ABP_Arctic_Moa_Mount_Corpse_C : ABP_GOAP_Corpse_Mount_C {
	struct UGFurComponent* GFur; // 0x788(0x08)

	void OnSkinnedStateUpdated(); // Function BP_Arctic_Moa_Mount_Corpse.BP_Arctic_Moa_Mount_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

