// BlueprintGeneratedClass BP_Breakable_Obsidian_Var1.BP_Breakable_Obsidian_Var1_C
// Size: 0x438 (Inherited: 0x400)
struct ABP_Breakable_Obsidian_Var1_C : ABP_Breakable_Rock_Base_C {
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_07; // 0x400(0x08)
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_06; // 0x408(0x08)
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_05; // 0x410(0x08)
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_04; // 0x418(0x08)
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_03; // 0x420(0x08)
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_02; // 0x428(0x08)
	struct UStaticMeshComponent* SM_Breakable_Obsidian_Var1_01; // 0x430(0x08)
};

