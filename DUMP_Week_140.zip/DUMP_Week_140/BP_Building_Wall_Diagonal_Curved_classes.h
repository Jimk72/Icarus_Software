// BlueprintGeneratedClass BP_Building_Wall_Diagonal_Curved.BP_Building_Wall_Diagonal_Curved_C
// Size: 0xbd0 (Inherited: 0xbd0)
struct ABP_Building_Wall_Diagonal_Curved_C : ABP_Building_Wall_Diagonal_C {

	void GetBlockingBypass(struct ABP_Building_Base_C* BuildingClass, struct TArray<struct FVectorPair>& BlockingPreRotate, struct FTransform GridSpaceTransform, struct TArray<struct FVectorPair>& BypassBlocking); // Function BP_Building_Wall_Diagonal_Curved.BP_Building_Wall_Diagonal_Curved_C.GetBlockingBypass // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

