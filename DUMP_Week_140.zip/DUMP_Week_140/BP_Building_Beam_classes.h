// BlueprintGeneratedClass BP_Building_Beam.BP_Building_Beam_C
// Size: 0xc68 (Inherited: 0xc60)
struct ABP_Building_Beam_C : ABP_Building_Frame_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc60(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Beam.BP_Building_Beam_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Building_Beam(int32_t EntryPoint); // Function BP_Building_Beam.BP_Building_Beam_C.ExecuteUbergraph_BP_Building_Beam // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

