// BlueprintGeneratedClass BP_Advanced_Kitchen_Corner.BP_Advanced_Kitchen_Corner_C
// Size: 0x790 (Inherited: 0x77a)
struct ABP_Advanced_Kitchen_Corner_C : ABP_DeployableContainerBase_C {
	char pad_77A[0x6]; // 0x77a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x780(0x08)
	struct UAudioOcclusionComponent* AudioOcclusion1; // 0x788(0x08)

	void OnBecomeInteractedWith(); // Function BP_Advanced_Kitchen_Corner.BP_Advanced_Kitchen_Corner_C.OnBecomeInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnNoLongerInteractedWith(); // Function BP_Advanced_Kitchen_Corner.BP_Advanced_Kitchen_Corner_C.OnNoLongerInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Advanced_Kitchen_Corner(int32_t EntryPoint); // Function BP_Advanced_Kitchen_Corner.BP_Advanced_Kitchen_Corner_C.ExecuteUbergraph_BP_Advanced_Kitchen_Corner // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

