// BlueprintGeneratedClass BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C
// Size: 0x358 (Inherited: 0x30a)
struct UBP_Actionable_FireExtinguisher_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* OwningPlayer; // 0x318(0x08)
	struct AActor* OwningActor; // 0x320(0x08)
	struct ABP_SkeletalItem_FireExtinguisher_C* ExtinguisherSKItem; // 0x328(0x08)
	bool DoFire; // 0x330(0x01)
	char pad_331[0x7]; // 0x331(0x07)
	struct UFMODAudioComponent* FMOD_Audio_Component; // 0x338(0x08)
	struct UFMODEvent* ExtinguishSound; // 0x340(0x08)
	struct TArray<struct UObject*> StoredMontages; // 0x348(0x10)

	void IsFiring(bool& Firing); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.IsFiring // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ProcessDurability(int32_t DurabilityLoss); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.ProcessDurability // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	int32_t GetStatAdjustedDurability(int32_t DurabilityLoss); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.GetStatAdjustedDurability // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void TickTimer(); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.TickTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void SphereTrace(); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.SphereTrace // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void Setup(struct AActor* OwningActor); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnLoaded_2B8B2B624CE5F97DAE6892B79C537CC2(struct UObject* Loaded); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.OnLoaded_2B8B2B624CE5F97DAE6892B79C537CC2 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ReceiveBeginPlay(); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void Multi_SpawnFX(struct FVector ImpactPoint, struct FVector ImpactNormal); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.Multi_SpawnFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Actionable_FireExtinguisher(int32_t EntryPoint); // Function BP_Actionable_FireExtinguisher.BP_Actionable_FireExtinguisher_C.ExecuteUbergraph_BP_Actionable_FireExtinguisher // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

