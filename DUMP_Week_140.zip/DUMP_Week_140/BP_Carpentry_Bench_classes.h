// BlueprintGeneratedClass BP_Carpentry_Bench.BP_Carpentry_Bench_C
// Size: 0x9c8 (Inherited: 0x9c0)
struct ABP_Carpentry_Bench_C : ABP_ProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9c0(0x08)

	void ReceiveBeginPlay(); // Function BP_Carpentry_Bench.BP_Carpentry_Bench_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Carpentry_Bench(int32_t EntryPoint); // Function BP_Carpentry_Bench.BP_Carpentry_Bench_C.ExecuteUbergraph_BP_Carpentry_Bench // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

