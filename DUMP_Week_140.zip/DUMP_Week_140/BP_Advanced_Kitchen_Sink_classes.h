// BlueprintGeneratedClass BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C
// Size: 0x798 (Inherited: 0x77a)
struct ABP_Advanced_Kitchen_Sink_C : ABP_DeployableContainerBase_C {
	char pad_77A[0x6]; // 0x77a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x780(0x08)
	struct UAudioOcclusionComponent* AudioOcclusion1; // 0x788(0x08)
	int32_t ContainerFillUnitsPerSecond; // 0x790(0x04)
	float ContainerFillTickRate; // 0x794(0x04)

	void TryAddWaterToContainers(); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.TryAddWaterToContainers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnBecomeInteractedWith(); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.OnBecomeInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void OnNoLongerInteractedWith(); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.OnNoLongerInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void DeployableTick(float DeltaSeconds); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void IcarusBeginPlay(); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fcdea0
	void ContainerFillTimerTick(); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.ContainerFillTimerTick // (BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Advanced_Kitchen_Sink(int32_t EntryPoint); // Function BP_Advanced_Kitchen_Sink.BP_Advanced_Kitchen_Sink_C.ExecuteUbergraph_BP_Advanced_Kitchen_Sink // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fcdea0
};

