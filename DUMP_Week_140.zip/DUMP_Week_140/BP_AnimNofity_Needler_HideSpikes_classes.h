// BlueprintGeneratedClass BP_AnimNofity_Needler_HideSpikes.BP_AnimNofity_Needler_HideSpikes_C
// Size: 0x38 (Inherited: 0x38)
struct UBP_AnimNofity_Needler_HideSpikes_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimNofity_Needler_HideSpikes.BP_AnimNofity_Needler_HideSpikes_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fcdea0
	struct FString GetNotifyName(); // Function BP_AnimNofity_Needler_HideSpikes.BP_AnimNofity_Needler_HideSpikes_C.GetNotifyName // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fcdea0
};

