// BlueprintGeneratedClass BPI_GenericAction.BPI_GenericAction_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_GenericAction_C : UInterface {

	void GenericActionWithCharacter(struct AIcarusPlayerCharacter* Character); // Function BPI_GenericAction.BPI_GenericAction_C.GenericActionWithCharacter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GenericAction(); // Function BPI_GenericAction.BPI_GenericAction_C.GenericAction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

