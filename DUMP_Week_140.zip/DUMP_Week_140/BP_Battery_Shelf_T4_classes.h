// BlueprintGeneratedClass BP_Battery_Shelf_T4.BP_Battery_Shelf_T4_C
// Size: 0x770 (Inherited: 0x761)
struct ABP_Battery_Shelf_T4_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)

	void ReceiveBeginPlay(); // Function BP_Battery_Shelf_T4.BP_Battery_Shelf_T4_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Battery_Shelf_T4(int32_t EntryPoint); // Function BP_Battery_Shelf_T4.BP_Battery_Shelf_T4_C.ExecuteUbergraph_BP_Battery_Shelf_T4 // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

