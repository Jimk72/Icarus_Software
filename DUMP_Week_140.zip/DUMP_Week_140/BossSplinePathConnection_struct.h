// UserDefinedStruct BossSplinePathConnection.BossSplinePathConnection
// Size: 0x14 (Inherited: 0x00)
struct FBossSplinePathConnection {
	int32_t StartingSplinePoint_12_696F47B44DD4F46EA29638935C3E0CF8; // 0x00(0x04)
	bool ForwardDirection_1_291F8B9F4ABAB3BFD372579F95F4B71C; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FName OtherSplineActorTag_14_8117D52E446C2E40A1DDF6866B6155FB; // 0x08(0x08)
	float OtherSplineInputKey_8_2D8270EF4B0BAEB62DBDE18146A76354; // 0x10(0x04)
};

