// BlueprintGeneratedClass BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_LightSlotAttachInfoProvider_C : UInterface {

	void UpdateCurrentOffset(struct FVector NewOffset); // Function BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C.UpdateCurrentOffset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetAttachmentOffset(struct FTransform& ThirdPersonActorOffset, struct FTransform& FirstPersonActorOffset, struct FVector& ThirdPersonComponentOffset); // Function BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C.GetAttachmentOffset // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetThirdPersonOnlyComponents(struct TArray<struct UPrimitiveComponent*>& OutComponents); // Function BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C.GetThirdPersonOnlyComponents // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetComponentToOffset(struct USceneComponent*& Component); // Function BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C.GetComponentToOffset // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void GetLightSlotAttachPoint(enum class LightSlotAttachPoint& AttachPoint); // Function BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C.GetLightSlotAttachPoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

