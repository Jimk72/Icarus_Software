// AnimBlueprintGeneratedClass Anim_VehicleLayerInterface.Anim_VehicleLayerInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UAnim_VehicleLayerInterface_C : UAnimLayerInterface {

	void VehicleUpperBody(struct FPoseLink UpperInPose, struct FPoseLink& VehicleUpperBody); // Function Anim_VehicleLayerInterface.Anim_VehicleLayerInterface_C.VehicleUpperBody // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void VehicleLowerBody(struct FPoseLink LowerInPose, struct FPoseLink& VehicleLowerBody); // Function Anim_VehicleLayerInterface.Anim_VehicleLayerInterface_C.VehicleLowerBody // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
};

