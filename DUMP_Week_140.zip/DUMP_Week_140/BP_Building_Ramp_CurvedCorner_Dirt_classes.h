// BlueprintGeneratedClass BP_Building_Ramp_CurvedCorner_Dirt.BP_Building_Ramp_CurvedCorner_Dirt_C
// Size: 0xbd0 (Inherited: 0xbd0)
struct ABP_Building_Ramp_CurvedCorner_Dirt_C : ABP_Building_Ramp_Diagonal_Curved_C {

	void Calculate Stability State Implementation(); // Function BP_Building_Ramp_CurvedCorner_Dirt.BP_Building_Ramp_CurvedCorner_Dirt_C.Calculate Stability State Implementation // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1fcdea0
	void BuildingStabilityColorCalc(struct FLinearColor& StabilityColor); // Function BP_Building_Ramp_CurvedCorner_Dirt.BP_Building_Ramp_CurvedCorner_Dirt_C.BuildingStabilityColorCalc // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fcdea0
};

