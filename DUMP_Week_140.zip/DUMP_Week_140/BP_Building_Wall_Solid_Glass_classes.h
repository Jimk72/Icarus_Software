// BlueprintGeneratedClass BP_Building_Wall_Solid_Glass.BP_Building_Wall_Solid_Glass_C
// Size: 0xbe0 (Inherited: 0xbd8)
struct ABP_Building_Wall_Solid_Glass_C : ABP_Building_Wall_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd8(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Wall_Solid_Glass.BP_Building_Wall_Solid_Glass_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fcdea0
	void ExecuteUbergraph_BP_Building_Wall_Solid_Glass(int32_t EntryPoint); // Function BP_Building_Wall_Solid_Glass.BP_Building_Wall_Solid_Glass_C.ExecuteUbergraph_BP_Building_Wall_Solid_Glass // (Final|UbergraphFunction) // @ game+0x1fcdea0
};

