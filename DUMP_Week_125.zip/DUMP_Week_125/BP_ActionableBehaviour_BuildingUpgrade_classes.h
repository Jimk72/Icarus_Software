// BlueprintGeneratedClass BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C
// Size: 0x340 (Inherited: 0x328)
struct UBP_ActionableBehaviour_BuildingUpgrade_C : UBP_ActionableBehaviour_Radial_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x328(0x08)
	enum class EBuildingResourceType SelectedResource; // 0x330(0x01)
	char pad_331[0x3]; // 0x331(0x03)
	float TraceDistance; // 0x334(0x04)
	struct ABP_Building_Base_C* LastBuildingHit; // 0x338(0x08)

	void PlaySwing(struct AIcarusPlayerCharacterSurvival* TargetPlayer); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.PlaySwing // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetHitFromViewTraces(struct FHitResult& OutHit); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.GetHitFromViewTraces // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetHitFromCamera(struct FHitResult& OutHit); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.GetHitFromCamera // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetContextMenuItems(struct TArray<struct FContextMenuItemData>& MenuItems); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.GetContextMenuItems // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReplaceBuilding(struct ABP_Building_Base_C* BuildingToReplace, enum class EBuildingResourceType ResourceType); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.ReplaceBuilding // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SwapBuilding(struct ABP_Building_Base_C* HitBuilding, enum class EBuildingResourceType ReplaceMentResrouce); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.SwapBuilding // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void MenuItemSelected(struct FName ItemIdentifier, int32_t ItemPayload); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.MenuItemSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void PlaySwingAnimation(struct AIcarusPlayerCharacterSurvival* Player); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.PlaySwingAnimation // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_ActionableBehaviour_BuildingUpgrade(int32_t EntryPoint); // Function BP_ActionableBehaviour_BuildingUpgrade.BP_ActionableBehaviour_BuildingUpgrade_C.ExecuteUbergraph_BP_ActionableBehaviour_BuildingUpgrade // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

