// BlueprintGeneratedClass BP_Alpha_Sandworm_Statue_Bronze.BP_Alpha_Sandworm_Statue_Bronze_C
// Size: 0x770 (Inherited: 0x761)
struct ABP_Alpha_Sandworm_Statue_Bronze_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)

	void ReceiveBeginPlay(); // Function BP_Alpha_Sandworm_Statue_Bronze.BP_Alpha_Sandworm_Statue_Bronze_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Alpha_Sandworm_Statue_Bronze(int32_t EntryPoint); // Function BP_Alpha_Sandworm_Statue_Bronze.BP_Alpha_Sandworm_Statue_Bronze_C.ExecuteUbergraph_BP_Alpha_Sandworm_Statue_Bronze // (Final|UbergraphFunction) // @ game+0x1fb3630
};

