// BlueprintGeneratedClass BP_Bed_Carved_A.BP_Bed_Carved_A_C
// Size: 0x7b0 (Inherited: 0x7b0)
struct ABP_Bed_Carved_A_C : ABP_Bed_Wood_C {
};

