// BlueprintGeneratedClass BP_Crocodile_Corpse.BP_Crocodile_Corpse_C
// Size: 0x780 (Inherited: 0x780)
struct ABP_Crocodile_Corpse_C : ABP_GOAP_Corpse_C {
};

