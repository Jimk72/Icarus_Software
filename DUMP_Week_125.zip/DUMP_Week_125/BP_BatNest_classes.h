// BlueprintGeneratedClass BP_BatNest.BP_BatNest_C
// Size: 0x458 (Inherited: 0x330)
struct ABP_BatNest_C : ABP_ContainerBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x330(0x08)
	struct UDestructibleComponent* DestructibleMesh; // 0x338(0x08)
	struct UNiagaraComponent* Smoke; // 0x340(0x08)
	struct UPointLightComponent* PointLight; // 0x348(0x08)
	struct USceneComponent* Attach_010; // 0x350(0x08)
	struct USceneComponent* Attach_09; // 0x358(0x08)
	struct USceneComponent* Attach_08; // 0x360(0x08)
	struct USceneComponent* Attach_07; // 0x368(0x08)
	struct USceneComponent* Attach_06; // 0x370(0x08)
	struct USceneComponent* Attach_05; // 0x378(0x08)
	struct USceneComponent* Attach_04; // 0x380(0x08)
	struct USceneComponent* Attach_03; // 0x388(0x08)
	struct USceneComponent* Attach_02; // 0x390(0x08)
	struct USceneComponent* Attach_01; // 0x398(0x08)
	struct USceneComponent* AttachPoints; // 0x3a0(0x08)
	struct USceneComponent* SpawnLocation; // 0x3a8(0x08)
	float Emissive_Intensity_Emission_Brightness_528BA2B14842961B15D9B3B3AEADC802; // 0x3b0(0x04)
	enum class ETimelineDirection Emissive_Intensity__Direction_528BA2B14842961B15D9B3B3AEADC802; // 0x3b4(0x01)
	char pad_3B5[0x3]; // 0x3b5(0x03)
	struct UTimelineComponent* Emissive_Intensity; // 0x3b8(0x08)
	float Light_Intensity_Emission_Brightness_421BABE64270D0A7266544BF81269576; // 0x3c0(0x04)
	enum class ETimelineDirection Light_Intensity__Direction_421BABE64270D0A7266544BF81269576; // 0x3c4(0x01)
	char pad_3C5[0x3]; // 0x3c5(0x03)
	struct UTimelineComponent* Light_Intensity; // 0x3c8(0x08)
	struct FRandomStream RandomStream; // 0x3d0(0x08)
	int32_t NumToSpawn; // 0x3d8(0x04)
	bool HasBeenDestroyed; // 0x3dc(0x01)
	char pad_3DD[0x3]; // 0x3dd(0x03)
	int32_t InitialSpawnCount; // 0x3e0(0x04)
	char pad_3E4[0x4]; // 0x3e4(0x04)
	struct TArray<struct AActor*> SpawnedBats; // 0x3e8(0x10)
	struct FTimerHandle AdditionalSpawnTimer; // 0x3f8(0x08)
	struct FName NestBlackboardKey; // 0x400(0x08)
	struct FName AggressiveBlackboardKey; // 0x408(0x08)
	struct FAISetupRowHandle SpawnBatType; // 0x410(0x18)
	struct UStaticMesh* Destroyed Mesh State; // 0x428(0x08)
	struct UDestructibleComponent* DM CRE Bat Nest Cave DES DM; // 0x430(0x08)
	struct UDestructibleMesh* DestrucibleMesh; // 0x438(0x08)
	struct FTimerHandle CheckPlayersNearbyTimer; // 0x440(0x08)
	struct TArray<struct USceneComponent*> InitialSpawnPoints; // 0x448(0x10)

	void NotifyCaveAISpawned(struct AActor* NewActor); // Function BP_BatNest.BP_BatNest_C.NotifyCaveAISpawned // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnSpawnedBatEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function BP_BatNest.BP_BatNest_C.OnSpawnedBatEndPlay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_HasBeenDestroyed(); // Function BP_BatNest.BP_BatNest_C.OnRep_HasBeenDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Emissive_Intensity__FinishedFunc(); // Function BP_BatNest.BP_BatNest_C.Emissive_Intensity__FinishedFunc // (BlueprintEvent) // @ game+0x1fb3630
	void Emissive_Intensity__UpdateFunc(); // Function BP_BatNest.BP_BatNest_C.Emissive_Intensity__UpdateFunc // (BlueprintEvent) // @ game+0x1fb3630
	void Light_Intensity__FinishedFunc(); // Function BP_BatNest.BP_BatNest_C.Light_Intensity__FinishedFunc // (BlueprintEvent) // @ game+0x1fb3630
	void Light_Intensity__UpdateFunc(); // Function BP_BatNest.BP_BatNest_C.Light_Intensity__UpdateFunc // (BlueprintEvent) // @ game+0x1fb3630
	void StartSpawning(); // Function BP_BatNest.BP_BatNest_C.StartSpawning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnActorDeath_Event(struct UActorState* ActorState); // Function BP_BatNest.BP_BatNest_C.OnActorDeath_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnDestroyedFX(); // Function BP_BatNest.BP_BatNest_C.OnDestroyedFX // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_BatNest.BP_BatNest_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void SpawnBat(struct FVector& Location, struct FRotator Rotation, bool StartAggressive); // Function BP_BatNest.BP_BatNest_C.SpawnBat // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_BatNest.BP_BatNest_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void TrySpawnAdditionalBats(); // Function BP_BatNest.BP_BatNest_C.TrySpawnAdditionalBats // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void StopSpawning(); // Function BP_BatNest.BP_BatNest_C.StopSpawning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CheckPlayersNearby(); // Function BP_BatNest.BP_BatNest_C.CheckPlayersNearby // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SpawnVisuals(); // Function BP_BatNest.BP_BatNest_C.SpawnVisuals // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_BatNest(int32_t EntryPoint); // Function BP_BatNest.BP_BatNest_C.ExecuteUbergraph_BP_BatNest // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

