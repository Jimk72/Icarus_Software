// BlueprintGeneratedClass BP_Bait.BP_Bait_C
// Size: 0x778 (Inherited: 0x761)
struct ABP_Bait_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct UFMODAudioComponent* FlyAudio; // 0x768(0x08)
	struct UNiagaraComponent* NS_Flies1; // 0x770(0x08)
};

