// BlueprintGeneratedClass BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_LightSlotAttachInfoProvider_C : UInterface {

	void GetLightSlotAttachPoint(enum class LightSlotAttachPoint& AttachPoint); // Function BPI_LightSlotAttachInfoProvider.BPI_LightSlotAttachInfoProvider_C.GetLightSlotAttachPoint // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

