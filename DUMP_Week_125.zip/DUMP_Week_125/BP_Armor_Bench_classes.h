// BlueprintGeneratedClass BP_Armor_Bench.BP_Armor_Bench_C
// Size: 0x9f8 (Inherited: 0x9c0)
struct ABP_Armor_Bench_C : ABP_ProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9c0(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Textile_Proxy_Fur_Head; // 0x9c8(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Textile_Proxy_Fur_Chest; // 0x9d0(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Textile_Proxy_Cloth; // 0x9d8(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Textile_Proxy_Rope; // 0x9e0(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Textile_Proxy_Leather; // 0x9e8(0x08)
	struct UStaticMeshComponent* SM_DEP_Bench_Textile_Proxy_Fur; // 0x9f0(0x08)

	void UserConstructionScript(); // Function BP_Armor_Bench.BP_Armor_Bench_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_Armor_Bench.BP_Armor_Bench_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Armor_Bench(int32_t EntryPoint); // Function BP_Armor_Bench.BP_Armor_Bench_C.ExecuteUbergraph_BP_Armor_Bench // (Final|UbergraphFunction) // @ game+0x1fb3630
};

