// BlueprintGeneratedClass BP_Campfire.BP_Campfire_C
// Size: 0xa90 (Inherited: 0x9f0)
struct ABP_Campfire_C : ABP_FireProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9f0(0x08)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight_Large; // 0x9f8(0x08)
	struct USphereComponent* NavBlockingSphere; // 0xa00(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Cooking_Stick; // 0xa08(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Cooking_Meat_Proxy; // 0xa10(0x08)
	struct UNiagaraComponent* CampfireFX; // 0xa18(0x08)
	struct USceneComponent* Scene_Niagara; // 0xa20(0x08)
	struct UPointLightComponent* PointLight_Bloom; // 0xa28(0x08)
	struct USceneComponent* Scene_Lights; // 0xa30(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Cooked_Full; // 0xa38(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Cooked_Med; // 0xa40(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Cooked_Low; // 0xa48(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Sticks_Full; // 0xa50(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Sticks_Low; // 0xa58(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Wood_Full; // 0xa60(0x08)
	struct UStaticMeshComponent* SM_DEP_Campfire_Wood_Low; // 0xa68(0x08)
	struct USceneComponent* RawMeat; // 0xa70(0x08)
	struct USceneComponent* CookedMeats; // 0xa78(0x08)
	struct USceneComponent* FuelSources; // 0xa80(0x08)
	struct UCapsuleComponent* FireSettingCapsule; // 0xa88(0x08)

	void UpdateEffects(bool Active); // Function BP_Campfire.BP_Campfire_C.UpdateEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UserConstructionScript(); // Function BP_Campfire.BP_Campfire_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Snow(float Intensity); // Function BP_Campfire.BP_Campfire_C.Snow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DeactivateCampfire(); // Function BP_Campfire.BP_Campfire_C.DeactivateCampfire // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Rain(int32_t Millilitres); // Function BP_Campfire.BP_Campfire_C.Rain // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_Campfire.BP_Campfire_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnThermalComponentActivated(struct UActorComponent* Component, bool bReset); // Function BP_Campfire.BP_Campfire_C.OnThermalComponentActivated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnThermalComponentDeactivated(struct UActorComponent* Component); // Function BP_Campfire.BP_Campfire_C.OnThermalComponentDeactivated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Campfire(int32_t EntryPoint); // Function BP_Campfire.BP_Campfire_C.ExecuteUbergraph_BP_Campfire // (Final|UbergraphFunction) // @ game+0x1fb3630
};

