// BlueprintGeneratedClass BP_Bait_Poisoned.BP_Bait_Poisoned_C
// Size: 0x780 (Inherited: 0x761)
struct ABP_Bait_Poisoned_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct UParticleSystemComponent* P_Smoke_Poison; // 0x768(0x08)
	struct UFMODAudioComponent* FlyAudio; // 0x770(0x08)
	struct UNiagaraComponent* NS_Flies1; // 0x778(0x08)

	void GetModifierToApplyOnConsume(struct FModifierStatesRowHandle& Modifier, float& LifeTime); // Function BP_Bait_Poisoned.BP_Bait_Poisoned_C.GetModifierToApplyOnConsume // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

