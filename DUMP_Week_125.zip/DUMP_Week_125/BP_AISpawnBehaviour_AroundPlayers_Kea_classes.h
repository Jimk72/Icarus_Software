// BlueprintGeneratedClass BP_AISpawnBehaviour_AroundPlayers_Kea.BP_AISpawnBehaviour_AroundPlayers_Kea_C
// Size: 0x151 (Inherited: 0x148)
struct UBP_AISpawnBehaviour_AroundPlayers_Kea_C : UBP_AISpawnBehaviour_AroundPlayers_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x148(0x08)
	bool SpawnFlying; // 0x150(0x01)

	bool FindValidSpawnLocationInsideTree(struct AActor* AroundActor, struct FVector& SpawnLocation); // Function BP_AISpawnBehaviour_AroundPlayers_Kea.BP_AISpawnBehaviour_AroundPlayers_Kea_C.FindValidSpawnLocationInsideTree // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TrySpawnAsync(struct AActor* AroundPlayer); // Function BP_AISpawnBehaviour_AroundPlayers_Kea.BP_AISpawnBehaviour_AroundPlayers_Kea_C.TrySpawnAsync // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DoSpawn(struct UObject* Context, struct FVector SpawnLocation); // Function BP_AISpawnBehaviour_AroundPlayers_Kea.BP_AISpawnBehaviour_AroundPlayers_Kea_C.DoSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_AISpawnBehaviour_AroundPlayers_Kea(int32_t EntryPoint); // Function BP_AISpawnBehaviour_AroundPlayers_Kea.BP_AISpawnBehaviour_AroundPlayers_Kea_C.ExecuteUbergraph_BP_AISpawnBehaviour_AroundPlayers_Kea // (Final|UbergraphFunction) // @ game+0x1fb3630
};

