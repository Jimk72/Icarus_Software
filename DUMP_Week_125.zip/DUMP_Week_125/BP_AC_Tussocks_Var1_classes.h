// BlueprintGeneratedClass BP_AC_Tussocks_Var1.BP_AC_Tussocks_Var1_C
// Size: 0x3d8 (Inherited: 0x3cc)
struct ABP_AC_Tussocks_Var1_C : ABP_ResourceNodeBase_C {
	char pad_3CC[0x4]; // 0x3cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)

	void PlayHarvestFX(struct FVector Location, struct AIcarusPlayerCharacter* Instigator); // Function BP_AC_Tussocks_Var1.BP_AC_Tussocks_Var1_C.PlayHarvestFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_AC_Tussocks_Var1.BP_AC_Tussocks_Var1_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_AC_Tussocks_Var1(int32_t EntryPoint); // Function BP_AC_Tussocks_Var1.BP_AC_Tussocks_Var1_C.ExecuteUbergraph_BP_AC_Tussocks_Var1 // (Final|UbergraphFunction) // @ game+0x1fb3630
};

