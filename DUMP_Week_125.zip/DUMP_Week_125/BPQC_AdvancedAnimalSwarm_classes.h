// BlueprintGeneratedClass BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C
// Size: 0x158 (Inherited: 0xb0)
struct UBPQC_AdvancedAnimalSwarm_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct TArray<struct FAISetupRowHandle> Creatures; // 0xb8(0x10)
	float TimeBetweenSpawns; // 0xc8(0x04)
	float TimeBetweenSpawnsMultiplier; // 0xcc(0x04)
	int32_t BaseCreatures; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct TArray<struct ABP_IcarusNPCGOAPCharacter_C*> SpawnedNPC's; // 0xd8(0x10)
	struct FRandomStream Random Stream; // 0xe8(0x08)
	struct AActor* Enemy Target; // 0xf0(0x08)
	struct FMulticastInlineDelegate CreatureKilled; // 0xf8(0x10)
	struct FVector Item; // 0x108(0x0c)
	float AdditionalCreaturesPerPlayer; // 0x114(0x04)
	int32_t Creature Limit; // 0x118(0x04)
	float MinQuerierDistance; // 0x11c(0x04)
	float MaxQuerierDistance; // 0x120(0x04)
	float MinDistance; // 0x124(0x04)
	float MaxDistance; // 0x128(0x04)
	float Spacing; // 0x12c(0x04)
	enum class EEnvQueryRunMode RunMode; // 0x130(0x01)
	char pad_131[0x7]; // 0x131(0x07)
	struct AActor* Spawn Target; // 0x138(0x08)
	struct FAIRelationshipsRowHandle AIRelationshipOverride; // 0x140(0x18)

	void SetRelationshipOverride(struct FAIRelationshipsRowHandle Creatures); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.SetRelationshipOverride // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Initialise(float TimeBetweenSpawns, int32_t BaseCreatures, float AdditionalCreaturesPerPlayer, int32_t Creature Limit, struct TArray<struct FAISetupRowHandle>& Creatures); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.Initialise // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Configure Distances(float MinQuerierDistance, float MaxQuerierDistance, float MinDistance, float MaxDistance, float Spacing); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.Configure Distances // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Get Creature(struct FAISetupRowHandle& Creature); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.Get Creature // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetMaxCreatures(int32_t& ScaledNumber); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.GetMaxCreatures // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	bool CanSpawn(); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.CanSpawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void UpdateTargets(struct AActor* EnemyTarget, struct AActor* Spawn Target); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.UpdateTargets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void AngerNPC(struct AIcarusNPCGOAPCharacter* NPC); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.AngerNPC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveTick(float DeltaSeconds); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void EQSComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.EQSComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnActorDeath(struct UActorState* ActorState); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.OnActorDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SpawnCreature(); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.SpawnCreature // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.OnEndPlay // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SpawnGroup(); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.SpawnGroup // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BPQC_AdvancedAnimalSwarm(int32_t EntryPoint); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.ExecuteUbergraph_BPQC_AdvancedAnimalSwarm // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
	void CreatureKilled__DelegateSignature(); // Function BPQC_AdvancedAnimalSwarm.BPQC_AdvancedAnimalSwarm_C.CreatureKilled__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

