// BlueprintGeneratedClass BP_DeployableBase.BP_DeployableBase_C
// Size: 0x761 (Inherited: 0x5b0)
struct ABP_DeployableBase_C : ADeployable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5b0(0x08)
	struct USceneComponent* AudioLocation; // 0x5b8(0x08)
	struct UStaticMeshComponent* SphereHelper_Fuel; // 0x5c0(0x08)
	struct UStaticMeshComponent* SphereHelper_Electric; // 0x5c8(0x08)
	struct UStaticMeshComponent* SphereHelper_Water; // 0x5d0(0x08)
	struct UBP_IcarusSplineConnectionComponent_Fuel_C* BP_IcarusSplineConnectionComponent_Fuel; // 0x5d8(0x08)
	struct UBP_IcarusSplineConnectionComponent_Electric_C* BP_IcarusSplineConnectionComponent_Electric; // 0x5e0(0x08)
	struct UBP_IcarusSplineConnectionComponent_Water_C* BP_IcarusSplineConnectionComponent_Water; // 0x5e8(0x08)
	struct USceneComponent* SplineConnectors; // 0x5f0(0x08)
	struct UShelteredModifierComponent* ShelteredModifier; // 0x5f8(0x08)
	struct UAudioContextComponent* AudioContext; // 0x600(0x08)
	struct UBoxComponent* WeightColliderBox; // 0x608(0x08)
	struct USceneComponent* ProxyMeshes; // 0x610(0x08)
	struct UBP_ShelteredComponent_C* BP_ShelteredComponent; // 0x618(0x08)
	struct UStaticMeshComponent* DeployableSM; // 0x620(0x08)
	struct USkeletalMeshComponent* DeployableSK; // 0x628(0x08)
	int32_t LastHealth; // 0x630(0x04)
	float LastShelter; // 0x634(0x04)
	struct UFMODEvent* DamagedAudio; // 0x638(0x08)
	struct UFMODEvent* BrokenAudio; // 0x640(0x08)
	struct UDestructibleMesh* DestructibleMesh; // 0x648(0x08)
	struct FTransform RelativeTransform; // 0x650(0x30)
	struct TMap<struct FItemsStaticRowHandle, struct FDeployableProxyMeshConditionArray> ProxyMeshMapping; // 0x680(0x50)
	bool OverflowBagHandled; // 0x6d0(0x01)
	char pad_6D1[0x7]; // 0x6d1(0x07)
	struct TArray<struct USceneComponent*> NetProxyMeshesToShow; // 0x6d8(0x10)
	struct TArray<struct USceneComponent*> NetProxyMeshesToHide; // 0x6e8(0x10)
	float AudioOcclusion; // 0x6f8(0x04)
	bool IsInteractedWith; // 0x6fc(0x01)
	char pad_6FD[0x3]; // 0x6fd(0x03)
	struct TSet<struct AActor*> CurrentInteractors; // 0x700(0x50)
	struct FVector ItemSlottedAudioLocationOffset; // 0x750(0x0c)
	bool GeneratorStateActive; // 0x75c(0x01)
	bool ProcessorStateActive; // 0x75d(0x01)
	bool ServerIsInCave; // 0x75e(0x01)
	bool InvolvedInQuest; // 0x75f(0x01)
	bool Include Self; // 0x760(0x01)

	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_DeployableBase.BP_DeployableBase_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Clear Weather Resource Modifiers(); // Function BP_DeployableBase.BP_DeployableBase_C.Clear Weather Resource Modifiers // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetDestructibleActorSpawnTransform(struct FTransform& SpawnTransform); // Function BP_DeployableBase.BP_DeployableBase_C.GetDestructibleActorSpawnTransform // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void Zero Fillable Stored(); // Function BP_DeployableBase.BP_DeployableBase_C.Zero Fillable Stored // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayItemAddedAudio(struct FItemsStaticRowHandle Item); // Function BP_DeployableBase.BP_DeployableBase_C.PlayItemAddedAudio // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayRepairedAudio(); // Function BP_DeployableBase.BP_DeployableBase_C.PlayRepairedAudio // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	bool GetIsInCave(); // Function BP_DeployableBase.BP_DeployableBase_C.GetIsInCave // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void GetDeployableSetup(struct FDeployableSetupRowHandle& DeployableSetup); // Function BP_DeployableBase.BP_DeployableBase_C.GetDeployableSetup // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ProcessorStateUpdate(bool Active); // Function BP_DeployableBase.BP_DeployableBase_C.ProcessorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GeneratorStateUpdate(bool Active); // Function BP_DeployableBase.BP_DeployableBase_C.GeneratorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_ProcessorStateActive(); // Function BP_DeployableBase.BP_DeployableBase_C.OnRep_ProcessorStateActive // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_GeneratorStateActive(); // Function BP_DeployableBase.BP_DeployableBase_C.OnRep_GeneratorStateActive // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayItemSlottedAudio(struct FVector Location, struct FItemsStaticRowHandle Item); // Function BP_DeployableBase.BP_DeployableBase_C.PlayItemSlottedAudio // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayBrokenAudio(); // Function BP_DeployableBase.BP_DeployableBase_C.PlayBrokenAudio // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayDamagedAudio(struct UActorState* ActorState, int32_t DamageTaken, enum class EIcarusDamageType DamageType); // Function BP_DeployableBase.BP_DeployableBase_C.PlayDamagedAudio // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_StopInteract(struct AActor* Interactor); // Function BP_DeployableBase.BP_DeployableBase_C.Deployable_StopInteract // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_DeployableBase.BP_DeployableBase_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_IsInteractedWith(); // Function BP_DeployableBase.BP_DeployableBase_C.OnRep_IsInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void VacuumItems(struct AActor* Instigator, struct FItemsStaticRowHandle ItemsStaticRowHandle, int32_t Count, struct FInventoryIDEnum InventoryID); // Function BP_DeployableBase.BP_DeployableBase_C.VacuumItems // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetComponentAndChildrenMobility(struct USceneComponent* Component, enum class EComponentMobility Mobility); // Function BP_DeployableBase.BP_DeployableBase_C.SetComponentAndChildrenMobility // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_NetProxyMeshesToHide(); // Function BP_DeployableBase.BP_DeployableBase_C.OnRep_NetProxyMeshesToHide // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_NetProxyMeshesToShow(); // Function BP_DeployableBase.BP_DeployableBase_C.OnRep_NetProxyMeshesToShow // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void AddProxyMeshCondition(struct FItemsStaticRowHandle ItemStatic, struct USceneComponent* ComponentToShow, int32_t MinimumStackSize, bool RequiresASlotableSlot); // Function BP_DeployableBase.BP_DeployableBase_C.AddProxyMeshCondition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ProxyMeshRemoveCheck(struct UInventory* Inventory, int32_t Index, struct FItemData RemovedData); // Function BP_DeployableBase.BP_DeployableBase_C.ProxyMeshRemoveCheck // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ProxyMeshAddCheck(struct UInventory* Inventory, int32_t Index, struct FItemData ItemData); // Function BP_DeployableBase.BP_DeployableBase_C.ProxyMeshAddCheck // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CreateOverflowBag(bool IncludeSelf, enum class EIcarusActorDestroyReason DestroyReason); // Function BP_DeployableBase.BP_DeployableBase_C.CreateOverflowBag // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetNewFoundationActor(struct AActor* NewFoundation); // Function BP_DeployableBase.BP_DeployableBase_C.SetNewFoundationActor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IsFunctional(bool& bFunctional); // Function BP_DeployableBase.BP_DeployableBase_C.IsFunctional // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void Deployable_Pickup(struct AActor* Instigator, bool& PickedUp); // Function BP_DeployableBase.BP_DeployableBase_C.Deployable_Pickup // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_DeployableBase.BP_DeployableBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveDestroyed(); // Function BP_DeployableBase.BP_DeployableBase_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void Event Actor Broken(); // Function BP_DeployableBase.BP_DeployableBase_C.Event Actor Broken // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Event Damaged(struct UActorState* ActorState, int32_t DamageTaken, struct FDamageEvent& DamageEvent, struct AController* Instigator, struct AActor* DamageCauser); // Function BP_DeployableBase.BP_DeployableBase_C.Event Damaged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_DeployableBase.BP_DeployableBase_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_BrokenEffects(); // Function BP_DeployableBase.BP_DeployableBase_C.MULTI_BrokenEffects // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RefreshFoundationBinds(); // Function BP_DeployableBase.BP_DeployableBase_C.RefreshFoundationBinds // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EventOnDestroyed(struct AActor* DestroyedActor); // Function BP_DeployableBase.BP_DeployableBase_C.EventOnDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRestoreFoundationFromDatabase(struct AIcarusActor* FoundationFromDatabase); // Function BP_DeployableBase.BP_DeployableBase_C.OnRestoreFoundationFromDatabase // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ItemAdded(struct UInventory* Inventory, int32_t Location); // Function BP_DeployableBase.BP_DeployableBase_C.ItemAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ItemRemovedVerbose(struct UInventory* Inventory, int32_t Location, struct FItemData& Item); // Function BP_DeployableBase.BP_DeployableBase_C.ItemRemovedVerbose // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void itemremovedfuel(struct UInventory* Inventory, int32_t Location, struct FItemData& Item); // Function BP_DeployableBase.BP_DeployableBase_C.itemremovedfuel // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ItemRemovedProcessor(struct UInventory* Inventory, int32_t Location, struct FItemData& Item); // Function BP_DeployableBase.BP_DeployableBase_C.ItemRemovedProcessor // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RepairObject(); // Function BP_DeployableBase.BP_DeployableBase_C.RepairObject // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnBecomeInteractedWith(); // Function BP_DeployableBase.BP_DeployableBase_C.OnBecomeInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnNoLongerInteractedWith(); // Function BP_DeployableBase.BP_DeployableBase_C.OnNoLongerInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EventItemAddedToSlot(struct FVector Slot, struct AIcarusItem* NewItem); // Function BP_DeployableBase.BP_DeployableBase_C.EventItemAddedToSlot // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_ItemAddedToSlot(struct FVector SlotLocation, struct FItemsStaticRowHandle Item); // Function BP_DeployableBase.BP_DeployableBase_C.MULTI_ItemAddedToSlot // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnGeneratorActiveStateUpdated(bool IsActive); // Function BP_DeployableBase.BP_DeployableBase_C.OnGeneratorActiveStateUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnProcessorStateUpdated(bool bIsActive); // Function BP_DeployableBase.BP_DeployableBase_C.OnProcessorStateUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EventFoundationDestroyed(struct ABuildingBase* Building, enum class EBuildingDestroyReason DestroyReason); // Function BP_DeployableBase.BP_DeployableBase_C.EventFoundationDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EventFoundationReplaced(struct ABuildingBase* NewBuilding); // Function BP_DeployableBase.BP_DeployableBase_C.EventFoundationReplaced // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetCaveState(bool IsInCave, struct AActor* CaveActor); // Function BP_DeployableBase.BP_DeployableBase_C.SetCaveState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_OnRepaired(); // Function BP_DeployableBase.BP_DeployableBase_C.MULTI_OnRepaired // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_OnItemVacuumed(struct FItemsStaticRowHandle Item); // Function BP_DeployableBase.BP_DeployableBase_C.MULTI_OnItemVacuumed // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_DeployableBase.BP_DeployableBase_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void DestroyIcarusActorInternal(enum class EIcarusActorDestroyReason Reason); // Function BP_DeployableBase.BP_DeployableBase_C.DestroyIcarusActorInternal // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_DeployableBase(int32_t EntryPoint); // Function BP_DeployableBase.BP_DeployableBase_C.ExecuteUbergraph_BP_DeployableBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

