// AnimBlueprintGeneratedClass 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C
// Size: 0xcbd (Inherited: 0x2c0)
struct U3RD_MAL_RIG_Chair_AnimBP_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x2c8(0x158)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x420(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x4a0(0xa0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator; // 0x540(0x50)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // 0x590(0xc8)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2; // 0x658(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_3; // 0x770(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x7a0(0x80)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // 0x820(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_2; // 0x938(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x968(0x80)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x9e8(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0xa08(0x20)
	struct FAnimNode_Root AnimGraphNode_Root; // 0xa28(0x30)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer_2; // 0xa58(0xb0)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer; // 0xb08(0xb0)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0xbb8(0xc0)
	bool IsDriver; // 0xc78(0x01)
	char pad_C79[0x7]; // 0xc79(0x07)
	struct UObject* VehicleRef; // 0xc80(0x08)
	float AimPitch; // 0xc88(0x04)
	float AimYaw; // 0xc8c(0x04)
	struct FRotator LookRot; // 0xc90(0x0c)
	float AnimDelta; // 0xc9c(0x04)
	float VehicleSpeed; // 0xca0(0x04)
	struct FVector LHandSocketLocation; // 0xca4(0x0c)
	struct FVector RHandSocketLocation; // 0xcb0(0x0c)
	bool Shake; // 0xcbc(0x01)

	void VehicleLowerBody(struct FPoseLink LowerInPose, struct FPoseLink& VehicleLowerBody); // Function 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C.VehicleLowerBody // (HasOutParms|BlueprintCallable) // @ game+0x1fb3630
	void VehicleUpperBody(struct FPoseLink UpperInPose, struct FPoseLink& VehicleUpperBody); // Function 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C.VehicleUpperBody // (HasOutParms|BlueprintCallable) // @ game+0x1fb3630
	void AnimGraph(struct FPoseLink& AnimGraph); // Function 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EvaluateGraphExposedInputs_ExecuteUbergraph_3RD_MAL_RIG_Chair_AnimBP_AnimGraphNode_TwoWayBlend_C412B1A04C8A3F73B4E7E89ED8F54F8C(); // Function 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_3RD_MAL_RIG_Chair_AnimBP_AnimGraphNode_TwoWayBlend_C412B1A04C8A3F73B4E7E89ED8F54F8C // (BlueprintEvent) // @ game+0x1fb3630
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_3RD_MAL_RIG_Chair_AnimBP(int32_t EntryPoint); // Function 3RD_MAL_RIG_Chair_AnimBP.3RD_MAL_RIG_Chair_AnimBP_C.ExecuteUbergraph_3RD_MAL_RIG_Chair_AnimBP // (Final|UbergraphFunction) // @ game+0x1fb3630
};

