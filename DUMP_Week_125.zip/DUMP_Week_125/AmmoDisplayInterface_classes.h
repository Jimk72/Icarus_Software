// BlueprintGeneratedClass AmmoDisplayInterface.AmmoDisplayInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UAmmoDisplayInterface_C : UInterface {

	void GetCurrentAmmoInfo(struct TSoftObjectPtr<UTexture2D>& AmmoIcon, struct FText& CurrentAmmo, struct FText& TotalAmmo); // Function AmmoDisplayInterface.AmmoDisplayInterface_C.GetCurrentAmmoInfo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

