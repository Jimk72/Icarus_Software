// AnimBlueprintGeneratedClass AfricanElephant_M_AnimBP.AfricanElephant_M_AnimBP_C
// Size: 0x12e8 (Inherited: 0x390)
struct UAfricanElephant_M_AnimBP_C : UIcarusCreatureAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x398(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2; // 0x3c8(0xe8)
	struct FAnimNode_ApplyMeshSpaceAdditive AnimGraphNode_ApplyMeshSpaceAdditive; // 0x4b0(0xd0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x580(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x600(0xa0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x6a0(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x6c0(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x7c8(0x20)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x7e8(0xe8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x8d0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x900(0xb0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0x9b0(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0xb08(0x28)
	struct FAnimNode_AimOffsetLookAt AnimGraphNode_AimOffsetLookAt; // 0xb30(0x1c0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0xcf0(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0xd18(0xa0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0xdb8(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0xe00(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0xf58(0x28)
	struct FAnimNode_ControlRig AnimGraphNode_ControlRig; // 0xf80(0x368)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AfricanElephant_M_AnimBP.AfricanElephant_M_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AfricanElephant_M_AnimBP_AnimGraphNode_BlendSpacePlayer_AF30C7B045D9B11D0CE0EF919134E33E(); // Function AfricanElephant_M_AnimBP.AfricanElephant_M_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AfricanElephant_M_AnimBP_AnimGraphNode_BlendSpacePlayer_AF30C7B045D9B11D0CE0EF919134E33E // (BlueprintEvent) // @ game+0x1fb3630
	void EvaluateGraphExposedInputs_ExecuteUbergraph_AfricanElephant_M_AnimBP_AnimGraphNode_ApplyMeshSpaceAdditive_E7FAA59A4AECB1BA819708896557D96A(); // Function AfricanElephant_M_AnimBP.AfricanElephant_M_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_AfricanElephant_M_AnimBP_AnimGraphNode_ApplyMeshSpaceAdditive_E7FAA59A4AECB1BA819708896557D96A // (BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_AfricanElephant_M_AnimBP(int32_t EntryPoint); // Function AfricanElephant_M_AnimBP.AfricanElephant_M_AnimBP_C.ExecuteUbergraph_AfricanElephant_M_AnimBP // (Final|UbergraphFunction) // @ game+0x1fb3630
};

