// BlueprintGeneratedClass BP_DropShip.BP_DropShip_C
// Size: 0x498 (Inherited: 0x318)
struct ABP_DropShip_C : AIcarusRocket {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UAudioContextComponent* AudioContext; // 0x320(0x08)
	struct UAudioOcclusionDropshipComponent* AudioOcclusionDropship; // 0x328(0x08)
	struct UIcarusMapIconComponent* IcarusMapIcon; // 0x330(0x08)
	struct UIcarusNavigationDirtier* IcarusNavigationDirtier; // 0x338(0x08)
	struct USphereComponent* Sphere; // 0x340(0x08)
	struct UInventoryComponent* Inventory; // 0x348(0x08)
	struct UHighlightableComponent* Highlightable; // 0x350(0x08)
	struct UCameraComponent* Camera; // 0x358(0x08)
	struct UIcarusCameraSpringArm* IcarusCameraSpringArm; // 0x360(0x08)
	struct UTextRenderComponent* PlayerName; // 0x368(0x08)
	struct UInteractableComponent* Interactable; // 0x370(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x378(0x08)
	struct TArray<struct ABP_PartBase_C*> HighlightComponents; // 0x380(0x10)
	float DescentTime; // 0x390(0x04)
	float CurrentTime; // 0x394(0x04)
	float AscentTime; // 0x398(0x04)
	char pad_39C[0x4]; // 0x39c(0x04)
	struct TArray<struct FDropShipEvent> DecentActions; // 0x3a0(0x10)
	struct TArray<struct FDropShipEvent> AscentActions; // 0x3b0(0x10)
	struct FDropShipSequencesRowHandle DecentSequence; // 0x3c0(0x18)
	struct FDropShipSequencesRowHandle AscentSequence; // 0x3d8(0x18)
	bool ShipInteractionEnabled; // 0x3f0(0x01)
	bool ClientReady; // 0x3f1(0x01)
	bool ServerShipBuilt; // 0x3f2(0x01)
	char pad_3F3[0x5]; // 0x3f3(0x05)
	struct FText Name; // 0x3f8(0x18)
	struct ABP_DropshipSeat_C* Seat; // 0x410(0x08)
	bool CollisionEnabled; // 0x418(0x01)
	char pad_419[0x3]; // 0x419(0x03)
	int32_t PlayerIndex; // 0x41c(0x04)
	bool PartsAttached; // 0x420(0x01)
	char pad_421[0x7]; // 0x421(0x07)
	struct ABP_PartBase_C* TopPart; // 0x428(0x08)
	struct ABP_PartBase_C* MidPart; // 0x430(0x08)
	struct ABP_PartBase_C* BtmPart; // 0x438(0x08)
	struct FVector ReplicatedLocation; // 0x440(0x0c)
	bool DebugDropshipSequence; // 0x44c(0x01)
	char pad_44D[0x3]; // 0x44d(0x03)
	struct FString LogName; // 0x450(0x10)
	bool Dropship Initialised; // 0x460(0x01)
	bool DebugWithoutBackend; // 0x461(0x01)
	enum class EDropshipDescentStateFMODParam FMODAudioDescentState; // 0x462(0x01)
	enum class EDropshipAssignedPlayerType AssignedPlayerType; // 0x463(0x01)
	bool bDatabaseReloaded; // 0x464(0x01)
	bool PlayLandingAudio; // 0x465(0x01)
	char pad_466[0x2]; // 0x466(0x02)
	struct TArray<struct FItemData> GrantedLoadoutItems; // 0x468(0x10)
	bool IsUnattendedLaunch; // 0x478(0x01)
	char pad_479[0x3]; // 0x479(0x03)
	struct FVector RelocationTarget; // 0x47c(0x0c)
	struct FVector LastFoliageLocationCheck; // 0x488(0x0c)
	float DestroyFoliageRadius; // 0x494(0x04)

	void CheckForAtomiseFoliage(struct FVector CurrentLocation, struct FVector TargetLocation); // Function BP_DropShip.BP_DropShip_C.CheckForAtomiseFoliage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TryAssignDebugDropship(); // Function BP_DropShip.BP_DropShip_C.TryAssignDebugDropship // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetDropshipLoadoutItems(struct FItemData& TopPart, struct FItemData& MidPart, struct FItemData& BottomPart); // Function BP_DropShip.BP_DropShip_C.GetDropshipLoadoutItems // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void ResetDropshipActions(); // Function BP_DropShip.BP_DropShip_C.ResetDropshipActions // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CheckClientPartsReady(bool& PartsReady); // Function BP_DropShip.BP_DropShip_C.CheckClientPartsReady // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void SetAssignedPlayerType(enum class EDropshipAssignedPlayerType PlayerType); // Function BP_DropShip.BP_DropShip_C.SetAssignedPlayerType // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateGlobalAudioParameters(); // Function BP_DropShip.BP_DropShip_C.UpdateGlobalAudioParameters // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnConnectedPlayerInitialised(struct FConnectedPlayer& ConnectedPlayer); // Function BP_DropShip.BP_DropShip_C.OnConnectedPlayerInitialised // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void HasProspectExpired(bool& IsExpired); // Function BP_DropShip.BP_DropShip_C.HasProspectExpired // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void UpdateFMODState(struct FDropShipActionsEnum Action); // Function BP_DropShip.BP_DropShip_C.UpdateFMODState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_FMODAudioDescentState(); // Function BP_DropShip.BP_DropShip_C.OnRep_FMODAudioDescentState // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Grant Loadout Items(); // Function BP_DropShip.BP_DropShip_C.Grant Loadout Items // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DebugSequence(float SequenceTime); // Function BP_DropShip.BP_DropShip_C.DebugSequence // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateFmodPlayerPerspective(bool bIsThirdPerson); // Function BP_DropShip.BP_DropShip_C.UpdateFmodPlayerPerspective // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void StateUpdated(); // Function BP_DropShip.BP_DropShip_C.StateUpdated // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void InitLandedState(); // Function BP_DropShip.BP_DropShip_C.InitLandedState // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FixDropshipLayout(); // Function BP_DropShip.BP_DropShip_C.FixDropshipLayout // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FixSeat(struct ABP_PartBase_C* Parent); // Function BP_DropShip.BP_DropShip_C.FixSeat // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FixPartsLocation(struct ABP_PartBase_C* Parent, struct ABP_PartBase_C* NewPart, struct FName ParentSocket, struct FName NewPartSocket); // Function BP_DropShip.BP_DropShip_C.FixPartsLocation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SpawnParts(struct FItemData TOP_Item, struct FItemData MID_Item, struct FItemData BTM_Item); // Function BP_DropShip.BP_DropShip_C.SpawnParts // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateAudioState(); // Function BP_DropShip.BP_DropShip_C.UpdateAudioState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetCommandPart(struct ABP_RP_Command_Base_C*& Command); // Function BP_DropShip.BP_DropShip_C.GetCommandPart // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_Name(); // Function BP_DropShip.BP_DropShip_C.OnRep_Name // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_ShipInteractionEnabled(); // Function BP_DropShip.BP_DropShip_C.OnRep_ShipInteractionEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetInteraction(bool Active); // Function BP_DropShip.BP_DropShip_C.SetInteraction // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReadyCheck(bool& Ready); // Function BP_DropShip.BP_DropShip_C.ReadyCheck // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void InitialiseActions(); // Function BP_DropShip.BP_DropShip_C.InitialiseActions // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TriggerPartEvent(struct FDropShipActionsEnum Action); // Function BP_DropShip.BP_DropShip_C.TriggerPartEvent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TriggerShipEvent(struct FDropShipActionsEnum Action, bool& Success); // Function BP_DropShip.BP_DropShip_C.TriggerShipEvent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TriggerActions(struct TArray<struct FDropShipEvent>& Actions, float& Time); // Function BP_DropShip.BP_DropShip_C.TriggerActions // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateHighlight(struct ABP_PartBase_C* Part, bool State); // Function BP_DropShip.BP_DropShip_C.UpdateHighlight // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRocketAssembled(); // Function BP_DropShip.BP_DropShip_C.OnRocketAssembled // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnServer_ClientReady(); // Function BP_DropShip.BP_DropShip_C.OnServer_ClientReady // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_DropShip.BP_DropShip_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1fb3630
	void SpawnShipParts(); // Function BP_DropShip.BP_DropShip_C.SpawnShipParts // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DropshipLog(struct FString Log); // Function BP_DropShip.BP_DropShip_C.DropshipLog // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_DropShip.BP_DropShip_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void InitialisePosition(struct FVector InitialPositionOverride); // Function BP_DropShip.BP_DropShip_C.InitialisePosition // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnProspectSessionEnded(enum class EEndProspectSessionContext Context); // Function BP_DropShip.BP_DropShip_C.OnProspectSessionEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveTick(float DeltaSeconds); // Function BP_DropShip.BP_DropShip_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_AssignedPlayerCharacterID(); // Function BP_DropShip.BP_DropShip_C.OnRep_AssignedPlayerCharacterID // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void OnWorldInteraction(struct UInteractableComponent* Interactable, struct AActor* Instigator, struct FHitResult& HitResult); // Function BP_DropShip.BP_DropShip_C.OnWorldInteraction // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_DropShip.BP_DropShip_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_RocketState(); // Function BP_DropShip.BP_DropShip_C.OnRep_RocketState // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void OnDatabaseReload(); // Function BP_DropShip.BP_DropShip_C.OnDatabaseReload // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void OnDropshipSpawnPlayerInit(); // Function BP_DropShip.BP_DropShip_C.OnDropshipSpawnPlayerInit // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TriggerLeaveProspectLaunch(); // Function BP_DropShip.BP_DropShip_C.TriggerLeaveProspectLaunch // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void TriggerLaunch(bool UnattendedLaunch); // Function BP_DropShip.BP_DropShip_C.TriggerLaunch // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TryInitialiseDropship(); // Function BP_DropShip.BP_DropShip_C.TryInitialiseDropship // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ProcessActions(float DeltaTime); // Function BP_DropShip.BP_DropShip_C.ProcessActions // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_DropShip.BP_DropShip_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void BeginRelocation(struct FVector NewTargetLocation); // Function BP_DropShip.BP_DropShip_C.BeginRelocation // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DoRelocation(); // Function BP_DropShip.BP_DropShip_C.DoRelocation // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void InitialiseMapIcon(); // Function BP_DropShip.BP_DropShip_C.InitialiseMapIcon // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_DropShip(int32_t EntryPoint); // Function BP_DropShip.BP_DropShip_C.ExecuteUbergraph_BP_DropShip // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

