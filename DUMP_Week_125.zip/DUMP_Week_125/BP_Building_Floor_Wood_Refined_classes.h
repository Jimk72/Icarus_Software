// BlueprintGeneratedClass BP_Building_Floor_Wood_Refined.BP_Building_Floor_Wood_Refined_C
// Size: 0xbe8 (Inherited: 0xbd8)
struct ABP_Building_Floor_Wood_Refined_C : ABP_Building_Floor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd8(0x08)
	struct UBP_WeatherAudioComponent_Roof_C* BP_WeatherAudioComponent_Roof; // 0xbe0(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Floor_Wood_Refined.BP_Building_Floor_Wood_Refined_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Building_Floor_Wood_Refined(int32_t EntryPoint); // Function BP_Building_Floor_Wood_Refined.BP_Building_Floor_Wood_Refined_C.ExecuteUbergraph_BP_Building_Floor_Wood_Refined // (Final|UbergraphFunction) // @ game+0x1fb3630
};

