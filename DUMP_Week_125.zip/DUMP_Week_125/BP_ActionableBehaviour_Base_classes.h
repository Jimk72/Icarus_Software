// BlueprintGeneratedClass BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C
// Size: 0x30a (Inherited: 0x2d0)
struct UBP_ActionableBehaviour_Base_C : UActionableBehaviour {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FRandomStream RandomStream; // 0x2d8(0x08)
	bool DEBUG_ShowGetAnimationErrorMessages; // 0x2e0(0x01)
	char pad_2E1[0x7]; // 0x2e1(0x07)
	struct AActor* BehaviorOwner; // 0x2e8(0x08)
	struct AIcarusPlayerCharacterSurvival* BehaviorOwnerPlayer; // 0x2f0(0x08)
	bool ShowNoDurabilityError; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct FTimerHandle NoDurabilityErrorTimerHandle; // 0x300(0x08)
	bool UseInsufficientStaminaSound; // 0x308(0x01)
	bool UseInsufficientDurabilitySound; // 0x309(0x01)

	void PlayActionItemBrokenSound(); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.PlayActionItemBrokenSound // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayActionInsufficientStaminaSound(); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.PlayActionInsufficientStaminaSound // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IsLocallyOwned(bool& LocallyOwned); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.IsLocallyOwned // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void StopActionMontage(struct AIcarusPlayerCharacter* AnimTarget, float BlendOutTime); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.StopActionMontage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ShowErrorMessage(struct FText Message, struct FTimerHandle Timer, float ErrorCooldown, struct FTimerHandle& OutTimerHandle); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.ShowErrorMessage // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void InitActionable(); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.InitActionable // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ProcessDurabilityLoss(int32_t Durability); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.ProcessDurabilityLoss // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TryGetFailAnimations(struct TArray<struct FName>& TP_AnimNames, struct TArray<struct FName>& FP_AnimNames); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.TryGetFailAnimations // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TryGetMissAnimations(struct TArray<struct FName>& TP_AnimNames, struct TArray<struct FName>& FP_AnimNames); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.TryGetMissAnimations // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TryGetSuccessAnimations(struct FValidHitTypesRowHandle ValidHitType, struct TArray<struct FName>& TP_AnimNames, struct TArray<struct FName>& FP_AnimNames); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.TryGetSuccessAnimations // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Select Random Weighted Montage(struct UAnimMontage* AnimMontage, struct TArray<struct FName>& SectionNames, struct FName& ChosenSection); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.Select Random Weighted Montage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PlayActionMontage(struct AIcarusPlayerCharacter* AnimTarget, bool PlayRandom, float SpeedModifier, struct TArray<struct FName>& TPAnimSections, struct TArray<struct FName>& FPAnimSections); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.PlayActionMontage // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void PerformActionFromMenu(struct AActor* InvokingActor); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.PerformActionFromMenu // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnErrorMessageCooldownComplete(); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.OnErrorMessageCooldownComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnActionInsufficientStamina(enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.OnActionInsufficientStamina // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnActionInsufficientDurability(enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.OnActionInsufficientDurability // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_ActionableBehaviour_Base(int32_t EntryPoint); // Function BP_ActionableBehaviour_Base.BP_ActionableBehaviour_Base_C.ExecuteUbergraph_BP_ActionableBehaviour_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

