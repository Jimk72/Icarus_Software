// BlueprintGeneratedClass BP_ActionableBehaviour_CurvedSplinePlace_Power.BP_ActionableBehaviour_CurvedSplinePlace_Power_C
// Size: 0x560 (Inherited: 0x560)
struct UBP_ActionableBehaviour_CurvedSplinePlace_Power_C : UBP_ActionableBehaviour_CurvedSplinePlace_C {
};

