// BlueprintGeneratedClass BP_Building_Roof_Angle_Iron.BP_Building_Roof_Angle_Iron_C
// Size: 0xbe8 (Inherited: 0xbd8)
struct ABP_Building_Roof_Angle_Iron_C : ABP_Building_Ramp_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd8(0x08)
	struct UBP_WeatherAudioComponent_Roof_C* BP_WeatherAudioComponent_Roof; // 0xbe0(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Roof_Angle_Iron.BP_Building_Roof_Angle_Iron_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Building_Roof_Angle_Iron(int32_t EntryPoint); // Function BP_Building_Roof_Angle_Iron.BP_Building_Roof_Angle_Iron_C.ExecuteUbergraph_BP_Building_Roof_Angle_Iron // (Final|UbergraphFunction) // @ game+0x1fb3630
};

