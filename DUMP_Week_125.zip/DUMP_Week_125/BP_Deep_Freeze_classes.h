// BlueprintGeneratedClass BP_Deep_Freeze.BP_Deep_Freeze_C
// Size: 0x788 (Inherited: 0x77a)
struct ABP_Deep_Freeze_C : ABP_DeployableContainerBase_C {
	char pad_77A[0x6]; // 0x77a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x780(0x08)

	void UpdateModifier(); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.UpdateModifier // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void AddIce(); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.AddIce // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnBecomeInteractedWith(); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.OnBecomeInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnNoLongerInteractedWith(); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.OnNoLongerInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GenerateIceTimer(); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.GenerateIceTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceOnStateChanged(bool bIsOn); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.OnDeviceOnStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnBrownOutStrengthChanged(enum class EIcarusResourceType ResourceType, int32_t Strength); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.OnBrownOutStrengthChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Deep_Freeze(int32_t EntryPoint); // Function BP_Deep_Freeze.BP_Deep_Freeze_C.ExecuteUbergraph_BP_Deep_Freeze // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

