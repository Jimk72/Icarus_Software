// BlueprintGeneratedClass BP_Aquarium.BP_Aquarium_C
// Size: 0x850 (Inherited: 0x771)
struct ABP_Aquarium_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_771[0x7]; // 0x771(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x778(0x08)
	struct UNiagaraComponent* NS_Bubble5; // 0x780(0x08)
	struct UBoxComponent* SwimmableArea; // 0x788(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x790(0x08)
	struct UOverlapAudioComponent* AudioBubbles; // 0x798(0x08)
	struct URectLightComponent* RecDowntLight; // 0x7a0(0x08)
	struct UNiagaraComponent* NS_Bubble4; // 0x7a8(0x08)
	struct UNiagaraComponent* NS_Bubble3; // 0x7b0(0x08)
	struct UNiagaraComponent* NS_Bubble2; // 0x7b8(0x08)
	struct UNiagaraComponent* NS_Bubble1; // 0x7c0(0x08)
	struct USceneComponent* VFXAndLighting; // 0x7c8(0x08)
	struct USceneComponent* Fish1Location; // 0x7d0(0x08)
	struct UCameraComponent* Camera; // 0x7d8(0x08)
	struct UStaticMeshComponent* Dressing; // 0x7e0(0x08)
	struct UStaticMesh* DirtyMesh; // 0x7e8(0x08)
	struct UStaticMesh* CleanMesh; // 0x7f0(0x08)
	int32_t DynMaterialIndex; // 0x7f8(0x04)
	char pad_7FC[0x4]; // 0x7fc(0x04)
	struct UMaterialInstanceDynamic* DynamicMaterial; // 0x800(0x08)
	float LightIntensity; // 0x808(0x04)
	char pad_80C[0x4]; // 0x80c(0x04)
	struct TArray<struct FVector> FishMovementTargetLocations; // 0x810(0x10)
	struct TArray<float> GetNewTargetLocationTimes; // 0x820(0x10)
	struct TArray<struct FItemData> FishArray; // 0x830(0x10)
	struct TArray<struct USkeletalMeshComponent*> FishComponents; // 0x840(0x10)

	void CreateDynamicMaterial(); // Function BP_Aquarium.BP_Aquarium_C.CreateDynamicMaterial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateEffectState(bool Active); // Function BP_Aquarium.BP_Aquarium_C.UpdateEffectState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_FishArray(); // Function BP_Aquarium.BP_Aquarium_C.OnRep_FishArray // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetNewMovementTargetLocation(struct USkeletalMeshComponent* FishComponent, struct FVector& TargetLocation, bool& FoundValidLocation); // Function BP_Aquarium.BP_Aquarium_C.GetNewMovementTargetLocation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	void DeployableTick(float DeltaSeconds); // Function BP_Aquarium.BP_Aquarium_C.DeployableTick // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetFishMeshes(struct TArray<struct USkeletalMeshComponent*>& SkeletalMeshes); // Function BP_Aquarium.BP_Aquarium_C.GetFishMeshes // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Aquarium.BP_Aquarium_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateAllFish(struct UInventory* Inventory); // Function BP_Aquarium.BP_Aquarium_C.UpdateAllFish // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnLoaded_60B8164F46CDB00B131057B2E772CE31(struct UObject* Loaded); // Function BP_Aquarium.BP_Aquarium_C.OnLoaded_60B8164F46CDB00B131057B2E772CE31 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_Aquarium.BP_Aquarium_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_Aquarium.BP_Aquarium_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void UpdateFishMeshes(); // Function BP_Aquarium.BP_Aquarium_C.UpdateFishMeshes // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnInventoryItemChanged(struct UInventory* Inventory, int32_t Location); // Function BP_Aquarium.BP_Aquarium_C.OnInventoryItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceStartRunning(); // Function BP_Aquarium.BP_Aquarium_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceStopRunning(); // Function BP_Aquarium.BP_Aquarium_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Aquarium(int32_t EntryPoint); // Function BP_Aquarium.BP_Aquarium_C.ExecuteUbergraph_BP_Aquarium // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

