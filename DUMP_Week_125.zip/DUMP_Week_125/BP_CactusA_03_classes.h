// BlueprintGeneratedClass BP_CactusA_03.BP_CactusA_03_C
// Size: 0x3cc (Inherited: 0x3cc)
struct ABP_CactusA_03_C : ABP_ResourceNodeBase_C {

	void PlayHarvestFX(struct FVector Location, struct AIcarusPlayerCharacter* Instigator); // Function BP_CactusA_03.BP_CactusA_03_C.PlayHarvestFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateNodeVisuals(bool& Success); // Function BP_CactusA_03.BP_CactusA_03_C.UpdateNodeVisuals // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

