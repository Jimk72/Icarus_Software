// BlueprintGeneratedClass BP_DeepOreDepositSpawn.BP_DeepOreDepositSpawn_C
// Size: 0x232 (Inherited: 0x220)
struct ABP_DeepOreDepositSpawn_C : AActor {
	struct UStaticMeshComponent* MetaNode; // 0x220(0x08)
	struct USceneComponent* Root; // 0x228(0x08)
	bool SpawnCaveVariant; // 0x230(0x01)
	bool SpawnIceVariant; // 0x231(0x01)
};

