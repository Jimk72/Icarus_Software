// BlueprintGeneratedClass BP_BedBase.BP_BedBase_C
// Size: 0x7a0 (Inherited: 0x761)
struct ABP_BedBase_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct USceneComponent* Scene; // 0x770(0x08)
	struct USceneComponent* SeatAttachPoint; // 0x778(0x08)
	struct UBP_UIProjectionComponent_C* BP_UIProjectionComponent; // 0x780(0x08)
	struct TArray<struct FString> AssignedPlayerUIDs; // 0x788(0x10)
	struct ABP_Seat_Bed_C* SeatRef; // 0x798(0x08)

	struct TArray<struct FString> GetPlayerUIDArray(); // Function BP_BedBase.BP_BedBase_C.GetPlayerUIDArray // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_BedBase.BP_BedBase_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_BedBase.BP_BedBase_C.Deployable_Interact // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EnterBed(struct AIcarusPlayerCharacter* Player); // Function BP_BedBase.BP_BedBase_C.EnterBed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CheckTimeSkip(); // Function BP_BedBase.BP_BedBase_C.CheckTimeSkip // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void InitSeat(); // Function BP_BedBase.BP_BedBase_C.InitSeat // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateInWorldIcon(); // Function BP_BedBase.BP_BedBase_C.UpdateInWorldIcon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	struct FVector FindExitSpot(); // Function BP_BedBase.BP_BedBase_C.FindExitSpot // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_AssignedPlayerUIDs(); // Function BP_BedBase.BP_BedBase_C.OnRep_AssignedPlayerUIDs // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	bool HasPlayerUID(struct FString& PlayerUID); // Function BP_BedBase.BP_BedBase_C.HasPlayerUID // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void SanitzeAllBedUIDs(); // Function BP_BedBase.BP_BedBase_C.SanitzeAllBedUIDs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RemovePlayerUID(struct FString& PlayerUID); // Function BP_BedBase.BP_BedBase_C.RemovePlayerUID // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void AddPlayerUID(struct FString& PlayerUID); // Function BP_BedBase.BP_BedBase_C.AddPlayerUID // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_BedBase.BP_BedBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void SetPlayerUIDArray(struct TArray<struct FString>& PlayerUIDArray); // Function BP_BedBase.BP_BedBase_C.SetPlayerUIDArray // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_BedBase(int32_t EntryPoint); // Function BP_BedBase.BP_BedBase_C.ExecuteUbergraph_BP_BedBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

