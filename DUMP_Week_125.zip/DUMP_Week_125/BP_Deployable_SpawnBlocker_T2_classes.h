// BlueprintGeneratedClass BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C
// Size: 0x7a0 (Inherited: 0x77d)
struct ABP_Deployable_SpawnBlocker_T2_C : ABP_Deployable_SpawnBlocker_C {
	char pad_77D[0x3]; // 0x77d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x780(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x788(0x08)
	struct UCameraComponent* Camera; // 0x790(0x08)
	struct UNiagaraComponent* NS_Smelly; // 0x798(0x08)

	void CheckBlockerActive(); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.CheckBlockerActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GeneratorStateUpdate(bool Active); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.GeneratorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnFuelInventoryUpdated(struct UInventory* Inventory, int32_t Location); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.OnFuelInventoryUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceOnStateChanged(bool bIsOn); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.OnDeviceOnStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OutOfFuelCheck(); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.OutOfFuelCheck // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Deployable_SpawnBlocker_T2(int32_t EntryPoint); // Function BP_Deployable_SpawnBlocker_T2.BP_Deployable_SpawnBlocker_T2_C.ExecuteUbergraph_BP_Deployable_SpawnBlocker_T2 // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

