// BlueprintGeneratedClass BP_BabyDeer_Corpse.BP_BabyDeer_Corpse_C
// Size: 0x780 (Inherited: 0x780)
struct ABP_BabyDeer_Corpse_C : ABP_GOAP_Corpse_C {
};

