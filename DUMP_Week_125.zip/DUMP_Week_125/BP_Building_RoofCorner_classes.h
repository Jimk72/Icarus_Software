// BlueprintGeneratedClass BP_Building_RoofCorner.BP_Building_RoofCorner_C
// Size: 0xbd8 (Inherited: 0xbd8)
struct ABP_Building_RoofCorner_C : ABP_Building_Ramp_C {
};

