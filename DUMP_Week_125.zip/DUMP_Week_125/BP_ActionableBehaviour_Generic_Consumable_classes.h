// BlueprintGeneratedClass BP_ActionableBehaviour_Generic_Consumable.BP_ActionableBehaviour_Generic_Consumable_C
// Size: 0x320 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Generic_Consumable_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* OwningPlayer; // 0x318(0x08)

	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Generic_Consumable.BP_ActionableBehaviour_Generic_Consumable_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Generic_Consumable.BP_ActionableBehaviour_Generic_Consumable_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Generic_Consumable.BP_ActionableBehaviour_Generic_Consumable_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_ActionableBehaviour_Generic_Consumable(int32_t EntryPoint); // Function BP_ActionableBehaviour_Generic_Consumable.BP_ActionableBehaviour_Generic_Consumable_C.ExecuteUbergraph_BP_ActionableBehaviour_Generic_Consumable // (Final|UbergraphFunction) // @ game+0x1fb3630
};

