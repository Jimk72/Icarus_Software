// BlueprintGeneratedClass BP_Conifer_Wolf_Corpse.BP_Conifer_Wolf_Corpse_C
// Size: 0x788 (Inherited: 0x780)
struct ABP_Conifer_Wolf_Corpse_C : ABP_GOAP_Corpse_C {
	struct UGFurComponent* GFur; // 0x780(0x08)

	void OnSkinnedStateUpdated(); // Function BP_Conifer_Wolf_Corpse.BP_Conifer_Wolf_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

