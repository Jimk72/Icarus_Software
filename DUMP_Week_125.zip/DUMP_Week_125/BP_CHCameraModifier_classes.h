// BlueprintGeneratedClass BP_CHCameraModifier.BP_CHCameraModifier_C
// Size: 0x48 (Inherited: 0x48)
struct UBP_CHCameraModifier_C : UCameraModifier {

	void BlueprintModifyCamera(float DeltaTime, struct FVector ViewLocation, struct FRotator ViewRotation, float FOV, struct FVector& NewViewLocation, struct FRotator& NewViewRotation, float& NewFOV); // Function BP_CHCameraModifier.BP_CHCameraModifier_C.BlueprintModifyCamera // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

