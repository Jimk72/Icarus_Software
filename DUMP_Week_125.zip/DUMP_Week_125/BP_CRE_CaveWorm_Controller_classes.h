// BlueprintGeneratedClass BP_CRE_CaveWorm_Controller.BP_CRE_CaveWorm_Controller_C
// Size: 0x350 (Inherited: 0x350)
struct ABP_CRE_CaveWorm_Controller_C : ABP_FactionBoss_Controller_SandWorm_C {
};

