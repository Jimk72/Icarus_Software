// BlueprintGeneratedClass AnimNotify_PreventAttacking.AnimNotify_PreventAttacking_C
// Size: 0x39 (Inherited: 0x38)
struct UAnimNotify_PreventAttacking_C : UAnimNotify {
	bool AttacksEnabled; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_PreventAttacking.AnimNotify_PreventAttacking_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	struct FString GetNotifyName(); // Function AnimNotify_PreventAttacking.AnimNotify_PreventAttacking_C.GetNotifyName // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
};

