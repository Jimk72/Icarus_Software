// BlueprintGeneratedClass BP_Bramble.BP_Bramble_C
// Size: 0x7e0 (Inherited: 0x7d8)
struct ABP_Bramble_C : ABP_Spike_Trap_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7d8(0x08)

	void DoDamage(int32_t DamageAmount, struct AActor* Defender); // Function BP_Bramble.BP_Bramble_C.DoDamage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_PlayDamageAudio(); // Function BP_Bramble.BP_Bramble_C.MULTI_PlayDamageAudio // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Bramble(int32_t EntryPoint); // Function BP_Bramble.BP_Bramble_C.ExecuteUbergraph_BP_Bramble // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

