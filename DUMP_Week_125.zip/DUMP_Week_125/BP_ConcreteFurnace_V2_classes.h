// BlueprintGeneratedClass BP_ConcreteFurnace_V2.BP_ConcreteFurnace_V2_C
// Size: 0xa50 (Inherited: 0x9f0)
struct ABP_ConcreteFurnace_V2_C : ABP_FireProcessorBase_C {
	struct UPointLightComponent* PointLight_Chimney; // 0x9f0(0x08)
	struct UStaticMeshComponent* SM_DEP_Furnace_Concrete_Proxy_Output_Ingot_4; // 0x9f8(0x08)
	struct UStaticMeshComponent* SM_DEP_Furnace_Concrete_Proxy_Output_Ingot_3; // 0xa00(0x08)
	struct UStaticMeshComponent* SM_DEP_Furnace_Concrete_Proxy_Output_Ingot_2; // 0xa08(0x08)
	struct UStaticMeshComponent* SM_DEP_Furnace_Concrete_Proxy_Input_Ore_4; // 0xa10(0x08)
	struct UStaticMeshComponent* SM_DEP_Furnace_Concrete_Proxy_Input_Ore_3; // 0xa18(0x08)
	struct UStaticMeshComponent* SM_DEP_Furnace_Concrete_Proxy_Input_Ore_2; // 0xa20(0x08)
	struct UNiagaraComponent* Niagara; // 0xa28(0x08)
	struct UPointLightComponent* PointLight_Left; // 0xa30(0x08)
	struct UPointLightComponent* PointLight_Right; // 0xa38(0x08)
	struct USpotLightComponent* SpotLight; // 0xa40(0x08)
	struct USceneComponent* Scene_Lights; // 0xa48(0x08)

	void UpdateEffects(bool Active); // Function BP_ConcreteFurnace_V2.BP_ConcreteFurnace_V2_C.UpdateEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UserConstructionScript(); // Function BP_ConcreteFurnace_V2.BP_ConcreteFurnace_V2_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

