// UserDefinedStruct ActorArrayStruct.ActorArrayStruct
// Size: 0x10 (Inherited: 0x00)
struct FActorArrayStruct {
	struct TArray<struct AActor*> ActorArray_3_5CDA33E84FAB094882AB2880391F8A0A; // 0x00(0x10)
};

