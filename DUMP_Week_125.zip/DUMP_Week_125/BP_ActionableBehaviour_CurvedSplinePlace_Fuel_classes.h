// BlueprintGeneratedClass BP_ActionableBehaviour_CurvedSplinePlace_Fuel.BP_ActionableBehaviour_CurvedSplinePlace_Fuel_C
// Size: 0x560 (Inherited: 0x560)
struct UBP_ActionableBehaviour_CurvedSplinePlace_Fuel_C : UBP_ActionableBehaviour_CurvedSplinePlace_C {
};

