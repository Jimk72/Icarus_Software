// BlueprintGeneratedClass BPQ_STYX_D_Recovery.BPQ_STYX_D_Recovery_C
// Size: 0x3c0 (Inherited: 0x390)
struct ABPQ_STYX_D_Recovery_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x398(0x08)
	struct ABP_Mount_Base_C* MiniHippo; // 0x3a0(0x08)
	struct FAISetupRowHandle AISetup; // 0x3a8(0x18)

	bool Check(); // Function BPQ_STYX_D_Recovery.BPQ_STYX_D_Recovery_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RunFlow(); // Function BPQ_STYX_D_Recovery.BPQ_STYX_D_Recovery_C.RunFlow // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveQuestEnded(bool bWasAbandoned); // Function BPQ_STYX_D_Recovery.BPQ_STYX_D_Recovery_C.ReceiveQuestEnded // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void Setup(bool bFirstTime); // Function BPQ_STYX_D_Recovery.BPQ_STYX_D_Recovery_C.Setup // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BPQ_STYX_D_Recovery(int32_t EntryPoint); // Function BPQ_STYX_D_Recovery.BPQ_STYX_D_Recovery_C.ExecuteUbergraph_BPQ_STYX_D_Recovery // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

