// BlueprintGeneratedClass BP_AlphaWolf_Trophy.BP_AlphaWolf_Trophy_C
// Size: 0x778 (Inherited: 0x761)
struct ABP_AlphaWolf_Trophy_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UGFurComponent* GFur; // 0x770(0x08)

	void ReceiveBeginPlay(); // Function BP_AlphaWolf_Trophy.BP_AlphaWolf_Trophy_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_AlphaWolf_Trophy(int32_t EntryPoint); // Function BP_AlphaWolf_Trophy.BP_AlphaWolf_Trophy_C.ExecuteUbergraph_BP_AlphaWolf_Trophy // (Final|UbergraphFunction) // @ game+0x1fb3630
};

