// BlueprintGeneratedClass BP_Actionable_Shovel.BP_Actionable_Shovel_C
// Size: 0x5a0 (Inherited: 0x3a0)
struct UBP_Actionable_Shovel_C : UBP_ActionableBehaviour_Generic_Melee_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	float SnowClearThresholdDegrees; // 0x3a8(0x04)
	char pad_3AC[0x4]; // 0x3ac(0x04)
	struct FItemData GainedResource; // 0x3b0(0x1f0)

	void OnActionHitEvent(struct AActor* Invoking Actor, struct UPrimitiveComponent* OverlappedComponent , struct FHitResult& SweepResult); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.OnActionHitEvent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Actionable_Shovel(int32_t EntryPoint); // Function BP_Actionable_Shovel.BP_Actionable_Shovel_C.ExecuteUbergraph_BP_Actionable_Shovel // (Final|UbergraphFunction) // @ game+0x1fb3630
};

