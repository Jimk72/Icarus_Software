// BlueprintGeneratedClass BP_CaveEntrance_CF_SML_02.BP_CaveEntrance_CF_SML_02_C
// Size: 0x330 (Inherited: 0x320)
struct ABP_CaveEntrance_CF_SML_02_C : ABP_BaseCaveEntrance_C {
	struct UStaticMeshComponent* StaticMesh02; // 0x320(0x08)
	struct UStaticMeshComponent* StaticMesh01; // 0x328(0x08)
};

