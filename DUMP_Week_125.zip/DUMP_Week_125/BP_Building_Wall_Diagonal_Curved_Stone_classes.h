// BlueprintGeneratedClass BP_Building_Wall_Diagonal_Curved_Stone.BP_Building_Wall_Diagonal_Curved_Stone_C
// Size: 0xbc8 (Inherited: 0xbc8)
struct ABP_Building_Wall_Diagonal_Curved_Stone_C : ABP_Building_Wall_Diagonal_Curved_C {
};

