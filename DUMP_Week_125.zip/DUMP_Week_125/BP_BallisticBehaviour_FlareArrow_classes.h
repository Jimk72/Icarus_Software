// BlueprintGeneratedClass BP_BallisticBehaviour_FlareArrow.BP_BallisticBehaviour_FlareArrow_C
// Size: 0x7bc (Inherited: 0x7a8)
struct UBP_BallisticBehaviour_FlareArrow_C : UBP_BallisticBehaviour_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7a8(0x08)
	bool HadUpwardsTrajectory; // 0x7b0(0x01)
	char pad_7B1[0x3]; // 0x7b1(0x03)
	float MaxSpeed; // 0x7b4(0x04)
	float GravityScale; // 0x7b8(0x04)

	void ReceiveTick(float DeltaSeconds); // Function BP_BallisticBehaviour_FlareArrow.BP_BallisticBehaviour_FlareArrow_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_BallisticBehaviour_FlareArrow.BP_BallisticBehaviour_FlareArrow_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_BallisticBehaviour_FlareArrow(int32_t EntryPoint); // Function BP_BallisticBehaviour_FlareArrow.BP_BallisticBehaviour_FlareArrow_C.ExecuteUbergraph_BP_BallisticBehaviour_FlareArrow // (Final|UbergraphFunction) // @ game+0x1fb3630
};

