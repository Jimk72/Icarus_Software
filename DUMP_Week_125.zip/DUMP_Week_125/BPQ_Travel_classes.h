// BlueprintGeneratedClass BPQ_Travel.BPQ_Travel_C
// Size: 0x3b0 (Inherited: 0x390)
struct ABPQ_Travel_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct UStaticMeshComponent* Location; // 0x398(0x08)
	struct USphereComponent* Sphere; // 0x3a0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3a8(0x08)

	bool Check(); // Function BPQ_Travel.BPQ_Travel_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void BndEvt__Sphere_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BPQ_Travel.BPQ_Travel_C.BndEvt__Sphere_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1fb3630
	void Overlap(); // Function BPQ_Travel.BPQ_Travel_C.Overlap // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BPQ_Travel(int32_t EntryPoint); // Function BPQ_Travel.BPQ_Travel_C.ExecuteUbergraph_BPQ_Travel // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

