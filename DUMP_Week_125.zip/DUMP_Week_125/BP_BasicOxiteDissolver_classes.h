// BlueprintGeneratedClass BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C
// Size: 0x7b8 (Inherited: 0x761)
struct ABP_BasicOxiteDissolver_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UStaticMeshComponent* Balloon; // 0x770(0x08)
	struct UNiagaraComponent* Niagara; // 0x778(0x08)
	struct UFMODAudioComponent* FMOD_Active_Audio; // 0x780(0x08)
	bool RequiresUpdate; // 0x788(0x01)
	char pad_789[0x3]; // 0x789(0x03)
	int32_t UnitsToTransfer; // 0x78c(0x04)
	struct UInventory* GeneralInventory; // 0x790(0x08)
	float FillScale; // 0x798(0x04)
	int32_t StoredUnits; // 0x79c(0x04)
	int32_t MaximumStoredUnits; // 0x7a0(0x04)
	char pad_7A4[0x4]; // 0x7a4(0x04)
	struct UFMODEvent* ConsumeOxygenSound; // 0x7a8(0x08)
	struct UFMODEvent* ActiveSound; // 0x7b0(0x08)

	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GeneratorStateUpdate(bool Active); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.GeneratorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Update_FmodParameters(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Update_FmodParameters // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Pickup(struct AActor* Instigator, bool& PickedUp); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Deployable_Pickup // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Leak(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Leak // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_FillScale(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.OnRep_FillScale // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FillableUnitsUpdated(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.FillableUnitsUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnInventoryItemAdded(struct UInventory* Inventory, int32_t Location); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.OnInventoryItemAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Multi_OnConsumeOxygen(struct AIcarusPlayerCharacter* Instigator); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Multi_OnConsumeOxygen // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void DeployableTick(float DeltaSeconds); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_BasicOxiteDissolver(int32_t EntryPoint); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.ExecuteUbergraph_BP_BasicOxiteDissolver // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

