// BlueprintGeneratedClass BP_AISpawner.BP_AISpawner_C
// Size: 0x7c8 (Inherited: 0x4e8)
struct ABP_AISpawner_C : AAISpawner {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4e8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x4f0(0x08)
	int32_t AmountToSpawn; // 0x4f8(0x04)
	char pad_4FC[0x4]; // 0x4fc(0x04)
	struct TArray<struct AActor*> SpawnedActors; // 0x500(0x10)
	float SpawnRadius; // 0x510(0x04)
	float MaxPlayerDistance; // 0x514(0x04)
	struct FVector SpawnLocation; // 0x518(0x0c)
	bool SpawningActivated; // 0x524(0x01)
	char pad_525[0x3]; // 0x525(0x03)
	struct TMap<struct APlayerController*, struct FActorArrayStruct> TetheredAIMap; // 0x528(0x50)
	struct APlayerController* NextTetherTarget; // 0x578(0x08)
	struct FActorArrayStruct CurrentTethers; // 0x580(0x10)
	struct FTimerHandle TetherCleanupTimer; // 0x590(0x08)
	struct FRandomStream RandomStream; // 0x598(0x08)
	struct TArray<struct UObject*> StoredGameplayTextures; // 0x5a0(0x10)
	struct TArray<struct TSoftObjectPtr<UGameplayTexture>> HeatmapTextures; // 0x5b0(0x10)
	struct AIcarusNPCGOAPCharacter* SpawnedNPC; // 0x5c0(0x08)
	int32_t DefaultSpawnDensity; // 0x5c8(0x04)
	bool IsRunningSpawnEQS; // 0x5cc(0x01)
	char pad_5CD[0x3]; // 0x5cd(0x03)
	struct TArray<struct AIcarusNPCGOAPCharacter*> SpawnedChildren; // 0x5d0(0x10)
	struct ABP_WeatherController_C* WeatherControllerRef; // 0x5e0(0x08)
	struct TMap<struct FBiomesRowHandle, int32_t> BiomePerceptionModifiers; // 0x5e8(0x50)
	struct FAISpawnConfigData Spawn Config; // 0x638(0xb0)
	enum class EBPLogVerbosity LoggingVerbosity; // 0x6e8(0x01)
	char pad_6E9[0x3]; // 0x6e9(0x03)
	int32_t MaximumAILevel; // 0x6ec(0x04)
	int32_t MinimumAILevel; // 0x6f0(0x04)
	int32_t GeneratedLevel; // 0x6f4(0x04)
	struct TMap<struct FVector, float> RecentSpawnBlockerLocations; // 0x6f8(0x50)
	bool ShouldBlockSpawningNearRecentDeath; // 0x748(0x01)
	char pad_749[0x7]; // 0x749(0x07)
	struct FTimerHandle SpawnBlockerUpdateTimer; // 0x750(0x08)
	float SpawnBlockerRadius; // 0x758(0x04)
	float SpawnBlockerDuration; // 0x75c(0x04)
	bool DebugSpawnBlockers; // 0x760(0x01)
	char pad_761[0x7]; // 0x761(0x07)
	struct TArray<struct FSpawnBlocker> ActiveSpawnBlockers; // 0x768(0x10)
	struct FName ProtectedActorKey; // 0x778(0x08)
	bool IsSpawningActor; // 0x780(0x01)
	char pad_781[0x3]; // 0x781(0x03)
	struct FAISetupRowHandle CurrentAISpawnType; // 0x784(0x18)
	bool SpawnMultipleAI; // 0x79c(0x01)
	char pad_79D[0x3]; // 0x79d(0x03)
	struct TArray<struct AIcarusNPCGOAPCharacter*> SpawnedFollowers; // 0x7a0(0x10)
	struct FEpicCreaturesRowHandle CurrentAIEpicCreature; // 0x7b0(0x18)

	void PrintDebugInformation(); // Function BP_AISpawner.BP_AISpawner_C.PrintDebugInformation // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	void NearWater(struct FVector Location, int32_t Distance, bool& NearWater); // Function BP_AISpawner.BP_AISpawner_C.NearWater // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ModifySpawnWeights(struct FVector AtLocation, int32_t WeightedListUID, struct TMap<struct FAISpawnListItemData, int32_t> BaseSpawnWeights); // Function BP_AISpawner.BP_AISpawner_C.ModifySpawnWeights // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void WantsSpawnJuvenile(struct FVector WorldLocation, struct FAISetupRowHandle ParentSetup, bool& WantsSpawn, struct FVector& position, struct FAISetupRowHandle& JuvenileType, int32_t& Level); // Function BP_AISpawner.BP_AISpawner_C.WantsSpawnJuvenile // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UntetherActor(struct AActor*& Actor); // Function BP_AISpawner.BP_AISpawner_C.UntetherActor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TrySpawnJuvenileAroundLocation(struct FVector WorldLocation, struct FAISetupRowHandle ParentSetup, struct AIcarusNPCGOAPCharacter*& JuvenileCharacter); // Function BP_AISpawner.BP_AISpawner_C.TrySpawnJuvenileAroundLocation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Check Manual Spawn(struct FAISetupEnum AISetup, bool& CanSpawn); // Function BP_AISpawner.BP_AISpawner_C.Check Manual Spawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetNumAliveNPCs(bool IncludeLatentDeaths, int32_t& Num); // Function BP_AISpawner.BP_AISpawner_C.GetNumAliveNPCs // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	bool GetDebugSpawnBlockers(); // Function BP_AISpawner.BP_AISpawner_C.GetDebugSpawnBlockers // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void OnNPCDeath(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function BP_AISpawner.BP_AISpawner_C.OnNPCDeath // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateSpawnBlockers(); // Function BP_AISpawner.BP_AISpawner_C.UpdateSpawnBlockers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetTetherDebugName(struct APlayerController* Tether, struct FName& Name); // Function BP_AISpawner.BP_AISpawner_C.GetTetherDebugName // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetTotalSpawnWeightForBiome(struct FVector Locarion, int32_t& TotalWeight); // Function BP_AISpawner.BP_AISpawner_C.GetTotalSpawnWeightForBiome // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetNearbyNPCs(struct FVector InOrigin, struct TArray<struct ABP_IcarusNPCGOAPCharacter_C*>& OutputNPCs); // Function BP_AISpawner.BP_AISpawner_C.GetNearbyNPCs // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	void GetModifiedSpawnWeightForAI(struct FAISetupRowHandle InAIType, struct FVector AtLocation, int32_t OriginalWeight, int32_t& ModifiedWeight); // Function BP_AISpawner.BP_AISpawner_C.GetModifiedSpawnWeightForAI // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Debug Biome Perception Modifiers(); // Function BP_AISpawner.BP_AISpawner_C.Debug Biome Perception Modifiers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateBiomePerceptionModifiers(); // Function BP_AISpawner.BP_AISpawner_C.UpdateBiomePerceptionModifiers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetSpawnDensityForLocation(struct FVector WorldLocation, int32_t& Biome Spawn Density); // Function BP_AISpawner.BP_AISpawner_C.GetSpawnDensityForLocation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReorganiseCleanupQueue(); // Function BP_AISpawner.BP_AISpawner_C.ReorganiseCleanupQueue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	int32_t GetNumberOfAINearTarget(struct AActor* Target); // Function BP_AISpawner.BP_AISpawner_C.GetNumberOfAINearTarget // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void PickNewAIToSpawn(struct FVector AtLocation, bool ManualSpawn, struct FAISetupRowHandle& Output, struct FEpicCreaturesRowHandle& EpicCreature, int32_t& Level, bool& ValidSpawn); // Function BP_AISpawner.BP_AISpawner_C.PickNewAIToSpawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TetherActor(struct AActor*& Actor, struct APlayerController*& TetherTarget); // Function BP_AISpawner.BP_AISpawner_C.TetherActor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CleanupDestroyedActors(); // Function BP_AISpawner.BP_AISpawner_C.CleanupDestroyedActors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TrySpawn(); // Function BP_AISpawner.BP_AISpawner_C.TrySpawn // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetNewTetherTarget(struct APlayerController*& OutControllerTether); // Function BP_AISpawner.BP_AISpawner_C.GetNewTetherTarget // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DebugDistances(); // Function BP_AISpawner.BP_AISpawner_C.DebugDistances // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FindSpawnLocation(struct FVector& Locaiton, bool& Return); // Function BP_AISpawner.BP_AISpawner_C.FindSpawnLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CheckLocation(struct FVector Location, bool& Found); // Function BP_AISpawner.BP_AISpawner_C.CheckLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	void CheckAIDistance(struct ABP_IcarusNPCGOAPCharacter_C* AI); // Function BP_AISpawner.BP_AISpawner_C.CheckAIDistance // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnLoaded_2B8B2B624CE5F97DAE6892B799469007(struct UObject* Loaded); // Function BP_AISpawner.BP_AISpawner_C.OnLoaded_2B8B2B624CE5F97DAE6892B799469007 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnLoaded_E484710A49B479B889B10EB5F9BB56D9(struct UObject* Loaded); // Function BP_AISpawner.BP_AISpawner_C.OnLoaded_E484710A49B479B889B10EB5F9BB56D9 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnLoaded_0C0CBC534E9E258D1E3E80AE2ECF2222(struct UObject* Loaded); // Function BP_AISpawner.BP_AISpawner_C.OnLoaded_0C0CBC534E9E258D1E3E80AE2ECF2222 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnLoaded_0D357C69493DD7DA680C14A251D6BA63(struct UObject* Loaded); // Function BP_AISpawner.BP_AISpawner_C.OnLoaded_0D357C69493DD7DA680C14A251D6BA63 // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_AISpawner.BP_AISpawner_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void SpawnActor(); // Function BP_AISpawner.BP_AISpawner_C.SpawnActor // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ValidateAndSpawn(); // Function BP_AISpawner.BP_AISpawner_C.ValidateAndSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EQSFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BP_AISpawner.BP_AISpawner_C.EQSFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TryDestroyAI(); // Function BP_AISpawner.BP_AISpawner_C.TryDestroyAI // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnEQSComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BP_AISpawner.BP_AISpawner_C.OnEQSComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnSeedUpdated(int32_t Seed); // Function BP_AISpawner.BP_AISpawner_C.OnSeedUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SpawnPointGenerationComplete(); // Function BP_AISpawner.BP_AISpawner_C.SpawnPointGenerationComplete // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void WeatherEventStarted(struct FBiomesRowHandle& Biome, struct FWeatherEventsRowHandle& Event); // Function BP_AISpawner.BP_AISpawner_C.WeatherEventStarted // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void WeatherEventCompleted(struct FBiomesRowHandle& Biome, struct FWeatherEventsRowHandle& Event); // Function BP_AISpawner.BP_AISpawner_C.WeatherEventCompleted // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnBiomePerceptionUpdated(int32_t NewValue, struct FBiomesRowHandle Biome); // Function BP_AISpawner.BP_AISpawner_C.OnBiomePerceptionUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveTick(float DeltaSeconds); // Function BP_AISpawner.BP_AISpawner_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void SetDebugSpawnBlockers(bool bEnabled); // Function BP_AISpawner.BP_AISpawner_C.SetDebugSpawnBlockers // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetupNPC(struct AIcarusNPCGOAPCharacter* SpawnedNPC); // Function BP_AISpawner.BP_AISpawner_C.SetupNPC // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UnlinkSpawnedNPC(struct AActor* NPC); // Function BP_AISpawner.BP_AISpawner_C.UnlinkSpawnedNPC // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MC_PreLoadClass(struct TSoftClassPtr<UObject> AssetClass); // Function BP_AISpawner.BP_AISpawner_C.MC_PreLoadClass // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_AISpawner(int32_t EntryPoint); // Function BP_AISpawner.BP_AISpawner_C.ExecuteUbergraph_BP_AISpawner // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

