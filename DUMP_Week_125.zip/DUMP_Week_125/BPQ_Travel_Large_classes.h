// BlueprintGeneratedClass BPQ_Travel_Large.BPQ_Travel_Large_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct ABPQ_Travel_Large_C : ABPQ_Travel_C {
};

