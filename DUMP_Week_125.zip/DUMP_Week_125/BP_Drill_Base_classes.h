// BlueprintGeneratedClass BP_Drill_Base.BP_Drill_Base_C
// Size: 0x7d2 (Inherited: 0x771)
struct ABP_Drill_Base_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_771[0x7]; // 0x771(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x778(0x08)
	struct UFMODAudioComponent* DrillActiveAudio; // 0x780(0x08)
	struct UCameraComponent* Camera; // 0x788(0x08)
	bool IsActive; // 0x790(0x01)
	char pad_791[0x3]; // 0x791(0x03)
	float CurrentTime; // 0x794(0x04)
	float MaxTime; // 0x798(0x04)
	char pad_79C[0x4]; // 0x79c(0x04)
	struct UFMODEvent* FMODEvent_Stop; // 0x7a0(0x08)
	struct UFMODEvent* FMODEvent_GenerateItem; // 0x7a8(0x08)
	struct UInventory* OreInventory; // 0x7b0(0x08)
	struct UInventory* FuelInventory; // 0x7b8(0x08)
	struct FStatsEnum DrillSpeedStat; // 0x7c0(0x10)
	bool IsEnergyDrill; // 0x7d0(0x01)
	enum class EIcarusResourceType FuelType; // 0x7d1(0x01)

	void IsFunctional(bool& bFunctional); // Function BP_Drill_Base.BP_Drill_Base_C.IsFunctional // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void CanStartDrill(bool& CanStart); // Function BP_Drill_Base.BP_Drill_Base_C.CanStartDrill // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void HasAnyRemainingInventorySpaceForOre(bool& HasAnyRemainingSpace); // Function BP_Drill_Base.BP_Drill_Base_C.HasAnyRemainingInventorySpaceForOre // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void SetDrillActive(bool Active); // Function BP_Drill_Base.BP_Drill_Base_C.SetDrillActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateMiningRateFromResourceType(); // Function BP_Drill_Base.BP_Drill_Base_C.UpdateMiningRateFromResourceType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void HasAnyResourcesRemaining(bool& HasResourcesRemaining); // Function BP_Drill_Base.BP_Drill_Base_C.HasAnyResourcesRemaining // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void PlayGenerateItemSFX(); // Function BP_Drill_Base.BP_Drill_Base_C.PlayGenerateItemSFX // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GenerateItem(); // Function BP_Drill_Base.BP_Drill_Base_C.GenerateItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_IsActive(); // Function BP_Drill_Base.BP_Drill_Base_C.OnRep_IsActive // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ActiveStateUpdated(); // Function BP_Drill_Base.BP_Drill_Base_C.ActiveStateUpdated // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Drill_Base.BP_Drill_Base_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnGeneratorActiveStateUpdated(bool IsActive); // Function BP_Drill_Base.BP_Drill_Base_C.OnGeneratorActiveStateUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_PlayGenerateItemFX(); // Function BP_Drill_Base.BP_Drill_Base_C.MULTI_PlayGenerateItemFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_Drill_Base.BP_Drill_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void OnOutOfResources(); // Function BP_Drill_Base.BP_Drill_Base_C.OnOutOfResources // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnOutOfInventorySpace(); // Function BP_Drill_Base.BP_Drill_Base_C.OnOutOfInventorySpace // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnGainedInventorySpace(); // Function BP_Drill_Base.BP_Drill_Base_C.OnGainedInventorySpace // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RestartDrill(); // Function BP_Drill_Base.BP_Drill_Base_C.RestartDrill // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ShutdownDrill(); // Function BP_Drill_Base.BP_Drill_Base_C.ShutdownDrill // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnInventoryModified(struct UInventory* Inventory, int32_t Location); // Function BP_Drill_Base.BP_Drill_Base_C.OnInventoryModified // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRestoreFoundationFromDatabase(struct AIcarusActor* FoundationFromDatabase); // Function BP_Drill_Base.BP_Drill_Base_C.OnRestoreFoundationFromDatabase // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void DeployableTick(float DeltaSeconds); // Function BP_Drill_Base.BP_Drill_Base_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceStartRunning(); // Function BP_Drill_Base.BP_Drill_Base_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceStopRunning(); // Function BP_Drill_Base.BP_Drill_Base_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnDeviceTurnedOn(); // Function BP_Drill_Base.BP_Drill_Base_C.OnDeviceTurnedOn // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Drill_Base(int32_t EntryPoint); // Function BP_Drill_Base.BP_Drill_Base_C.ExecuteUbergraph_BP_Drill_Base // (Final|UbergraphFunction) // @ game+0x1fb3630
};

