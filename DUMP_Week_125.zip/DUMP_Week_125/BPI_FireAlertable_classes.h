// BlueprintGeneratedClass BPI_FireAlertable.BPI_FireAlertable_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_FireAlertable_C : UInterface {

	void NotifyOfFire(struct FVector FireLocation, bool& WasNotified); // Function BPI_FireAlertable.BPI_FireAlertable_C.NotifyOfFire // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

