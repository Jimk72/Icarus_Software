// BlueprintGeneratedClass BP_CaveCheatMarker.BP_CaveCheatMarker_C
// Size: 0x258 (Inherited: 0x220)
struct ABP_CaveCheatMarker_C : AActor {
	struct UIcarusMapIconComponent* IcarusMapIcon; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
	struct TSoftObjectPtr<UCavePrefabAsset> Prefab; // 0x230(0x28)
};

