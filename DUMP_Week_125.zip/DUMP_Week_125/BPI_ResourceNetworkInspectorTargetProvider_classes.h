// BlueprintGeneratedClass BPI_ResourceNetworkInspectorTargetProvider.BPI_ResourceNetworkInspectorTargetProvider_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_ResourceNetworkInspectorTargetProvider_C : UInterface {

	void GetTargetNetworkType(enum class EIcarusResourceType& TargetNetworkType); // Function BPI_ResourceNetworkInspectorTargetProvider.BPI_ResourceNetworkInspectorTargetProvider_C.GetTargetNetworkType // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

