// BlueprintGeneratedClass BP_ActionableBehaviour_DropGItem.BP_ActionableBehaviour_DropGItem_C
// Size: 0x370 (Inherited: 0x368)
struct UBP_ActionableBehaviour_DropGItem_C : UBP_ActionableBehaviour_Hold_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x368(0x08)

	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_DropGItem.BP_ActionableBehaviour_DropGItem_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void DropItem(enum class EActionableEventType ActionType); // Function BP_ActionableBehaviour_DropGItem.BP_ActionableBehaviour_DropGItem_C.DropItem // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CancelDrop(); // Function BP_ActionableBehaviour_DropGItem.BP_ActionableBehaviour_DropGItem_C.CancelDrop // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_ActionableBehaviour_DropGItem(int32_t EntryPoint); // Function BP_ActionableBehaviour_DropGItem.BP_ActionableBehaviour_DropGItem_C.ExecuteUbergraph_BP_ActionableBehaviour_DropGItem // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

