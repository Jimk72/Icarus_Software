// BlueprintGeneratedClass BP_CF_FernB_03.BP_CF_FernB_03_C
// Size: 0x3d8 (Inherited: 0x3cc)
struct ABP_CF_FernB_03_C : ABP_ResourceNodeBase_C {
	char pad_3CC[0x4]; // 0x3cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)

	void ReceiveBeginPlay(); // Function BP_CF_FernB_03.BP_CF_FernB_03_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_CF_FernB_03(int32_t EntryPoint); // Function BP_CF_FernB_03.BP_CF_FernB_03_C.ExecuteUbergraph_BP_CF_FernB_03 // (Final|UbergraphFunction) // @ game+0x1fb3630
};

