// BlueprintGeneratedClass BP_Deep_Mining_Ice_Deposit_v2.BP_Deep_Mining_Ice_Deposit_v2_C
// Size: 0x3f0 (Inherited: 0x3f0)
struct ABP_Deep_Mining_Ice_Deposit_v2_C : ABP_Deep_Mining_Ore_Deposit_C {
};

