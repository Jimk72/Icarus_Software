// BlueprintGeneratedClass BP_Dehumidifier.BP_Dehumidifier_C
// Size: 0x7d8 (Inherited: 0x761)
struct ABP_Dehumidifier_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UNiagaraComponent* Niagara2; // 0x770(0x08)
	struct UNiagaraComponent* Niagara1; // 0x778(0x08)
	struct USceneComponent* Scene_Niagara; // 0x780(0x08)
	struct UPointLightComponent* PointLight7; // 0x788(0x08)
	struct UPointLightComponent* PointLight6; // 0x790(0x08)
	struct UPointLightComponent* PointLight5; // 0x798(0x08)
	struct UPointLightComponent* PointLight4; // 0x7a0(0x08)
	struct UPointLightComponent* PointLight3; // 0x7a8(0x08)
	struct UPointLightComponent* PointLight2; // 0x7b0(0x08)
	struct UPointLightComponent* PointLight1; // 0x7b8(0x08)
	struct USceneComponent* Scene_Lights; // 0x7c0(0x08)
	struct UFMODAudioComponent* FMOD_Active_Audio; // 0x7c8(0x08)
	struct UInventory* GeneralInventory; // 0x7d0(0x08)

	void GeneratorStateUpdate(bool Active); // Function BP_Dehumidifier.BP_Dehumidifier_C.GeneratorStateUpdate // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_Dehumidifier.BP_Dehumidifier_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void OnInventoryItemAdded(struct UInventory* Inventory, int32_t Location); // Function BP_Dehumidifier.BP_Dehumidifier_C.OnInventoryItemAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Dehumidifier(int32_t EntryPoint); // Function BP_Dehumidifier.BP_Dehumidifier_C.ExecuteUbergraph_BP_Dehumidifier // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

