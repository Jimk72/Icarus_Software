// BlueprintGeneratedClass BP_ActionableBehaviour_Scanner_DeepOre.BP_ActionableBehaviour_Scanner_DeepOre_C
// Size: 0x3ac (Inherited: 0x3ac)
struct UBP_ActionableBehaviour_Scanner_DeepOre_C : UBP_ActionableBehaviour_Scanner_C {
};

