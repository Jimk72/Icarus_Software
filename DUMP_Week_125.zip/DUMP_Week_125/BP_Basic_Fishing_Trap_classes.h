// BlueprintGeneratedClass BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C
// Size: 0x7b1 (Inherited: 0x761)
struct ABP_Basic_Fishing_Trap_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x770(0x08)
	struct UOverlapAudioComponent* OverlapAudio; // 0x778(0x08)
	struct UCameraComponent* Camera; // 0x780(0x08)
	struct USkeletalMeshComponent* Fish; // 0x788(0x08)
	struct UBP_BuoyancyComponent_C* BP_BuoyancyComponent; // 0x790(0x08)
	float InitialTimeToCatch; // 0x798(0x04)
	char pad_79C[0x4]; // 0x79c(0x04)
	struct UInventory* InventoryRef; // 0x7a0(0x08)
	struct FTimerHandle Timer; // 0x7a8(0x08)
	bool ShowFish; // 0x7b0(0x01)

	void WearLure(); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.WearLure // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_ShowFish(); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.OnRep_ShowFish // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetTimeToCatch(float& TimeToCatch); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.GetTimeToCatch // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void TimerCatchFish(); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.TimerCatchFish // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FishingLureChanged(struct UInventory* Inventory, int32_t Location); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.FishingLureChanged // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetChanceToCatch(int32_t& ChanceToCatch); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.GetChanceToCatch // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void AddToInventory(struct FItemData Item); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.AddToInventory // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DeployableTick(float DeltaSeconds); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OnInventoryUpdated(struct UInventory* Inventory, int32_t Location); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.OnInventoryUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Basic_Fishing_Trap(int32_t EntryPoint); // Function BP_Basic_Fishing_Trap.BP_Basic_Fishing_Trap_C.ExecuteUbergraph_BP_Basic_Fishing_Trap // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

