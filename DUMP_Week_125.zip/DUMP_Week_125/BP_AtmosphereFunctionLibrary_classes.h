// BlueprintGeneratedClass BP_AtmosphereFunctionLibrary.BP_AtmosphereFunctionLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_AtmosphereFunctionLibrary_C : UBlueprintFunctionLibrary {

	struct ABP_AtmosphereController_C* GetAtmosphereController(struct UObject* __WorldContext); // Function BP_AtmosphereFunctionLibrary.BP_AtmosphereFunctionLibrary_C.GetAtmosphereController // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
};

