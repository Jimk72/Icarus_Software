// BlueprintGeneratedClass BP_Deep_Mining_Ore_Deposit_Base.BP_Deep_Mining_Ore_Deposit_Base_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct ABP_Deep_Mining_Ore_Deposit_Base_C : ABP_OreDeposit_C {
};

