// BlueprintGeneratedClass BP_DropshipContainer.BP_DropshipContainer_C
// Size: 0x338 (Inherited: 0x330)
struct ABP_DropshipContainer_C : ABP_ContainerBase_C {
	struct UCameraComponent* Camera; // 0x330(0x08)

	void WorldObject_Interact(struct AActor* Instigator); // Function BP_DropshipContainer.BP_DropshipContainer_C.WorldObject_Interact // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

