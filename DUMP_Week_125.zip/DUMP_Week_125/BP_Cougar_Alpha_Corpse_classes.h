// BlueprintGeneratedClass BP_Cougar_Alpha_Corpse.BP_Cougar_Alpha_Corpse_C
// Size: 0x788 (Inherited: 0x780)
struct ABP_Cougar_Alpha_Corpse_C : ABP_GOAP_Corpse_C {
	struct UGFurComponent* GFur; // 0x780(0x08)

	void OnSkinnedStateUpdated(); // Function BP_Cougar_Alpha_Corpse.BP_Cougar_Alpha_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

