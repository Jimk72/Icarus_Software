// BlueprintGeneratedClass BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C
// Size: 0x480 (Inherited: 0x468)
struct UBP_ActionableBehaviour_SimplePlaceWithVariants_C : UBP_ActionableBehaviour_SimplePlace_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)
	struct UContextMenuWidget* CurrentRadialMenu; // 0x470(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* OwningPlayer; // 0x478(0x08)

	void CreateMenuItem(struct AContextMenuFactory* ContextMenuFactory, struct FContextMenuItemData& ContextMenuItemData, int32_t ItemIndex); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.CreateMenuItem // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetContextMenuItems(struct TArray<struct FContextMenuItemData>& MenuItems); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.GetContextMenuItems // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetContextMenuInfo(struct FText& MenuName, struct TSoftObjectPtr<UTexture2D>& MenuIcon); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.GetContextMenuInfo // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void LocalOrServer(bool& Local, bool& Server); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.LocalOrServer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetupPlayer(); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.SetupPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void OpenRadialMenu(); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.OpenRadialMenu // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CloseRadialMenu(); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.CloseRadialMenu // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MenuItemSelected(struct FName ItemIdentifier, int32_t ItemPayload); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.MenuItemSelected // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_ActionableBehaviour_SimplePlaceWithVariants(int32_t EntryPoint); // Function BP_ActionableBehaviour_SimplePlaceWithVariants.BP_ActionableBehaviour_SimplePlaceWithVariants_C.ExecuteUbergraph_BP_ActionableBehaviour_SimplePlaceWithVariants // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

