// BlueprintGeneratedClass BP_Beehive.BP_Beehive_C
// Size: 0x83d (Inherited: 0x761)
struct ABP_Beehive_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x770(0x08)
	struct USceneComponent* BeeBreedAudioLocation; // 0x778(0x08)
	struct USceneComponent* HoneyExtractorAudioLocation; // 0x780(0x08)
	struct UFMODAudioComponent* BeesHiveLoopAudio; // 0x788(0x08)
	struct UCameraComponent* Camera; // 0x790(0x08)
	struct UStaticMeshComponent* Expansion2; // 0x798(0x08)
	struct UStaticMeshComponent* Extractor; // 0x7a0(0x08)
	struct UStaticMeshComponent* BreedingCenter; // 0x7a8(0x08)
	struct UStaticMeshComponent* Expansion1; // 0x7b0(0x08)
	bool Installed_Expansion; // 0x7b8(0x01)
	bool Installed_Expansion2; // 0x7b9(0x01)
	bool Installed_Extractor; // 0x7ba(0x01)
	bool Installed_Breeding; // 0x7bb(0x01)
	float Honeycomb_CurrentTime; // 0x7bc(0x04)
	float Honeycomb_MaxTime; // 0x7c0(0x04)
	struct FItemTemplateRowHandle Honeycomb; // 0x7c4(0x18)
	float Extraction_CurrentTime; // 0x7dc(0x04)
	float Extraction_MaxTime; // 0x7e0(0x04)
	struct FItemTemplateRowHandle Honey; // 0x7e4(0x18)
	struct FItemTemplateRowHandle Beeswax; // 0x7fc(0x18)
	float Breeding_MaxTime; // 0x814(0x04)
	float Breeding_CurrentTime; // 0x818(0x04)
	struct FItemTemplateRowHandle Worker_Bee; // 0x81c(0x18)
	bool CachedInstalledExpansion; // 0x834(0x01)
	bool CachedInstalledExpansion2; // 0x835(0x01)
	char pad_836[0x2]; // 0x836(0x02)
	int32_t AuraUID; // 0x838(0x04)
	bool CachedBeehiveState; // 0x83c(0x01)

	bool IsSlotValidForItem(struct UInventoryComponent* Inventory, struct FInventoryIDEnum InventoryID, struct FItemData Item, int32_t SlotIndex); // Function BP_Beehive.BP_Beehive_C.IsSlotValidForItem // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void CheckWantsPower(); // Function BP_Beehive.BP_Beehive_C.CheckWantsPower // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FindFirstHoneycombInInventory(bool& Found, struct UInventory*& Inventory, int32_t& Slot); // Function BP_Beehive.BP_Beehive_C.FindFirstHoneycombInInventory // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TickExtractor(float DeltaTime); // Function BP_Beehive.BP_Beehive_C.TickExtractor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetUpgradeStats(int32_t Slot, struct TMap<struct FBaseStatsEnum, int32_t>& Additional Stats); // Function BP_Beehive.BP_Beehive_C.GetUpgradeStats // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GeneratorStateUpdate(bool Active); // Function BP_Beehive.BP_Beehive_C.GeneratorStateUpdate // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateExpansions(); // Function BP_Beehive.BP_Beehive_C.UpdateExpansions // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GenerateItem(struct FItemTemplateRowHandle RowHandle, struct FInventoryIDEnum InventoryID); // Function BP_Beehive.BP_Beehive_C.GenerateItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Beehive.BP_Beehive_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_Installed_Breeding(); // Function BP_Beehive.BP_Beehive_C.OnRep_Installed_Breeding // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_Installed_Extractor(); // Function BP_Beehive.BP_Beehive_C.OnRep_Installed_Extractor // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_Installed_Expansion2(); // Function BP_Beehive.BP_Beehive_C.OnRep_Installed_Expansion2 // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CanInstallExpansion(struct FItemData Item, bool& Success); // Function BP_Beehive.BP_Beehive_C.CanInstallExpansion // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_Installed_Expansion(); // Function BP_Beehive.BP_Beehive_C.OnRep_Installed_Expansion // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Add Expansion(struct FItemData Item, bool& Success); // Function BP_Beehive.BP_Beehive_C.Add Expansion // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnHighlightChanged(struct UHighlightableComponent* Highlightable, struct UPrimitiveComponent* Component, bool bHighlighted); // Function BP_Beehive.BP_Beehive_C.OnHighlightChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void IcarusBeginPlay(); // Function BP_Beehive.BP_Beehive_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveTick(float DeltaSeconds); // Function BP_Beehive.BP_Beehive_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void InventoryUpdated(struct UInventory* Inventory, int32_t Location); // Function BP_Beehive.BP_Beehive_C.InventoryUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnInventoryItemChanged(struct UInventory* Inventory, int32_t Location); // Function BP_Beehive.BP_Beehive_C.OnInventoryItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_Play Honeycome Crafted(); // Function BP_Beehive.BP_Beehive_C.MULTI_Play Honeycome Crafted // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI_Play Honey Crafted(); // Function BP_Beehive.BP_Beehive_C.MULTI_Play Honey Crafted // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MULTI Bee Breed Audio(); // Function BP_Beehive.BP_Beehive_C.MULTI Bee Breed Audio // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Beehive(int32_t EntryPoint); // Function BP_Beehive.BP_Beehive_C.ExecuteUbergraph_BP_Beehive // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

