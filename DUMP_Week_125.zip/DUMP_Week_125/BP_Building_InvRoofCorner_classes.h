// BlueprintGeneratedClass BP_Building_InvRoofCorner.BP_Building_InvRoofCorner_C
// Size: 0xbd8 (Inherited: 0xbd8)
struct ABP_Building_InvRoofCorner_C : ABP_Building_Ramp_C {
};

