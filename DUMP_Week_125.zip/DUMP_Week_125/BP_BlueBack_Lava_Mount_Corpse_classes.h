// BlueprintGeneratedClass BP_BlueBack_Lava_Mount_Corpse.BP_BlueBack_Lava_Mount_Corpse_C
// Size: 0x788 (Inherited: 0x788)
struct ABP_BlueBack_Lava_Mount_Corpse_C : ABP_GOAP_Corpse_Mount_C {
};

