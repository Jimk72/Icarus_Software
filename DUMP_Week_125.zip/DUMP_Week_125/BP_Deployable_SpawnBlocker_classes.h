// BlueprintGeneratedClass BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C
// Size: 0x77d (Inherited: 0x761)
struct ABP_Deployable_SpawnBlocker_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UBPQC_SearchArea_C* BPQC_SearchArea; // 0x770(0x08)
	int32_t SpawnBlockerRadius; // 0x778(0x04)
	bool SpawnBlockerActive; // 0x77c(0x01)

	int32_t GetSpawnBlockerEffectiveRadius(); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.GetSpawnBlockerEffectiveRadius // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1fb3630
	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_SpawnBlockerRadius(); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.OnRep_SpawnBlockerRadius // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_SpawnBlockerActive(); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.OnRep_SpawnBlockerActive // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateSpawnBlockerEffects(); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.UpdateSpawnBlockerEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateRadius(int32_t SpawnRadius); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.UpdateRadius // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DeployableTick(float DeltaSeconds); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Deployable_SpawnBlocker(int32_t EntryPoint); // Function BP_Deployable_SpawnBlocker.BP_Deployable_SpawnBlocker_C.ExecuteUbergraph_BP_Deployable_SpawnBlocker // (Final|UbergraphFunction) // @ game+0x1fb3630
};

