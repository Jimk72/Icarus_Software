// BlueprintGeneratedClass BP_Bed_Wood.BP_Bed_Wood_C
// Size: 0x7b0 (Inherited: 0x7a0)
struct ABP_Bed_Wood_C : ABP_BedBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7a0(0x08)
	struct UGFurComponent* GFur; // 0x7a8(0x08)

	void ReceiveBeginPlay(); // Function BP_Bed_Wood.BP_Bed_Wood_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Bed_Wood(int32_t EntryPoint); // Function BP_Bed_Wood.BP_Bed_Wood_C.ExecuteUbergraph_BP_Bed_Wood // (Final|UbergraphFunction) // @ game+0x1fb3630
};

