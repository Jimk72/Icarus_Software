// BlueprintGeneratedClass BP_AtmosphereController.BP_AtmosphereController_C
// Size: 0x79d (Inherited: 0x2c0)
struct ABP_AtmosphereController_C : AIcarusActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct UPostProcessComponent* PostProcess_GL; // 0x2c8(0x08)
	struct UPostProcessComponent* PostProcess_CF; // 0x2d0(0x08)
	struct UPostProcessComponent* PostProcess_Fire; // 0x2d8(0x08)
	struct UPostProcessComponent* PostProcess_SandStorm; // 0x2e0(0x08)
	struct UPostProcessComponent* PostProcess_Base; // 0x2e8(0x08)
	struct UPostProcessComponent* PostProcess_WL; // 0x2f0(0x08)
	struct UPostProcessComponent* PostProcess_AC; // 0x2f8(0x08)
	struct UPostProcessComponent* PostProcess_DC; // 0x300(0x08)
	struct UPostProcessComponent* PostProcess_LC; // 0x308(0x08)
	struct USceneComponent* PostProcesss; // 0x310(0x08)
	struct UStaticMeshComponent* Sphere; // 0x318(0x08)
	struct UStaticMeshComponent* SunPos; // 0x320(0x08)
	struct UStaticMeshComponent* SM_PlanetCard6; // 0x328(0x08)
	struct UStaticMeshComponent* SM_PlanetCard5; // 0x330(0x08)
	struct UStaticMeshComponent* SM_PlanetCard4; // 0x338(0x08)
	struct UStaticMeshComponent* SM_PlanetCard3; // 0x340(0x08)
	struct UStaticMeshComponent* SM_PlanetCard2; // 0x348(0x08)
	struct UStaticMeshComponent* SM_PlanetCard1; // 0x350(0x08)
	struct UStaticMeshComponent* SM_PlanetCard; // 0x358(0x08)
	struct USceneComponent* SkyPlanets; // 0x360(0x08)
	struct UBP_CaveLightController_C* BP_CaveLightController; // 0x368(0x08)
	struct UVolumetricCloudComponent* VolumetricCloud; // 0x370(0x08)
	struct USkyAtmosphereComponent* SkyAtmosphere; // 0x378(0x08)
	struct UStaticMeshComponent* SkySphere; // 0x380(0x08)
	struct UDirectionalLightComponent* MoonLight; // 0x388(0x08)
	struct USceneComponent* MoonOffset; // 0x390(0x08)
	struct USceneComponent* Moon; // 0x398(0x08)
	struct UDirectionalLightComponent* SunLight; // 0x3a0(0x08)
	struct UExponentialHeightFogComponent* ExponentialHeightFog; // 0x3a8(0x08)
	struct USkyLightComponent* SkyLight; // 0x3b0(0x08)
	struct UChildActorComponent* WindDirectionalSource; // 0x3b8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3c0(0x08)
	int32_t StartHour; // 0x3c8(0x04)
	float StartMinute; // 0x3cc(0x04)
	struct UCurveFloat* CurveWeatherWind; // 0x3d0(0x08)
	bool Enabled; // 0x3d8(0x01)
	char pad_3D9[0x3]; // 0x3d9(0x03)
	float SnowcapHeight; // 0x3dc(0x04)
	float SunRoll; // 0x3e0(0x04)
	float BiomeInfluenceCF; // 0x3e4(0x04)
	float BiomeInfluenceLC; // 0x3e8(0x04)
	float BiomeInfluenceDC; // 0x3ec(0x04)
	float BiomeInfluenceAC; // 0x3f0(0x04)
	float BiomeInfluenceWL; // 0x3f4(0x04)
	float RainAmountCF; // 0x3f8(0x04)
	float StormAmountCF; // 0x3fc(0x04)
	float RainAmountLC; // 0x400(0x04)
	float StormAmountLC; // 0x404(0x04)
	float RainAmountDC; // 0x408(0x04)
	float StormAmountDC; // 0x40c(0x04)
	float RainAmountAC; // 0x410(0x04)
	float StormAmountAC; // 0x414(0x04)
	float RainAmountWL; // 0x418(0x04)
	float StormAmountWL; // 0x41c(0x04)
	bool Debug_Wind; // 0x420(0x01)
	char pad_421[0x3]; // 0x421(0x03)
	float BiomeInfluenceGL; // 0x424(0x04)
	enum class EBiomes CurrentBiome; // 0x428(0x01)
	char pad_429[0x3]; // 0x429(0x03)
	float TransitionValue; // 0x42c(0x04)
	bool SpineTransition; // 0x430(0x01)
	char pad_431[0x3]; // 0x431(0x03)
	float BiomeInfluenceCave; // 0x434(0x04)
	struct UCurveFloat* CurveNightSky; // 0x438(0x08)
	float FogOffset; // 0x440(0x04)
	float SunDirection; // 0x444(0x04)
	struct UCurveFloat* CurveSunIntensity; // 0x448(0x08)
	struct UCurveFloat* CurveSkylightIntensity; // 0x450(0x08)
	struct UCurveLinearColor* CurveSunColour; // 0x458(0x08)
	bool AutoTransition; // 0x460(0x01)
	char pad_461[0x7]; // 0x461(0x07)
	struct UCurveFloat* TimeScaleCurve; // 0x468(0x08)
	float MoonRoll; // 0x470(0x04)
	float FogHeight; // 0x474(0x04)
	struct UCurveFloat* CurveMoonIntensity; // 0x478(0x08)
	float WeatherVal_Rain; // 0x480(0x04)
	float WeatherVal_SandStorm; // 0x484(0x04)
	float WeatherVal_Snow; // 0x488(0x04)
	float WeatherVal_Cloudy; // 0x48c(0x04)
	float WeatherVal_Thunder; // 0x490(0x04)
	char pad_494[0x4]; // 0x494(0x04)
	struct UMaterialInstanceDynamic* DynamicCloudMaterial; // 0x498(0x08)
	float WeatherVal_SnowStorm; // 0x4a0(0x04)
	float CONT_DistFogScale_CF; // 0x4a4(0x04)
	float CONT_DistFogScale_Cave; // 0x4a8(0x04)
	float CONT_DistFogScale_LC; // 0x4ac(0x04)
	float CONT_DistFogScale_AC; // 0x4b0(0x04)
	float CONT_DistFogScale_DC; // 0x4b4(0x04)
	float CONT_DistFogScale_WL; // 0x4b8(0x04)
	char pad_4BC[0x4]; // 0x4bc(0x04)
	struct FBiomesEnum PlayerBiome; // 0x4c0(0x10)
	struct FBiomesEnum PlayerNewBiome; // 0x4d0(0x10)
	struct UTexture* CloudMAP; // 0x4e0(0x08)
	float DropshipOverride; // 0x4e8(0x04)
	float WeatherVal_WindSpeed; // 0x4ec(0x04)
	float WeatherVal_WindStrength; // 0x4f0(0x04)
	float WeatherVal_WindMaxGustAmount; // 0x4f4(0x04)
	float WeatherVal_WindMinGustAmount; // 0x4f8(0x04)
	char pad_4FC[0x4]; // 0x4fc(0x04)
	struct UCurveFloat* CurveContactShadow; // 0x500(0x08)
	float WeatherVal_Debris; // 0x508(0x04)
	float OverrideWindSpeed; // 0x50c(0x04)
	float OverrideWindStrength; // 0x510(0x04)
	bool UpdateWeather; // 0x514(0x01)
	char pad_515[0x3]; // 0x515(0x03)
	struct UCurveFloat* CloudCoverageFogCurve; // 0x518(0x08)
	struct FMulticastInlineDelegate SunLightDirection; // 0x520(0x10)
	struct FMulticastInlineDelegate SunLightColor; // 0x530(0x10)
	float WeatherVal_FogDensity; // 0x540(0x04)
	float WeatherVal_FogExtinction; // 0x544(0x04)
	struct FLinearColor Color_2; // 0x548(0x10)
	float Intensity_2; // 0x558(0x04)
	struct FRotator SunDirection_2; // 0x55c(0x0c)
	struct UCurveFloat* CaveLightCurve; // 0x568(0x08)
	struct TArray<struct AWT_CaveVolume_C*> CaveVolumesInUse; // 0x570(0x10)
	float CaveInfluence; // 0x580(0x04)
	char pad_584[0x4]; // 0x584(0x04)
	struct UCurveFloat* CurvePlanetSunDirection; // 0x588(0x08)
	struct FRotator WindRotation; // 0x590(0x0c)
	bool useWeatherMan; // 0x59c(0x01)
	char pad_59D[0x3]; // 0x59d(0x03)
	struct UCurveLinearColor* LocalFogTimeOfDay; // 0x5a0(0x08)
	struct UCurveFloat* CurveShadowCascades; // 0x5a8(0x08)
	float ImpassableSnowOffset; // 0x5b0(0x04)
	char pad_5B4[0x4]; // 0x5b4(0x04)
	struct UCurveLinearColor* CURVE_FogTint_CF; // 0x5b8(0x08)
	struct UCurveLinearColor* CURVE_FogTint_AC; // 0x5c0(0x08)
	struct UCurveLinearColor* CURVE_FogTint_DC; // 0x5c8(0x08)
	struct UCurveLinearColor* CURVE_FogTint_Cave; // 0x5d0(0x08)
	struct UCurveLinearColor* CURVE_FogTint_LC; // 0x5d8(0x08)
	struct UCurveLinearColor* CURVE_FogTint_WL; // 0x5e0(0x08)
	struct UCurveFloat* CURVE_SunIntensity_CF; // 0x5e8(0x08)
	struct UCurveFloat* CURVE_SunIntensity_AC; // 0x5f0(0x08)
	struct UCurveFloat* CURVE_SunIntensity_DC; // 0x5f8(0x08)
	struct UCurveFloat* CURVE_SunIntensity_LC; // 0x600(0x08)
	struct UCurveFloat* CURVE_SunIntensity_WL; // 0x608(0x08)
	struct UCurveFloat* CURVE_SunIntensity_Cave; // 0x610(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_CF; // 0x618(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_AC; // 0x620(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_DC; // 0x628(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_Cave; // 0x630(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_LC; // 0x638(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_WL; // 0x640(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_CF; // 0x648(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_AC; // 0x650(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_DC; // 0x658(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_Cave; // 0x660(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_LC; // 0x668(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_WL; // 0x670(0x08)
	float SunBrightness; // 0x678(0x04)
	char pad_67C[0x4]; // 0x67c(0x04)
	struct UCurveLinearColor* CURVE_AtmosSun_CF; // 0x680(0x08)
	struct UCurveLinearColor* CURVE_AtmosSun_AC; // 0x688(0x08)
	struct UCurveLinearColor* CURVE_AtmosSun_DC; // 0x690(0x08)
	struct UCurveLinearColor* CURVE_AtmosSun_Cave; // 0x698(0x08)
	struct UCurveLinearColor* CURVE_AtmosSun_LC; // 0x6a0(0x08)
	struct UCurveLinearColor* CURVE_AtmosSun_WL; // 0x6a8(0x08)
	float MoonThreshold; // 0x6b0(0x04)
	char pad_6B4[0x4]; // 0x6b4(0x04)
	struct UCurveFloat* CURVE_MoonIntensity_CF; // 0x6b8(0x08)
	struct UCurveVector* CURVE_BloomSettings_CF; // 0x6c0(0x08)
	struct UCurveFloat* CURVE_MoonIntensity_AC; // 0x6c8(0x08)
	struct UCurveVector* CURVE_BloomSettings_AC; // 0x6d0(0x08)
	struct UCurveFloat* CURVE_MoonIntensity_DC; // 0x6d8(0x08)
	struct UCurveFloat* CURVE_MoonIntensity_Cave; // 0x6e0(0x08)
	struct UCurveFloat* CURVE_MoonIntensity_LC; // 0x6e8(0x08)
	struct UCurveFloat* CURVE_MoonIntensity_WL; // 0x6f0(0x08)
	struct FLinearColor MoonLightColor; // 0x6f8(0x10)
	bool Use Sun Atmosphere for moon; // 0x708(0x01)
	bool UseLowShadowSettings; // 0x709(0x01)
	bool OverrideLightSettings; // 0x70a(0x01)
	bool WeathermanActive; // 0x70b(0x01)
	float RealTimeThisFrame; // 0x70c(0x04)
	float TimeTotalThisFrame; // 0x710(0x04)
	float WeatherVal_Ash; // 0x714(0x04)
	float WeatherVal_Embers; // 0x718(0x04)
	float WeatherVal_Smoke; // 0x71c(0x04)
	float WeatherVal_AcidRain; // 0x720(0x04)
	float WeatherVal_Hail; // 0x724(0x04)
	struct UCurveLinearColor* CURVE_FogTint_GL; // 0x728(0x08)
	struct UCurveFloat* CURVE_SunIntensity_GL; // 0x730(0x08)
	struct UCurveFloat* CURVE_SkyLightIntensity_GL; // 0x738(0x08)
	struct UCurveFloat* CURVE_OvercastScattering_GL; // 0x740(0x08)
	struct UCurveLinearColor* CURVE_AtmosSun_GL; // 0x748(0x08)
	struct UCurveFloat* CURVE_MoonIntensity_GL; // 0x750(0x08)
	float RainAmountGL; // 0x758(0x04)
	float StormAmountGL; // 0x75c(0x04)
	float CONT_DistFogScale_GL; // 0x760(0x04)
	char pad_764[0x4]; // 0x764(0x04)
	struct UCurveVector* CURVE_BloomSettings_DC; // 0x768(0x08)
	struct UCurveVector* CURVE_BloomSettings_Cave; // 0x770(0x08)
	struct UCurveVector* CURVE_BloomSettings_LC; // 0x778(0x08)
	struct UCurveVector* CURVE_BloomSettings_WL; // 0x780(0x08)
	struct UCurveVector* CURVE_BloomSettings_GL; // 0x788(0x08)
	struct FVector CurrentBloomSettings; // 0x790(0x0c)
	bool BloomActive; // 0x79c(0x01)

	void CheckShadowQualitySetting(); // Function BP_AtmosphereController.BP_AtmosphereController_C.CheckShadowQualitySetting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetFogTintPerBiome(struct FLinearColor& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetFogTintPerBiome // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	struct FVector GetBloomSettingsPerBiome(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetBloomSettingsPerBiome // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetAtmosSunColorPerBiome(struct FLinearColor& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetAtmosSunColorPerBiome // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetMoonBrightnessPerBiome(float& Out); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetMoonBrightnessPerBiome // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetSunBrightnessPerBiome(float& OutBrightness); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetSunBrightnessPerBiome // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetSunColorPerBiome(struct FLinearColor& OutColor); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetSunColorPerBiome // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void UpdateBloomSettings(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateBloomSettings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	struct FAtmospheresEnum GetAtmosphereType(struct FBiomesEnum Biome); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetAtmosphereType // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	float GetCurrentTimeRealTime(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeRealTime // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	float GetCurrentTimeNormalized(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeNormalized // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	float GetCurrentTimeTotal(); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeTotal // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void FogTimeOfDay(); // Function BP_AtmosphereController.BP_AtmosphereController_C.FogTimeOfDay // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RemoveCaveVolume(struct AWT_CaveVolume_C* Volume); // Function BP_AtmosphereController.BP_AtmosphereController_C.RemoveCaveVolume // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void AddCaveVolume(struct AWT_CaveVolume_C* Volume); // Function BP_AtmosphereController.BP_AtmosphereController_C.AddCaveVolume // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void WeatherVisualUpdated(); // Function BP_AtmosphereController.BP_AtmosphereController_C.WeatherVisualUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void LinearBiomeTransition(struct FBiomesEnum PlayerNewBiome); // Function BP_AtmosphereController.BP_AtmosphereController_C.LinearBiomeTransition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TransitionWeather(struct FBiomesEnum FromBiome, struct FBiomesEnum ToBiome, float Amount); // Function BP_AtmosphereController.BP_AtmosphereController_C.TransitionWeather // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetDistFogScale(struct FVector& Scale); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetDistFogScale // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void GetCloudCoverage(float& Coverage, float& CoverageNoClamp); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCloudCoverage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void UpdateCloudCoverage(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateCloudCoverage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void MoonSetRotation(); // Function BP_AtmosphereController.BP_AtmosphereController_C.MoonSetRotation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateBiomeMPCs(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateBiomeMPCs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdateWeatherMPCs(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateWeatherMPCs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SkylightSetProperties(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SkylightSetProperties // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void FogSetProperties(); // Function BP_AtmosphereController.BP_AtmosphereController_C.FogSetProperties // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SunSetProperties(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunSetProperties // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SunSetRotation(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunSetRotation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	float GetBiomeInfluence(struct FBiomesEnum Biome); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetBiomeInfluence // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void Transition Biome(struct FBiomesEnum FromBiome, struct FBiomesEnum ToBiome, float Amount); // Function BP_AtmosphereController.BP_AtmosphereController_C.Transition Biome // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CycleBiome(); // Function BP_AtmosphereController.BP_AtmosphereController_C.CycleBiome // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ForceSetBiome(struct FBiomesEnum Biome); // Function BP_AtmosphereController.BP_AtmosphereController_C.ForceSetBiome // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Fog Track Player(); // Function BP_AtmosphereController.BP_AtmosphereController_C.Fog Track Player // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UpdatePostProcessing(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdatePostProcessing // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetBiomeInfo(float& CF, float& LC, float& DC, float& AC, float& WL, float& GL); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetBiomeInfo // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void UpdateWind(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UpdateWind // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SetTerrainDetails(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SetTerrainDetails // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void EditorReset(); // Function BP_AtmosphereController.BP_AtmosphereController_C.EditorReset // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Update Atmosphere Settings(); // Function BP_AtmosphereController.BP_AtmosphereController_C.Update Atmosphere Settings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetCurrentTimeOfDay(float& Total, float& Normalized, float& Realtime); // Function BP_AtmosphereController.BP_AtmosphereController_C.GetCurrentTimeOfDay // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void UserConstructionScript(); // Function BP_AtmosphereController.BP_AtmosphereController_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CheckBiome(); // Function BP_AtmosphereController.BP_AtmosphereController_C.CheckBiome // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_AtmosphereController.BP_AtmosphereController_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveTick(float DeltaSeconds); // Function BP_AtmosphereController.BP_AtmosphereController_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void SlowTickUpdates(); // Function BP_AtmosphereController.BP_AtmosphereController_C.SlowTickUpdates // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_AtmosphereController(int32_t EntryPoint); // Function BP_AtmosphereController.BP_AtmosphereController_C.ExecuteUbergraph_BP_AtmosphereController // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
	void SunLightColor__DelegateSignature(struct FLinearColor Color, float Intensity, float CaveCover); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunLightColor__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void SunLightDirection__DelegateSignature(struct FRotator SunDirection); // Function BP_AtmosphereController.BP_AtmosphereController_C.SunLightDirection__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

