// BlueprintGeneratedClass BP_Door_Curtain_Fur.BP_Door_Curtain_Fur_C
// Size: 0x780 (Inherited: 0x761)
struct ABP_Door_Curtain_Fur_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UBoxComponent* InteractionCollision; // 0x770(0x08)
	struct UCapsuleComponent* BlockingCapsule; // 0x778(0x08)

	void ReceiveBeginPlay(); // Function BP_Door_Curtain_Fur.BP_Door_Curtain_Fur_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Door_Curtain_Fur(int32_t EntryPoint); // Function BP_Door_Curtain_Fur.BP_Door_Curtain_Fur_C.ExecuteUbergraph_BP_Door_Curtain_Fur // (Final|UbergraphFunction) // @ game+0x1fb3630
};

