// BlueprintGeneratedClass BP_Door_Wood.BP_Door_Wood_C
// Size: 0x7a4 (Inherited: 0x7a4)
struct ABP_Door_Wood_C : ABP_Door_Base_C {
};

