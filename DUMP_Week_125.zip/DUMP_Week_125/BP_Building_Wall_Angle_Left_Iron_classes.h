// BlueprintGeneratedClass BP_Building_Wall_Angle_Left_Iron.BP_Building_Wall_Angle_Left_Iron_C
// Size: 0xbd8 (Inherited: 0xbd0)
struct ABP_Building_Wall_Angle_Left_Iron_C : ABP_Building_Wall_Half_Angle_L_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd0(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Wall_Angle_Left_Iron.BP_Building_Wall_Angle_Left_Iron_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Building_Wall_Angle_Left_Iron(int32_t EntryPoint); // Function BP_Building_Wall_Angle_Left_Iron.BP_Building_Wall_Angle_Left_Iron_C.ExecuteUbergraph_BP_Building_Wall_Angle_Left_Iron // (Final|UbergraphFunction) // @ game+0x1fb3630
};

