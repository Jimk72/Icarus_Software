// BlueprintGeneratedClass BP_Door_Glass.BP_Door_Glass_C
// Size: 0x7b0 (Inherited: 0x7a4)
struct ABP_Door_Glass_C : ABP_Door_Base_C {
	char pad_7A4[0x4]; // 0x7a4(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7a8(0x08)

	void ReceiveBeginPlay(); // Function BP_Door_Glass.BP_Door_Glass_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Door_Glass(int32_t EntryPoint); // Function BP_Door_Glass.BP_Door_Glass_C.ExecuteUbergraph_BP_Door_Glass // (Final|UbergraphFunction) // @ game+0x1fb3630
};

