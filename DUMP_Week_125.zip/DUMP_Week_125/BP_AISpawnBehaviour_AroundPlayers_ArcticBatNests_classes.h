// BlueprintGeneratedClass BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C
// Size: 0x158 (Inherited: 0x148)
struct UBP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C : UBP_AISpawnBehaviour_AroundPlayers_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x148(0x08)
	float MinTimeBetweenSpawns; // 0x150(0x04)
	float LastSpawnTime; // 0x154(0x04)

	bool TrySpawnAI(struct UObject* WorldContextObject); // Function BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C.TrySpawnAI // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	bool CanCleanupAI(struct AActor* AI); // Function BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C.CanCleanupAI // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void TrySpawnAsync(struct AActor* AroundPlayer); // Function BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C.TrySpawnAsync // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void DoSpawn(struct UObject* Context, struct FVector SpawnLocation); // Function BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C.DoSpawn // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C.QueryFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests(int32_t EntryPoint); // Function BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests.BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests_C.ExecuteUbergraph_BP_AISpawnBehaviour_AroundPlayers_ArcticBatNests // (Final|UbergraphFunction) // @ game+0x1fb3630
};

