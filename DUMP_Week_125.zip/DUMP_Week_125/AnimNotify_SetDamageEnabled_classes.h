// BlueprintGeneratedClass AnimNotify_SetDamageEnabled.AnimNotify_SetDamageEnabled_C
// Size: 0x39 (Inherited: 0x38)
struct UAnimNotify_SetDamageEnabled_C : UAnimNotify {
	bool DamageEnabled; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_SetDamageEnabled.AnimNotify_SetDamageEnabled_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	struct FString GetNotifyName(); // Function AnimNotify_SetDamageEnabled.AnimNotify_SetDamageEnabled_C.GetNotifyName // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
};

