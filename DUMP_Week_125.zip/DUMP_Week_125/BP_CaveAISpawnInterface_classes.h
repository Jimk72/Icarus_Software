// BlueprintGeneratedClass BP_CaveAISpawnInterface.BP_CaveAISpawnInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_CaveAISpawnInterface_C : UInterface {

	void OnAdditionalActorSpawned(struct AActor* SpawnedActor); // Function BP_CaveAISpawnInterface.BP_CaveAISpawnInterface_C.OnAdditionalActorSpawned // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
};

