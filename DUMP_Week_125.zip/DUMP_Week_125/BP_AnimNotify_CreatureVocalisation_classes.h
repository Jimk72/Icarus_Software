// BlueprintGeneratedClass BP_AnimNotify_CreatureVocalisation.BP_AnimNotify_CreatureVocalisation_C
// Size: 0x39 (Inherited: 0x38)
struct UBP_AnimNotify_CreatureVocalisation_C : UAnimNotify {
	enum class EAIVocalisationType Type; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimNotify_CreatureVocalisation.BP_AnimNotify_CreatureVocalisation_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
};

