// BlueprintGeneratedClass BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C
// Size: 0x3b8 (Inherited: 0x390)
struct ABPQ_STYX_D_Recovery_Site_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct USceneComponent* Scene; // 0x398(0x08)
	struct UIcarusMapIconComponent* IcarusMapIcon; // 0x3a0(0x08)
	struct UBPQC_AdvancedAnimalSwarm_C* BPQC_AdvancedAnimalSwarm; // 0x3a8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x3b0(0x08)

	bool Check(); // Function BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Setup(bool bFirstTime); // Function BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C.Setup // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void RunFlow(); // Function BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C.RunFlow // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveQuestEnded(bool bWasAbandoned); // Function BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C.ReceiveQuestEnded // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void RunOperations(float DeltaSeconds); // Function BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C.RunOperations // (Event|Public|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BPQ_STYX_D_Recovery_Site(int32_t EntryPoint); // Function BPQ_STYX_D_Recovery_Site.BPQ_STYX_D_Recovery_Site_C.ExecuteUbergraph_BPQ_STYX_D_Recovery_Site // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

