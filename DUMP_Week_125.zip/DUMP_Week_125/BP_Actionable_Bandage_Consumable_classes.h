// BlueprintGeneratedClass BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C
// Size: 0x370 (Inherited: 0x368)
struct UBP_Actionable_Bandage_Consumable_C : UBP_ActionableBehaviour_Hold_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x368(0x08)

	bool CanHold(); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.CanHold // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void CompleteHold(bool Success); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.CompleteHold // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Actionable_Bandage_Consumable(int32_t EntryPoint); // Function BP_Actionable_Bandage_Consumable.BP_Actionable_Bandage_Consumable_C.ExecuteUbergraph_BP_Actionable_Bandage_Consumable // (Final|UbergraphFunction) // @ game+0x1fb3630
};

