// WidgetBlueprintGeneratedClass AccountFlagRow.AccountFlagRow_C
// Size: 0x2a0 (Inherited: 0x260)
struct UAccountFlagRow_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* TextBlock_57; // 0x268(0x08)
	struct FText NameText; // 0x270(0x18)
	struct FAccountFlagsRowHandle Flag; // 0x288(0x18)

	void SetAccountFlagRow(struct FAccountFlagsRowHandle AccountFlag); // Function AccountFlagRow.AccountFlagRow_C.SetAccountFlagRow // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_AccountFlagRow(int32_t EntryPoint); // Function AccountFlagRow.AccountFlagRow_C.ExecuteUbergraph_AccountFlagRow // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

