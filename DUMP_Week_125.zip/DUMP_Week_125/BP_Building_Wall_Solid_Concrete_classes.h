// BlueprintGeneratedClass BP_Building_Wall_Solid_Concrete.BP_Building_Wall_Solid_Concrete_C
// Size: 0xbd8 (Inherited: 0xbd0)
struct ABP_Building_Wall_Solid_Concrete_C : ABP_Building_Wall_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd0(0x08)

	void ReceiveBeginPlay(); // Function BP_Building_Wall_Solid_Concrete.BP_Building_Wall_Solid_Concrete_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_Building_Wall_Solid_Concrete(int32_t EntryPoint); // Function BP_Building_Wall_Solid_Concrete.BP_Building_Wall_Solid_Concrete_C.ExecuteUbergraph_BP_Building_Wall_Solid_Concrete // (Final|UbergraphFunction) // @ game+0x1fb3630
};

