// BlueprintGeneratedClass BP_ChairBase.BP_ChairBase_C
// Size: 0x7d8 (Inherited: 0x761)
struct ABP_ChairBase_C : ABP_DeployableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct USceneComponent* SeatAttachPoint_3S_L; // 0x770(0x08)
	struct USceneComponent* SeatAttachPoint_3S_R; // 0x778(0x08)
	struct USceneComponent* SeatAttachPoint_2S_R; // 0x780(0x08)
	struct USceneComponent* SeatAttachPoint_2S_L; // 0x788(0x08)
	struct USceneComponent* SeatAttachPoint; // 0x790(0x08)
	struct TArray<struct FString> AssignedPlayerUIDs; // 0x798(0x10)
	int32_t Seats; // 0x7a8(0x04)
	char pad_7AC[0x4]; // 0x7ac(0x04)
	struct ABP_Seat_Chair_C* SeatRef; // 0x7b0(0x08)
	struct ABP_Seat_Chair_C* SeatRef_2S_L; // 0x7b8(0x08)
	struct ABP_Seat_Chair_C* SeatRef_2S_R; // 0x7c0(0x08)
	struct ABP_Seat_Chair_C* SeatRef_3S_L; // 0x7c8(0x08)
	struct ABP_Seat_Chair_C* SeatRef_3S_R; // 0x7d0(0x08)

	struct TArray<struct FString> GetPlayerUIDArray(); // Function BP_ChairBase.BP_ChairBase_C.GetPlayerUIDArray // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1fb3630
	void GetClosestSeatRef(struct AActor* Instigator, struct ABP_Seat_Chair_C*& SeatOut); // Function BP_ChairBase.BP_ChairBase_C.GetClosestSeatRef // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_ChairBase.BP_ChairBase_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void Deployable_Interact(struct AActor* Interactor); // Function BP_ChairBase.BP_ChairBase_C.Deployable_Interact // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void CheckTimeSkip(); // Function BP_ChairBase.BP_ChairBase_C.CheckTimeSkip // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void InitSeat(); // Function BP_ChairBase.BP_ChairBase_C.InitSeat // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	struct FVector FindExitSpot(); // Function BP_ChairBase.BP_ChairBase_C.FindExitSpot // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void OnRep_AssignedPlayerUIDs(); // Function BP_ChairBase.BP_ChairBase_C.OnRep_AssignedPlayerUIDs // (BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	bool HasPlayerUID(struct FString& PlayerUID); // Function BP_ChairBase.BP_ChairBase_C.HasPlayerUID // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1fb3630
	void SanitzeAllBedUIDs(); // Function BP_ChairBase.BP_ChairBase_C.SanitzeAllBedUIDs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void RemovePlayerUID(struct FString& PlayerUID); // Function BP_ChairBase.BP_ChairBase_C.RemovePlayerUID // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void AddPlayerUID(struct FString& PlayerUID); // Function BP_ChairBase.BP_ChairBase_C.AddPlayerUID // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1fb3630
	void ReceiveBeginPlay(); // Function BP_ChairBase.BP_ChairBase_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1fb3630
	void SetPlayerUIDArray(struct TArray<struct FString>& PlayerUIDArray); // Function BP_ChairBase.BP_ChairBase_C.SetPlayerUIDArray // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1fb3630
	void ExecuteUbergraph_BP_ChairBase(int32_t EntryPoint); // Function BP_ChairBase.BP_ChairBase_C.ExecuteUbergraph_BP_ChairBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x1fb3630
};

