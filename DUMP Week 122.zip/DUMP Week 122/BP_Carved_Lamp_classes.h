// BlueprintGeneratedClass BP_Carved_Lamp.BP_Carved_Lamp_C
// Size: 0x810 (Inherited: 0x7fc)
struct ABP_Carved_Lamp_C : ABP_Light_Electric_Base_C {
	char pad_7FC[0x4]; // 0x7fc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x800(0x08)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x808(0x08)

	void ReceiveBeginPlay(); // Function BP_Carved_Lamp.BP_Carved_Lamp_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Carved_Lamp(int32_t EntryPoint); // Function BP_Carved_Lamp.BP_Carved_Lamp_C.ExecuteUbergraph_BP_Carved_Lamp // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

