// BlueprintGeneratedClass BP_CaveStaticMesh.BP_CaveStaticMesh_C
// Size: 0x230 (Inherited: 0x230)
struct ABP_CaveStaticMesh_C : AStaticMeshActor {
};

