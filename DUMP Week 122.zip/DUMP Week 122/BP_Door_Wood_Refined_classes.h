// BlueprintGeneratedClass BP_Door_Wood_Refined.BP_Door_Wood_Refined_C
// Size: 0x794 (Inherited: 0x794)
struct ABP_Door_Wood_Refined_C : ABP_Door_Base_C {
};

