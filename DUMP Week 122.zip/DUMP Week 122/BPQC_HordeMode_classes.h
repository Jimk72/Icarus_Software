// BlueprintGeneratedClass BPQC_HordeMode.BPQC_HordeMode_C
// Size: 0x18c (Inherited: 0xb0)
struct UBPQC_HordeMode_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	struct TArray<struct ABP_IcarusNPCGOAPCharacter_C*> NPCs; // 0xb8(0x10)
	struct AActor* Target; // 0xc8(0x08)
	struct FHordeRowHandle Horde Setup; // 0xd0(0x18)
	float Multiplier; // 0xe8(0x04)
	struct FHordeWaveRowHandle Current Wave; // 0xec(0x18)
	char pad_104[0x4]; // 0x104(0x04)
	struct TArray<float> Next Spawn; // 0x108(0x10)
	struct TArray<int32_t> Number Spawned; // 0x118(0x10)
	struct TArray<bool> Spawn Complete; // 0x128(0x10)
	int32_t Current Wave Index; // 0x138(0x04)
	char pad_13C[0x4]; // 0x13c(0x04)
	struct FMulticastInlineDelegate HordeComplete; // 0x140(0x10)
	int32_t Killed; // 0x150(0x04)
	int32_t Total; // 0x154(0x04)
	struct TArray<struct AActor*> SpawnLocations; // 0x158(0x10)
	int32_t TotalNumberSpawned; // 0x168(0x04)
	float MaximumQuestMarkerSpawnDistance; // 0x16c(0x04)
	bool Current; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct TArray<int32_t> PerCreatureTotalSpawnCount; // 0x178(0x10)
	float DelayBetweenSimultaneousSpawns; // 0x188(0x04)

	void GetTotalNumberToSpawn(struct FHordeCreatureSetup HordeCreature, int32_t& TotalSpawnNum); // Function BPQC_HordeMode.BPQC_HordeMode_C.GetTotalNumberToSpawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	void GetTimeBetweenSpawns(struct FHordeCreatureSetup HordeCreature, float& TimeBetween); // Function BPQC_HordeMode.BPQC_HordeMode_C.GetTimeBetweenSpawns // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	void GetSimultaneousNumberOfAIToSpawn(struct FHordeCreatureSetup HordeCreature, int32_t& ToSpawn); // Function BPQC_HordeMode.BPQC_HordeMode_C.GetSimultaneousNumberOfAIToSpawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	void GetOriginForSpawnEQS(struct FVector& Origin, bool& IsQuestMarker); // Function BPQC_HordeMode.BPQC_HordeMode_C.GetOriginForSpawnEQS // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void GetProgress(float& Progress); // Function BPQC_HordeMode.BPQC_HordeMode_C.GetProgress // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void On Creature End Play(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function BPQC_HordeMode.BPQC_HordeMode_C.On Creature End Play // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void On Creature Death(struct UActorState* ActorState); // Function BPQC_HordeMode.BPQC_HordeMode_C.On Creature Death // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void On Creature Spawned(struct ABP_IcarusNPCGOAPCharacter_C* NPC); // Function BPQC_HordeMode.BPQC_HordeMode_C.On Creature Spawned // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void AngerNPC(struct AIcarusNPCGOAPCharacter* NPC); // Function BPQC_HordeMode.BPQC_HordeMode_C.AngerNPC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Check Spawn(float Delta); // Function BPQC_HordeMode.BPQC_HordeMode_C.Check Spawn // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void TriggerNextWave(bool& Complete); // Function BPQC_HordeMode.BPQC_HordeMode_C.TriggerNextWave // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Check Complete(bool& Complete); // Function BPQC_HordeMode.BPQC_HordeMode_C.Check Complete // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Stop Horde(); // Function BPQC_HordeMode.BPQC_HordeMode_C.Stop Horde // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Trigger Horde(struct FHordeRowHandle HordeSetup, float Multiplier); // Function BPQC_HordeMode.BPQC_HordeMode_C.Trigger Horde // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BPQC_HordeMode.BPQC_HordeMode_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BPQC_HordeMode.BPQC_HordeMode_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BPQC_HordeMode(int32_t EntryPoint); // Function BPQC_HordeMode.BPQC_HordeMode_C.ExecuteUbergraph_BPQC_HordeMode // (Final|UbergraphFunction) // @ game+0x1f9a5d0
	void HordeComplete__DelegateSignature(); // Function BPQC_HordeMode.BPQC_HordeMode_C.HordeComplete__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

