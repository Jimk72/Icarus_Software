// BlueprintGeneratedClass BP_Carved_SittingBench.BP_Carved_SittingBench_C
// Size: 0x7c8 (Inherited: 0x7c8)
struct ABP_Carved_SittingBench_C : ABP_ChairBase_C {
};

