// BlueprintGeneratedClass BP_CaveWorm_Spit_Large.BP_CaveWorm_Spit_Large_C
// Size: 0x590 (Inherited: 0x580)
struct ABP_CaveWorm_Spit_Large_C : ASkeletalItem {
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x580(0x08)
	struct UNiagaraComponent* NS_Sandworm_SpitProjectile_FX; // 0x588(0x08)
};

