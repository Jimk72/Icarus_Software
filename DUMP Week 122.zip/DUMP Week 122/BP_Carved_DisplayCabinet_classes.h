// BlueprintGeneratedClass BP_Carved_DisplayCabinet.BP_Carved_DisplayCabinet_C
// Size: 0x76a (Inherited: 0x76a)
struct ABP_Carved_DisplayCabinet_C : ABP_DeployableContainerBase_C {
};

