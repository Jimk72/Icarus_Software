// BlueprintGeneratedClass BP_AimAssistTargetComponent.BP_AimAssistTargetComponent_C
// Size: 0xe8 (Inherited: 0xb0)
struct UBP_AimAssistTargetComponent_C : UActorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb0(0x08)
	float CollisionRadiusScale; // 0xb8(0x04)
	float OverrideCollisionRadius; // 0xbc(0x04)
	bool DebugComponent; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct USphereComponent* Collider; // 0xc8(0x08)
	float DesiredSize; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct TArray<struct FName> ColliderTags; // 0xd8(0x10)

	void ReceiveBeginPlay(); // Function BP_AimAssistTargetComponent.BP_AimAssistTargetComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_AimAssistTargetComponent.BP_AimAssistTargetComponent_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_AimAssistTargetComponent(int32_t EntryPoint); // Function BP_AimAssistTargetComponent.BP_AimAssistTargetComponent_C.ExecuteUbergraph_BP_AimAssistTargetComponent // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

