// BlueprintGeneratedClass BP_Bait.BP_Bait_C
// Size: 0x768 (Inherited: 0x751)
struct ABP_Bait_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct UFMODAudioComponent* FlyAudio; // 0x758(0x08)
	struct UNiagaraComponent* NS_Flies1; // 0x760(0x08)
};

