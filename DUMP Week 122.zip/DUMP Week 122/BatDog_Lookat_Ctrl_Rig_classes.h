// ControlRigBlueprintGeneratedClass BatDog_Lookat_Ctrl_Rig.BatDog_Lookat_Ctrl_Rig_C
// Size: 0x66c (Inherited: 0x650)
struct UBatDog_Lookat_Ctrl_Rig_C : UControlRig {
	struct FVector LookAtTargetLocation; // 0x650(0x0c)
	bool DoLookAt; // 0x65c(0x01)
	char pad_65D[0x3]; // 0x65d(0x03)
	float LookAtDistanceBlendStart; // 0x660(0x04)
	float LookAtDistanceBlendEnd; // 0x664(0x04)
	float AdditionalTargetHeight; // 0x668(0x04)
};

