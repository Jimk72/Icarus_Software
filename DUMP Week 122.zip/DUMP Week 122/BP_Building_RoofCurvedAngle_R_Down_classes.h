// BlueprintGeneratedClass BP_Building_RoofCurvedAngle_R_Down.BP_Building_RoofCurvedAngle_R_Down_C
// Size: 0xbe0 (Inherited: 0xbe0)
struct ABP_Building_RoofCurvedAngle_R_Down_C : ABP_Building_RoofCorner_C {

	void GetBlockingBypass(struct ABP_Building_Base_C* BuildingClass, struct TArray<struct FVectorPair>& BlockingPreRotate, struct FTransform GridSpaceTransform, struct TArray<struct FVectorPair>& BypassBlocking); // Function BP_Building_RoofCurvedAngle_R_Down.BP_Building_RoofCurvedAngle_R_Down_C.GetBlockingBypass // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

