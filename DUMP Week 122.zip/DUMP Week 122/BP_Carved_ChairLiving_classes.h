// BlueprintGeneratedClass BP_Carved_ChairLiving.BP_Carved_ChairLiving_C
// Size: 0x7c8 (Inherited: 0x7c8)
struct ABP_Carved_ChairLiving_C : ABP_ChairBase_C {
};

