// BlueprintGeneratedClass BP_Bed_Bedroll.BP_Bed_Bedroll_C
// Size: 0x790 (Inherited: 0x788)
struct ABP_Bed_Bedroll_C : ABP_BedBase_C {
	struct UGFurComponent* GFur; // 0x788(0x08)
};

