// BlueprintGeneratedClass BPI_GeneratorUIProvider.BPI_GeneratorUIProvider_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_GeneratorUIProvider_C : UInterface {

	void UseDeviceToggle(bool& WantsDeviceToggle); // Function BPI_GeneratorUIProvider.BPI_GeneratorUIProvider_C.UseDeviceToggle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

