// BlueprintGeneratedClass BP_DialogueManager.BP_DialogueManager_C
// Size: 0x270 (Inherited: 0x268)
struct ABP_DialogueManager_C : ADialogueManager {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x268(0x08)

	void GetDialogueWidget(struct UUMG_Dialogue_C*& DialogueWidget); // Function BP_DialogueManager.BP_DialogueManager_C.GetDialogueWidget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDialoguePlayed(struct FDialogueRowHandle Dialogue); // Function BP_DialogueManager.BP_DialogueManager_C.OnDialoguePlayed // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDialogueCleared(); // Function BP_DialogueManager.BP_DialogueManager_C.OnDialogueCleared // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_DialogueManager(int32_t EntryPoint); // Function BP_DialogueManager.BP_DialogueManager_C.ExecuteUbergraph_BP_DialogueManager // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

