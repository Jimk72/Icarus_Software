// BlueprintGeneratedClass BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C
// Size: 0x7c4 (Inherited: 0x761)
struct ABP_Electric_Dehumidifier_V2_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UStaticMeshComponent* SM_DEP_Electric_Dehumidifier_Fan_02; // 0x770(0x08)
	struct UStaticMeshComponent* SM_DEP_Electric_Dehumidifier_Fan_01; // 0x778(0x08)
	struct UStaticMeshComponent* SM_DEP_Electric_Dehumidifier_Proxy_V2; // 0x780(0x08)
	struct UNiagaraComponent* Niagara2; // 0x788(0x08)
	struct UNiagaraComponent* Niagara1; // 0x790(0x08)
	struct USceneComponent* Scene_Niagara; // 0x798(0x08)
	struct UFMODAudioComponent* FMOD_Active_Audio; // 0x7a0(0x08)
	float FanAnim_SpinRate_E87368C54EC6D3F0213C90880A7FFD3F; // 0x7a8(0x04)
	enum class ETimelineDirection FanAnim__Direction_E87368C54EC6D3F0213C90880A7FFD3F; // 0x7ac(0x01)
	char pad_7AD[0x3]; // 0x7ad(0x03)
	struct UTimelineComponent* FanAnim; // 0x7b0(0x08)
	struct UInventory* GeneralInventory; // 0x7b8(0x08)
	int32_t LastRangeValue; // 0x7c0(0x04)

	void UpdateModifier(bool Powered); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.UpdateModifier // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateRunningEffects(bool ReceivingPower); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.UpdateRunningEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void FanAnim__FinishedFunc(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.FanAnim__FinishedFunc // (BlueprintEvent) // @ game+0x1f9a5d0
	void FanAnim__UpdateFunc(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.FanAnim__UpdateFunc // (BlueprintEvent) // @ game+0x1f9a5d0
	void PlayFanAnim(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.PlayFanAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void StopFanAnim(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.StopFanAnim // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStartRunning(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStopRunning(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnBrownOutStrengthChanged(enum class EIcarusResourceType ResourceType, int32_t NewBrownOutStrength); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.OnBrownOutStrengthChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnStatContainerUpdated(); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.OnStatContainerUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Electric_Dehumidifier_V2(int32_t EntryPoint); // Function BP_Electric_Dehumidifier_V2.BP_Electric_Dehumidifier_V2_C.ExecuteUbergraph_BP_Electric_Dehumidifier_V2 // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

