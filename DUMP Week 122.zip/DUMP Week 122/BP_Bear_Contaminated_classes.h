// BlueprintGeneratedClass BP_Bear_Contaminated.BP_Bear_Contaminated_C
// Size: 0x788 (Inherited: 0x778)
struct ABP_Bear_Contaminated_C : ABP_GOAP_Corpse_C {
	struct UNiagaraComponent* Niagara; // 0x778(0x08)
	struct UGFurComponent* GFur; // 0x780(0x08)

	void OnSkinnedStateUpdated(); // Function BP_Bear_Contaminated.BP_Bear_Contaminated_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

