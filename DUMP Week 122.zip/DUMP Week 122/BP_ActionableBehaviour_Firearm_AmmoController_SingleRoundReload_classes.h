// BlueprintGeneratedClass BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C
// Size: 0xe34 (Inherited: 0xe28)
struct UBP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C : UBP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe28(0x08)
	float ReloadCancelBlendOutTime; // 0xe30(0x04)

	int32_t GetAmmoCapacity(); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.GetAmmoCapacity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void CanAbortReload(bool& CanAbort); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.CanAbortReload // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void ServerFinishReload(); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.ServerFinishReload // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnAbortReloadRequested(); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.OnAbortReloadRequested // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReloadSingleRound(); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.ReloadSingleRound // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetReloadMontageNextSections(struct FName SectionNameToChange, struct FName NextSection); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.SetReloadMontageNextSections // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	float GetReloadAnimPlayRate(struct UAnimMontage* Montage); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.GetReloadAnimPlayRate // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void CalculateNumberOfRoundsToLoad(int32_t& NumRounds); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.CalculateNumberOfRoundsToLoad // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HandleReloadAnimNotify(struct FString NotifyName); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.HandleReloadAnimNotify // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void AbortReloadAnimations(); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.AbortReloadAnimations // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload(int32_t EntryPoint); // Function BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload.BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload_C.ExecuteUbergraph_BP_ActionableBehaviour_Firearm_AmmoController_SingleRoundReload // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

