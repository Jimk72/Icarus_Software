// BlueprintGeneratedClass BP_ActionableBehaviour_Fertalize_Crops.BP_ActionableBehaviour_Fertalize_Crops_C
// Size: 0x340 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Fertalize_Crops_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct AIcarusPlayerCharacterSurvival* OwningPlayer; // 0x318(0x08)
	struct USurvivalCharacterState* SurvivalStateRef; // 0x320(0x08)
	struct UFMODEvent* FMODEvent_Eat; // 0x328(0x08)
	struct UFMODEvent* FMODEvent_Drink; // 0x330(0x08)
	struct ABP_Crop_Plot_Base_C* As BP Crop Plot Base; // 0x338(0x08)

	void PlayConsumeSound(struct AIcarusMountCharacter* Mount, struct UFMODEvent* Sound); // Function BP_ActionableBehaviour_Fertalize_Crops.BP_ActionableBehaviour_Fertalize_Crops_C.PlayConsumeSound // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Fertalize_Crops.BP_ActionableBehaviour_Fertalize_Crops_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Fertalize_Crops.BP_ActionableBehaviour_Fertalize_Crops_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Fertalize_Crops.BP_ActionableBehaviour_Fertalize_Crops_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Fertalize_Crops(int32_t EntryPoint); // Function BP_ActionableBehaviour_Fertalize_Crops.BP_ActionableBehaviour_Fertalize_Crops_C.ExecuteUbergraph_BP_ActionableBehaviour_Fertalize_Crops // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

