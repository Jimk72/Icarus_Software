// BlueprintGeneratedClass BP_Brazier.BP_Brazier_C
// Size: 0x7b0 (Inherited: 0x790)
struct ABP_Brazier_C : ABP_Light_Fire_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x790(0x08)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight_Large; // 0x798(0x08)
	struct UPointLightComponent* PointLight_SmallBounce; // 0x7a0(0x08)
	struct UNiagaraComponent* Niagara_Brazier; // 0x7a8(0x08)

	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_Brazier.BP_Brazier_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GeneratorStateUpdate(bool Active); // Function BP_Brazier.BP_Brazier_C.GeneratorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Snow(float Intensity); // Function BP_Brazier.BP_Brazier_C.Snow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void DeactivateCampfire(); // Function BP_Brazier.BP_Brazier_C.DeactivateCampfire // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Rain(int32_t Millilitres); // Function BP_Brazier.BP_Brazier_C.Rain // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Brazier(int32_t EntryPoint); // Function BP_Brazier.BP_Brazier_C.ExecuteUbergraph_BP_Brazier // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

