// BlueprintGeneratedClass BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C
// Size: 0xaad (Inherited: 0xa6c)
struct UBP_ActionableBehaviour_FireArm_FireController_Charge_C : UBP_ActionableBehaviour_FireArm_FireController_Base_C {
	char pad_A6C[0x4]; // 0xa6c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)
	float ChargePower; // 0xa78(0x04)
	bool StaminaUsed; // 0xa7c(0x01)
	char pad_A7D[0x3]; // 0xa7d(0x03)
	float FullChargePowerTimeStamp; // 0xa80(0x04)
	char pad_A84[0x4]; // 0xa84(0x04)
	struct UMatineeCameraShake* CameraShake; // 0xa88(0x08)
	bool LocalChargeCancel; // 0xa90(0x01)
	char pad_A91[0x7]; // 0xa91(0x07)
	struct FTimerHandle ChargeShakeTimer; // 0xa98(0x08)
	bool IsDoingChargeShake; // 0xaa0(0x01)
	char pad_AA1[0x3]; // 0xaa1(0x03)
	float LastChargePower; // 0xaa4(0x04)
	float AcceptableClientPowerDifference; // 0xaa8(0x04)
	bool LocalIsFiring; // 0xaac(0x01)

	void GetFiring(bool& Firing); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.GetFiring // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void HandleRep_WantsFire(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.HandleRep_WantsFire // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void FinishFiring(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.FinishFiring // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void BeginFire(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.BeginFire // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IsChargedForFiring(bool& Charged); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.IsChargedForFiring // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void EndFire(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.EndFire // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CancelCharging(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.CancelCharging // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CheckCancelCharge(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.CheckCancelCharge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void TickCameraEffects(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.TickCameraEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	float GetChargeTimeMultiplier(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.GetChargeTimeMultiplier // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void TickCharge(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.TickCharge // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	float GetLaunchForce(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.GetLaunchForce // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void IsCharging(bool& IsCharging); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.IsCharging // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void UpdatePersistentAudioCharge(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.UpdatePersistentAudioCharge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetCurrentChargePower(float& ChargePower); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.GetCurrentChargePower // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnReloadPressed(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.OnReloadPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ChargeShakeBegin(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.ChargeShakeBegin // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ChargeShakeEnd(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.ChargeShakeEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void LateSetup(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.LateSetup // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Server_CancelCharge(); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.Server_CancelCharge // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Server_OnReleasedShot(bool ClientFired, float ClientChargePower); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.Server_OnReleasedShot // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_FireArm_FireController_Charge(int32_t EntryPoint); // Function BP_ActionableBehaviour_FireArm_FireController_Charge.BP_ActionableBehaviour_FireArm_FireController_Charge_C.ExecuteUbergraph_BP_ActionableBehaviour_FireArm_FireController_Charge // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

