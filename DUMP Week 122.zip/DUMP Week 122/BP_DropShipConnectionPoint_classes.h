// BlueprintGeneratedClass BP_DropShipConnectionPoint.BP_DropShipConnectionPoint_C
// Size: 0x5a0 (Inherited: 0x590)
struct ABP_DropShipConnectionPoint_C : AIcarusRocketPartConnector {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x590(0x08)
	struct UStaticMeshComponent* Sphere; // 0x598(0x08)

	void ReceiveBeginPlay(); // Function BP_DropShipConnectionPoint.BP_DropShipConnectionPoint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void OnConnectionUpdated(); // Function BP_DropShipConnectionPoint.BP_DropShipConnectionPoint_C.OnConnectionUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_DropShipConnectionPoint(int32_t EntryPoint); // Function BP_DropShipConnectionPoint.BP_DropShipConnectionPoint_C.ExecuteUbergraph_BP_DropShipConnectionPoint // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

