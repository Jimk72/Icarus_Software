// BlueprintGeneratedClass BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C
// Size: 0x331 (Inherited: 0x30a)
struct UBP_Actionable_FlameThrower_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* OwningPlayer; // 0x318(0x08)
	struct AActor* OwningActor; // 0x320(0x08)
	struct ABP_SkeletalItem_FlameThrower_Small_C* SKItem; // 0x328(0x08)
	bool DoFire; // 0x330(0x01)

	void TickTimer(); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.TickTimer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SphereTrace(); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.SphereTrace // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Setup(struct AActor* OwningActor); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void Multi_SpawnFX(struct FVector ImpactPoint, struct FVector ImpactNormal); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.Multi_SpawnFX // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Actionable_FlameThrower(int32_t EntryPoint); // Function BP_Actionable_FlameThrower.BP_Actionable_FlameThrower_C.ExecuteUbergraph_BP_Actionable_FlameThrower // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

