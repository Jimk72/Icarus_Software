// BlueprintGeneratedClass BP_CaveComponentInterface.BP_CaveComponentInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_CaveComponentInterface_C : UInterface {

	void SetCaveState(bool IsInCave, struct AActor* CaveActor); // Function BP_CaveComponentInterface.BP_CaveComponentInterface_C.SetCaveState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

