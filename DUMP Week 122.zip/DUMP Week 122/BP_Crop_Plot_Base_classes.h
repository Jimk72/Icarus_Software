// BlueprintGeneratedClass BP_Crop_Plot_Base.BP_Crop_Plot_Base_C
// Size: 0x811 (Inherited: 0x751)
struct ABP_Crop_Plot_Base_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x760(0x08)
	struct USceneComponent* CropSnappingPoint; // 0x768(0x08)
	struct UStaticMeshComponent* Crop; // 0x770(0x08)
	struct UFMODEvent* FMODEvent_Watering; // 0x778(0x08)
	struct TMap<struct UCultivation*, struct UStaticMeshComponent*> Cultivations; // 0x780(0x50)
	int32_t GlasshousePieceThreshold; // 0x7d0(0x04)
	int32_t OutsideModifierID; // 0x7d4(0x04)
	int32_t GlassHouseModifierID; // 0x7d8(0x04)
	int32_t WateredModifierUID; // 0x7dc(0x04)
	bool SoilWet; // 0x7e0(0x01)
	char pad_7E1[0x3]; // 0x7e1(0x03)
	int32_t EnergyModifierUID; // 0x7e4(0x04)
	struct UMaterialInterface* SoilMatDry; // 0x7e8(0x08)
	struct UMaterialInterface* SoilMatWet; // 0x7f0(0x08)
	int32_t SoilMatID; // 0x7f8(0x04)
	bool bHasGlasshouseModifier; // 0x7fc(0x01)
	bool bHasSunlightModifier; // 0x7fd(0x01)
	bool bHasNoSunModifier; // 0x7fe(0x01)
	char pad_7FF[0x1]; // 0x7ff(0x01)
	int32_t NoSunModifierID; // 0x800(0x04)
	int32_t CurrentGlasshousePieces; // 0x804(0x04)
	int32_t CurrentWaterModifierEffectiveness; // 0x808(0x04)
	float WaterDisconnectedModifierStayTime; // 0x80c(0x04)
	bool bHasWaterConnectionModifier; // 0x810(0x01)

	void GetCropPlotValues(struct TArray<struct FCultivationSaveData>& SaveData); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.GetCropPlotValues // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CheckWantsFlow(bool& WantsFlow); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.CheckWantsFlow // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateWantsFlow(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.UpdateWantsFlow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetFertilizerModifier(struct UModifierStateComponent*& Modifier); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.GetFertilizerModifier // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IsFertilized(bool& Fertilized); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.IsFertilized // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetSoilState(bool bWet); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.SetSoilState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CanHarvestAny(bool& CanHarvest); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.CanHarvestAny // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void HasAnySeeds(bool& IsSeeded); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.HasAnySeeds // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ClearCultivation(int32_t Cultivation); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.ClearCultivation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateEnergyConnectionModifier(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.UpdateEnergyConnectionModifier // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateWaterConnectionModifier(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.UpdateWaterConnectionModifier // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void FertilizePlot(struct FItemData FertilizerItem, bool& Fertalized); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.FertilizePlot // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CanFertilize(bool& CanBeFertilized); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.CanFertilize // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlaySound(struct UFMODEvent* FMODEvent); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlaySound // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetAudioData(struct FFarmingSeedAudioData& Data); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.GetAudioData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void OnRep_SoilWet(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.OnRep_SoilWet // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateGlasshouseAndOutsideModifiers(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.UpdateGlasshouseAndOutsideModifiers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CanHarvest(struct UStaticMeshComponent* StaticMeshComponent, bool& CanHarvest); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.CanHarvest // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	void GetCultivationFromMesh(struct UStaticMeshComponent* StaticMesh, struct UCultivation*& Cultivation); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.GetCultivationFromMesh // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void SetupCultivations(struct TMap<struct UCultivation*, struct UStaticMeshComponent*>& Cultivations); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.SetupCultivations // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void HasSeed(int32_t Cultivation, bool& IsSeeded); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.HasSeed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	void CanPlantSeed(struct FItemData& ItemData, int32_t Cultivation, bool& CanPlant); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.CanPlantSeed // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlantSeed(struct FItemData NewSeed, int32_t Cultivation, struct AIcarusPlayerCharacter* Player, bool& Planted); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlantSeed // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HarvestResource(struct AActor* HarvestActor, struct UStaticMeshComponent*& StaticMeshComponent, bool bUsingSickle, struct UInventory* NonPlayerInventory, bool& Harvested); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.HarvestResource // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnLoaded_002CDE2F457F54BDFC92D7AEFED0E4AA(struct UObject* Loaded); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.OnLoaded_002CDE2F457F54BDFC92D7AEFED0E4AA // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Snow(float Intensity); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.Snow // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void OnSeedUpdated(struct UCultivation* Cultivation, struct FFarmingSeedsRowHandle FarmingSeed); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.OnSeedUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnGrowthStateUpdated(struct UCultivation* Cultivation, enum class EPlantGrowthStates GrowthState); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.OnGrowthStateUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateCultivationMesh(struct UCultivation* Cultivation); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.UpdateCultivationMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void Rain(int32_t Millilitres); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.Rain // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnModifierUpdated(struct UModifierStateComponent* Component, bool bRemoved); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.OnModifierUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ManuallyWater(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.ManuallyWater // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlaySeedPlantedFX(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlaySeedPlantedFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayHarvestFX(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlayHarvestFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayClearPlotFX(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlayClearPlotFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void MULTI_PlaySound(struct UFMODEvent* FMODEvent); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.MULTI_PlaySound // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void MULTI_PlayItemAddedAudio(struct FItemsStaticRowHandle Item); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.MULTI_PlayItemAddedAudio // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayFertilizerFX(struct FItemsStaticRowHandle Item); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlayFertilizerFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayWateringFX(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.PlayWateringFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetCropPlotValues(struct TArray<struct FCultivationSaveData>& SaveData); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.SetCropPlotValues // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1f9a5d0
	void CustomEvent_1(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.CustomEvent_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceResourceChanged(enum class EIcarusResourceType ResourceType); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.OnDeviceResourceChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void DelayedUpdateWaterModifier(); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.DelayedUpdateWaterModifier // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Crop_Plot_Base(int32_t EntryPoint); // Function BP_Crop_Plot_Base.BP_Crop_Plot_Base_C.ExecuteUbergraph_BP_Crop_Plot_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

