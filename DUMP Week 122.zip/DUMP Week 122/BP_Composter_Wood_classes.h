// BlueprintGeneratedClass BP_Composter_Wood.BP_Composter_Wood_C
// Size: 0x9d0 (Inherited: 0x9b0)
struct ABP_Composter_Wood_C : ABP_ProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9b0(0x08)
	struct UStaticMeshComponent* StaticMesh2; // 0x9b8(0x08)
	struct UStaticMeshComponent* StaticMesh1; // 0x9c0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x9c8(0x08)

	void ReceiveBeginPlay(); // Function BP_Composter_Wood.BP_Composter_Wood_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Composter_Wood(int32_t EntryPoint); // Function BP_Composter_Wood.BP_Composter_Wood_C.ExecuteUbergraph_BP_Composter_Wood // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

