// BlueprintGeneratedClass BP_Breakable_Rock_Base.BP_Breakable_Rock_Base_C
// Size: 0x400 (Inherited: 0x400)
struct ABP_Breakable_Rock_Base_C : ARockBase {
};

