// BlueprintGeneratedClass BPQ_Exploration.BPQ_Exploration_C
// Size: 0x390 (Inherited: 0x380)
struct ABPQ_Exploration_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x388(0x08)

	bool Check(); // Function BPQ_Exploration.BPQ_Exploration_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Setup(bool bFirstTime); // Function BPQ_Exploration.BPQ_Exploration_C.Setup // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void RunFlow(); // Function BPQ_Exploration.BPQ_Exploration_C.RunFlow // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void Launch(struct AIcarusRocket* Dropship); // Function BPQ_Exploration.BPQ_Exploration_C.Launch // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BPQ_Exploration(int32_t EntryPoint); // Function BPQ_Exploration.BPQ_Exploration_C.ExecuteUbergraph_BPQ_Exploration // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

