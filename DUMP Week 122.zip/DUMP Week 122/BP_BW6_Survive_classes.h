// BlueprintGeneratedClass BP_BW6_Survive.BP_BW6_Survive_C
// Size: 0x394 (Inherited: 0x380)
struct ABP_BW6_Survive_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x388(0x08)
	float UpdateTime; // 0x390(0x04)

	bool Check(); // Function BP_BW6_Survive.BP_BW6_Survive_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_BW6_Survive(int32_t EntryPoint); // Function BP_BW6_Survive.BP_BW6_Survive_C.ExecuteUbergraph_BP_BW6_Survive // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

