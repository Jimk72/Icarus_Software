// BlueprintGeneratedClass BPQ_Common_Progress.BPQ_Common_Progress_C
// Size: 0x3a4 (Inherited: 0x380)
struct ABPQ_Common_Progress_C : AQuest {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x388(0x08)
	bool NearbyPlayers; // 0x390(0x01)
	char pad_391[0x3]; // 0x391(0x03)
	int32_t NumberOfPlayers; // 0x394(0x04)
	struct FTimerHandle Event; // 0x398(0x08)
	float MaxPlayerDistance; // 0x3a0(0x04)

	float GetMaxTime(); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.GetMaxTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void PlayersLeftArea(); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.PlayersLeftArea // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetDescription(struct FText& InDescription, struct FText& OutDescription, bool& bOutComplete); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.GetDescription // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	bool Check(); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.Check // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void RunOperations(float DeltaSeconds); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.RunOperations // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void Setup(bool bFirstTime); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.Setup // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void CheckPlayers(); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.CheckPlayers // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BPQ_Common_Progress(int32_t EntryPoint); // Function BPQ_Common_Progress.BPQ_Common_Progress_C.ExecuteUbergraph_BPQ_Common_Progress // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

