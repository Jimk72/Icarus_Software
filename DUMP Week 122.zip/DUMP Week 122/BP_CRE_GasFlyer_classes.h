// BlueprintGeneratedClass BP_CRE_GasFlyer.BP_CRE_GasFlyer_C
// Size: 0xb84 (Inherited: 0xb6c)
struct ABP_CRE_GasFlyer_C : ABP_IcarusNPCGOAPCharacter_C {
	char pad_B6C[0x4]; // 0xb6c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb70(0x08)
	bool IsScared; // 0xb78(0x01)
	char pad_B79[0x3]; // 0xb79(0x03)
	struct FName IsScaredKeyName; // 0xb7c(0x08)

	void OnRep_On Rep Explode(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.OnRep_On Rep Explode // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetSightPerceptionOrigin(struct FVector& OutLocation, struct FRotator& OutRotation); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.GetSightPerceptionOrigin // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	struct TMap<struct UPrimitiveComponent*, struct FCriticalHitAreasEnum> GetCriticalHitAreas(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.GetCriticalHitAreas // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void UpdateVocalisationState(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.UpdateVocalisationState // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	bool CanKillcam(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.CanKillcam // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnActorDeath(struct UActorState* ActorStateIn); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.OnActorDeath // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnMeshLanded(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.OnMeshLanded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HideCorpse(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.HideCorpse // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void MultiDeathExplode(); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.MultiDeathExplode // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_CRE_GasFlyer(int32_t EntryPoint); // Function BP_CRE_GasFlyer.BP_CRE_GasFlyer_C.ExecuteUbergraph_BP_CRE_GasFlyer // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

