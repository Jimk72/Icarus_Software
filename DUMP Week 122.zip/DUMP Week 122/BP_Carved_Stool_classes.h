// BlueprintGeneratedClass BP_Carved_Stool.BP_Carved_Stool_C
// Size: 0x7c8 (Inherited: 0x7c8)
struct ABP_Carved_Stool_C : ABP_ChairBase_C {
};

