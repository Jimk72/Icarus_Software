// AnimBlueprintGeneratedClass AnimBP_FireExtinguisher.AnimBP_FireExtinguisher_C
// Size: 0x419 (Inherited: 0x2c0)
struct UAnimBP_FireExtinguisher_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x2f8(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x378(0xa0)
	bool Firing; // 0x418(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AnimBP_FireExtinguisher.AnimBP_FireExtinguisher_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function AnimBP_FireExtinguisher.AnimBP_FireExtinguisher_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_AnimBP_FireExtinguisher(int32_t EntryPoint); // Function AnimBP_FireExtinguisher.AnimBP_FireExtinguisher_C.ExecuteUbergraph_AnimBP_FireExtinguisher // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

