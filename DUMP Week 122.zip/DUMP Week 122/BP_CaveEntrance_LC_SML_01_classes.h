// BlueprintGeneratedClass BP_CaveEntrance_LC_SML_01.BP_CaveEntrance_LC_SML_01_C
// Size: 0x328 (Inherited: 0x320)
struct ABP_CaveEntrance_LC_SML_01_C : ABP_BaseCaveEntrance_C {
	struct UStaticMeshComponent* StaticMesh01; // 0x320(0x08)
};

