// BlueprintGeneratedClass BP_BabyDeer_Corpse.BP_BabyDeer_Corpse_C
// Size: 0x778 (Inherited: 0x778)
struct ABP_BabyDeer_Corpse_C : ABP_GOAP_Corpse_C {
};

