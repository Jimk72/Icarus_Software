// BlueprintGeneratedClass BP_ActionableBehaviour_Scanner_Cave.BP_ActionableBehaviour_Scanner_Cave_C
// Size: 0x3b8 (Inherited: 0x3ac)
struct UBP_ActionableBehaviour_Scanner_Cave_C : UBP_ActionableBehaviour_Scanner_C {
	char pad_3AC[0x4]; // 0x3ac(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b0(0x08)

	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Scanner_Cave.BP_ActionableBehaviour_Scanner_Cave_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Scanner_Cave(int32_t EntryPoint); // Function BP_ActionableBehaviour_Scanner_Cave.BP_ActionableBehaviour_Scanner_Cave_C.ExecuteUbergraph_BP_ActionableBehaviour_Scanner_Cave // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

