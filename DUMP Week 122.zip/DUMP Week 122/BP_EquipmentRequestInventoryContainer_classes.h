// BlueprintGeneratedClass BP_EquipmentRequestInventoryContainer.BP_EquipmentRequestInventoryContainer_C
// Size: 0x240 (Inherited: 0x238)
struct ABP_EquipmentRequestInventoryContainer_C : AEquipmentRequestInventoryContainer {
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
};

