// BlueprintGeneratedClass BP_DeployableContainerBase.BP_DeployableContainerBase_C
// Size: 0x76a (Inherited: 0x751)
struct ABP_DeployableContainerBase_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	struct UUMG_IcarusLinkedActorPanel_C* WidgetClassToOpen; // 0x760(0x08)
	bool ShowStoreAll; // 0x768(0x01)
	bool ShowTakeAll; // 0x769(0x01)

	void Deployable_Interact(struct AActor* Interactor); // Function BP_DeployableContainerBase.BP_DeployableContainerBase_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnBecomeInteractedWith(); // Function BP_DeployableContainerBase.BP_DeployableContainerBase_C.OnBecomeInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnNoLongerInteractedWith(); // Function BP_DeployableContainerBase.BP_DeployableContainerBase_C.OnNoLongerInteractedWith // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_DeployableContainerBase(int32_t EntryPoint); // Function BP_DeployableContainerBase.BP_DeployableContainerBase_C.ExecuteUbergraph_BP_DeployableContainerBase // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

