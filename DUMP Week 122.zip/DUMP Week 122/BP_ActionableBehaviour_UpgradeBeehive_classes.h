// BlueprintGeneratedClass BP_ActionableBehaviour_UpgradeBeehive.BP_ActionableBehaviour_UpgradeBeehive_C
// Size: 0xc52 (Inherited: 0xc52)
struct UBP_ActionableBehaviour_UpgradeBeehive_C : UBP_ActionableBehaviour_DeployableBase_C {

	void CustomDeploymentCheck(struct AActor* HitActor, bool& ValidPlacement, struct FText& Reason); // Function BP_ActionableBehaviour_UpgradeBeehive.BP_ActionableBehaviour_UpgradeBeehive_C.CustomDeploymentCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void BlueprintDeploy(struct FTransform DeployTransform, struct AActor* FoundationActor, struct FItemData ItemData, int32_t VarientIndex); // Function BP_ActionableBehaviour_UpgradeBeehive.BP_ActionableBehaviour_UpgradeBeehive_C.BlueprintDeploy // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

