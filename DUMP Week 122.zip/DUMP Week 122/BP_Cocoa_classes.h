// BlueprintGeneratedClass BP_Cocoa.BP_Cocoa_C
// Size: 0x3d8 (Inherited: 0x3cc)
struct ABP_Cocoa_C : ABP_ResourceNodeBase_C {
	char pad_3CC[0x4]; // 0x3cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)

	void PlayHarvestFX(struct FVector Location, struct AIcarusPlayerCharacter* Instigator); // Function BP_Cocoa.BP_Cocoa_C.PlayHarvestFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Cocoa.BP_Cocoa_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Cocoa(int32_t EntryPoint); // Function BP_Cocoa.BP_Cocoa_C.ExecuteUbergraph_BP_Cocoa // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

