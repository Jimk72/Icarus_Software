// BlueprintGeneratedClass BP_Elephant_Corpse.BP_Elephant_Corpse_C
// Size: 0x778 (Inherited: 0x778)
struct ABP_Elephant_Corpse_C : ABP_GOAP_Corpse_C {
};

