// WidgetBlueprintGeneratedClass BestiaryGroupRow.BestiaryGroupRow_C
// Size: 0x2a0 (Inherited: 0x260)
struct UBestiaryGroupRow_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* TextBlock_57; // 0x268(0x08)
	struct FText BestiaryName; // 0x270(0x18)
	struct FBestiaryDataRowHandle Bestiary; // 0x288(0x18)

	void SetBestiary(struct FBestiaryDataRowHandle NewBestiary); // Function BestiaryGroupRow.BestiaryGroupRow_C.SetBestiary // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetAsAll(); // Function BestiaryGroupRow.BestiaryGroupRow_C.SetAsAll // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BestiaryGroupRow(int32_t EntryPoint); // Function BestiaryGroupRow.BestiaryGroupRow_C.ExecuteUbergraph_BestiaryGroupRow // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

