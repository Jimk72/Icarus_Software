// BlueprintGeneratedClass BP_Cement_Mixer.BP_Cement_Mixer_C
// Size: 0xa18 (Inherited: 0x9d4)
struct ABP_Cement_Mixer_C : ABP_ResourceNetworkProcessor_C {
	char pad_9D4[0x4]; // 0x9d4(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9d8(0x08)
	struct UFMODAudioComponent* FMODAudio_CementStart; // 0x9e0(0x08)
	struct UStaticMeshComponent* SM_DEP_Concrete_Mixer_Proxy_Output3; // 0x9e8(0x08)
	struct UStaticMeshComponent* SM_DEP_Concrete_Mixer_Proxy_Output2; // 0x9f0(0x08)
	struct UStaticMeshComponent* SM_DEP_Concrete_Mixer_Proxy_Output1; // 0x9f8(0x08)
	struct UStaticMeshComponent* SM_DEP_Concrete_Mixer_Proxy_Input3; // 0xa00(0x08)
	struct UStaticMeshComponent* SM_DEP_Concrete_Mixer_Proxy_Input2; // 0xa08(0x08)
	struct UStaticMeshComponent* SM_DEP_Concrete_Mixer_Proxy_Input1; // 0xa10(0x08)

	void UpdateEffects(bool EnergyFlowChanged, bool ProcessorActiveChanged); // Function BP_Cement_Mixer.BP_Cement_Mixer_C.UpdateEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UserConstructionScript(); // Function BP_Cement_Mixer.BP_Cement_Mixer_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceOnStateChanged(bool bIsOn); // Function BP_Cement_Mixer.BP_Cement_Mixer_C.OnDeviceOnStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Cement_Mixer.BP_Cement_Mixer_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Cement_Mixer(int32_t EntryPoint); // Function BP_Cement_Mixer.BP_Cement_Mixer_C.ExecuteUbergraph_BP_Cement_Mixer // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

