// BlueprintGeneratedClass BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C
// Size: 0x560 (Inherited: 0x468)
struct UBP_ActionableBehaviour_CurvedSplinePlace_C : UBP_ActionableBehaviour_SimplePlace_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)
	struct ABP_IcarusSplineActor_C* WorkingSpline; // 0x470(0x08)
	struct TMap<int32_t, enum class SplineTypes> ToolTypeMap; // 0x478(0x50)
	int32_t ToolInt; // 0x4c8(0x04)
	enum class SplineTypes SplineType; // 0x4cc(0x01)
	char pad_4CD[0x3]; // 0x4cd(0x03)
	struct TMap<enum class SplineTypes, float> SplineTypeMaxDistance; // 0x4d0(0x50)
	bool Snapping; // 0x520(0x01)
	char pad_521[0x7]; // 0x521(0x07)
	struct UFMODEvent* FMODEvent_SplinePlaced_Anchorable; // 0x528(0x08)
	struct UFMODEvent* FMODEvent_SplinePlaced_Spline; // 0x530(0x08)
	struct UFMODEvent* FMODEvent_SplinePlaced_Deployable; // 0x538(0x08)
	float InspectorTraceRange; // 0x540(0x04)
	enum class EIcarusResourceType LimitInspectorToType; // 0x544(0x01)
	char pad_545[0x3]; // 0x545(0x03)
	struct FTimerHandle SplineHighlightTimerHandle; // 0x548(0x08)
	struct AResourceNetwork* FocusedNetwork; // 0x550(0x08)
	struct UUMG_ResourceNetworkInspector_FullScreen_C* InspectorWidget; // 0x558(0x08)

	void GetClosestWorldAndLocalPointsOnSpline(struct USplineComponent* Spline, struct FVector& WorldLocation, struct FVector& ClosestLocal, struct FVector& ClosestWorld); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.GetClosestWorldAndLocalPointsOnSpline // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HighlightTrace(struct AResourceNetwork*& HoveredNetwork); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.HighlightTrace // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HighlightPrimitive(struct UObject* Object, int32_t StencilValue); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.HighlightPrimitive // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetSplineHighlightStencilValue(bool IsHovered, bool IsFocused, bool IsCorrectSplineType, enum class EIcarusResourceType SplineType, int32_t& StencilValue); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.GetSplineHighlightStencilValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ClearSplineNetworkHighlights(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ClearSplineNetworkHighlights // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateSplineNetworkHighlighting(struct AResourceNetwork* HoveredNetwork, struct AResourceNetwork* FocusedNetwork); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.UpdateSplineNetworkHighlighting // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void InspectorLineTrace(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.InspectorLineTrace // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Try Link As Icarus Actor(struct AActor* Actor, struct FHitResult& Hit); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.Try Link As Icarus Actor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CleanupSpline(bool CleanupWorkingSplineOnly); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.CleanupSpline // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ProcessLastSplinePoint(struct FTransform& HitTransform, struct UBP_IcarusSplineSegment_C* SplineSegment, struct ABP_IcarusSplineActor_C* SplineActor); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ProcessLastSplinePoint // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetSplineConnectionPointFromActor(struct AActor* Actor, enum class SplineTypes SplineType, struct FTransform& Transform); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.GetSplineConnectionPointFromActor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void WorldSpaceTooCloseToAnySpline(struct FVector WorldSpaceLocation, bool& bLocked); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.WorldSpaceTooCloseToAnySpline // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ActorIsLinkable(struct AIcarusActor* IcarusActor, bool& Linkable); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ActorIsLinkable // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayNegativeFeedback(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.PlayNegativeFeedback // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlaySplinePointPlacedAudio(enum class ECurvedSplinePlaceContext Context, struct FHitResult& Hit); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.PlaySplinePointPlacedAudio // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SplineAnchorableHitCheck(struct AActor* HitActor, bool& CanPlacePoint); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.SplineAnchorableHitCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_Snapping(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.OnRep_Snapping // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void FindSegmentFromComponent(struct ABP_IcarusSplineActor_C* SplineActor, struct UPrimitiveComponent* HitComponent, struct UBP_IcarusSplineSegment_C*& SplineSegment, int32_t& SegmentIndex, bool& Success); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.FindSegmentFromComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void ShouldActionCameraTrace(enum class EActionableEventType ActionableType, enum class EActionableTrigger ActionableTrigger, bool& ShouldTrace); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ShouldActionCameraTrace // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ValidPlacementCheck(struct FHitResult Hit, bool& Valid); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ValidPlacementCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void TickCameraTraceHit(struct FHitResult Hit, bool DidHit); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.TickCameraTraceHit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnActionCameraTraceHit(struct FHitResult Hit); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.OnActionCameraTraceHit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void MULTI_PlaySplinePointPlacedAudio(struct UFMODEvent* FMODEvent, struct FVector Location, enum class EPhysicalSurface Surface); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.MULTI_PlaySplinePointPlacedAudio // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void TickHighlight(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.TickHighlight // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDynamicWidgetDisplayed(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.OnDynamicWidgetDisplayed // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnMenuOpened(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.OnMenuOpened // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ServerCleanupWorkingSpline(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ServerCleanupWorkingSpline // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ServerClearTracedSpline(); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ServerClearTracedSpline // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_CurvedSplinePlace(int32_t EntryPoint); // Function BP_ActionableBehaviour_CurvedSplinePlace.BP_ActionableBehaviour_CurvedSplinePlace_C.ExecuteUbergraph_BP_ActionableBehaviour_CurvedSplinePlace // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

