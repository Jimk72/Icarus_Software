// BlueprintGeneratedClass BP_Door_Base.BP_Door_Base_C
// Size: 0x794 (Inherited: 0x751)
struct ABP_Door_Base_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	struct UBoxComponent* PlacementBlockerBox; // 0x760(0x08)
	struct UAudioOcclusionComponent* AudioOcclusion1; // 0x768(0x08)
	enum class DoorState DoorState; // 0x770(0x01)
	char pad_771[0x7]; // 0x771(0x07)
	struct FMulticastInlineDelegate OpenStateChanged; // 0x778(0x10)
	struct FTimerHandle DelayedDirtyTimer; // 0x788(0x08)
	int32_t DoorStateSaved; // 0x790(0x04)

	float GetOcclusionValue(); // Function BP_Door_Base.BP_Door_Base_C.GetOcclusionValue // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	void DirtyNavigation(); // Function BP_Door_Base.BP_Door_Base_C.DirtyNavigation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetOpenableStateOnFoundationActor(); // Function BP_Door_Base.BP_Door_Base_C.SetOpenableStateOnFoundationActor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_DoorState(); // Function BP_Door_Base.BP_Door_Base_C.OnRep_DoorState // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Door_Base.BP_Door_Base_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OpenCloseDoor(struct FHitResult HitResult); // Function BP_Door_Base.BP_Door_Base_C.OpenCloseDoor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_Door_Base.BP_Door_Base_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Door_Base.BP_Door_Base_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ScheduleDelayedOpenableStateCheck(); // Function BP_Door_Base.BP_Door_Base_C.ScheduleDelayedOpenableStateCheck // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Door_Base.BP_Door_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Door_Base(int32_t EntryPoint); // Function BP_Door_Base.BP_Door_Base_C.ExecuteUbergraph_BP_Door_Base // (Final|UbergraphFunction) // @ game+0x1f9a5d0
	void OpenStateChanged__DelegateSignature(bool Open); // Function BP_Door_Base.BP_Door_Base_C.OpenStateChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

