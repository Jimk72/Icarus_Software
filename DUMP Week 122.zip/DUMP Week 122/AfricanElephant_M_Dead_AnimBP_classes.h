// AnimBlueprintGeneratedClass AfricanElephant_M_Dead_AnimBP.AfricanElephant_M_Dead_AnimBP_C
// Size: 0x3e8 (Inherited: 0x320)
struct UAfricanElephant_M_Dead_AnimBP_C : UIcarusCorpseAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x328(0x30)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot; // 0x358(0x90)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AfricanElephant_M_Dead_AnimBP.AfricanElephant_M_Dead_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_AfricanElephant_M_Dead_AnimBP(int32_t EntryPoint); // Function AfricanElephant_M_Dead_AnimBP.AfricanElephant_M_Dead_AnimBP_C.ExecuteUbergraph_AfricanElephant_M_Dead_AnimBP // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

