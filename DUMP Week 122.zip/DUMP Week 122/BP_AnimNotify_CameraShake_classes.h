// BlueprintGeneratedClass BP_AnimNotify_CameraShake.BP_AnimNotify_CameraShake_C
// Size: 0x50 (Inherited: 0x38)
struct UBP_AnimNotify_CameraShake_C : UAnimNotify {
	struct UCameraShakeBase* Shake; // 0x38(0x08)
	float Scale; // 0x40(0x04)
	float Radius; // 0x44(0x04)
	struct FName SourceBone; // 0x48(0x08)

	struct FString GetNotifyName(); // Function BP_AnimNotify_CameraShake.BP_AnimNotify_CameraShake_C.GetNotifyName // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimNotify_CameraShake.BP_AnimNotify_CameraShake_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
};

