// AnimBlueprintGeneratedClass 1ST_GUN_Shotgun_Rig_AnimBP.1ST_GUN_Shotgun_Rig_AnimBP_C
// Size: 0x350 (Inherited: 0x2d0)
struct U1ST_GUN_Shotgun_Rig_AnimBP_C : UIcarusAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x308(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function 1ST_GUN_Shotgun_Rig_AnimBP.1ST_GUN_Shotgun_Rig_AnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_1ST_GUN_Shotgun_Rig_AnimBP(int32_t EntryPoint); // Function 1ST_GUN_Shotgun_Rig_AnimBP.1ST_GUN_Shotgun_Rig_AnimBP_C.ExecuteUbergraph_1ST_GUN_Shotgun_Rig_AnimBP // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

