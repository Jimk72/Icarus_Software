// BlueprintGeneratedClass BP_Carved_Wardrobe_A.BP_Carved_Wardrobe_A_C
// Size: 0x76a (Inherited: 0x76a)
struct ABP_Carved_Wardrobe_A_C : ABP_DeployableContainerBase_C {
};

