// BlueprintGeneratedClass BP_AlterationBench.BP_AlterationBench_C
// Size: 0xbe8 (Inherited: 0x9b0)
struct ABP_AlterationBench_C : ABP_ProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9b0(0x08)
	struct UFMODAudioComponent* AlterationProcessingAudio; // 0x9b8(0x08)
	struct UStaticMeshComponent* StaticMesh1; // 0x9c0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x9c8(0x08)
	struct FItemData CurrentItem; // 0x9d0(0x1f0)
	bool InUse; // 0xbc0(0x01)
	char pad_BC1[0x3]; // 0xbc1(0x03)
	float AlterTime; // 0xbc4(0x04)
	float AlterProgress; // 0xbc8(0x04)
	float MaxTime; // 0xbcc(0x04)
	struct UFMODEvent* ItemAlteredSound; // 0xbd0(0x08)
	struct UFMODEvent* ItemUnalteredSound; // 0xbd8(0x08)
	struct AIcarusPlayerCharacter* UsingCharacter; // 0xbe0(0x08)

	void ModifyAlterTime(float AlterTickTime, float& ModifiedAlterTickTime); // Function BP_AlterationBench.BP_AlterationBench_C.ModifyAlterTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void PlaySoundWithParams(struct UFMODEvent* FMODEvent, struct FVector Location); // Function BP_AlterationBench.BP_AlterationBench_C.PlaySoundWithParams // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetInUseAudioState(bool Active); // Function BP_AlterationBench.BP_AlterationBench_C.SetInUseAudioState // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_InUse(); // Function BP_AlterationBench.BP_AlterationBench_C.OnRep_InUse // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayItemUnalteredSound(); // Function BP_AlterationBench.BP_AlterationBench_C.PlayItemUnalteredSound // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayItemAlteredSound(); // Function BP_AlterationBench.BP_AlterationBench_C.PlayItemAlteredSound // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void RemoveItem(); // Function BP_AlterationBench.BP_AlterationBench_C.RemoveItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void AlterItem(); // Function BP_AlterationBench.BP_AlterationBench_C.AlterItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_AlterationBench.BP_AlterationBench_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GenericAction(); // Function BP_AlterationBench.BP_AlterationBench_C.GenericAction // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_AlterationBench.BP_AlterationBench_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void AlterationSlotUpdated(struct UInventory* Inventory, int32_t Location); // Function BP_AlterationBench.BP_AlterationBench_C.AlterationSlotUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_AlterationBench.BP_AlterationBench_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnServer_PerformAction(); // Function BP_AlterationBench.BP_AlterationBench_C.OnServer_PerformAction // (Net|NetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void MULTI_OnAlteredItem(); // Function BP_AlterationBench.BP_AlterationBench_C.MULTI_OnAlteredItem // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void MULTI_OnRemovedItemAlteration(); // Function BP_AlterationBench.BP_AlterationBench_C.MULTI_OnRemovedItemAlteration // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GenericActionWithCharacter(struct AIcarusPlayerCharacter* Character); // Function BP_AlterationBench.BP_AlterationBench_C.GenericActionWithCharacter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_AlterationBench(int32_t EntryPoint); // Function BP_AlterationBench.BP_AlterationBench_C.ExecuteUbergraph_BP_AlterationBench // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

