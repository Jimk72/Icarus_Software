// BlueprintGeneratedClass BP_CaveEntrance_LC_SML_03.BP_CaveEntrance_LC_SML_03_C
// Size: 0x328 (Inherited: 0x320)
struct ABP_CaveEntrance_LC_SML_03_C : ABP_BaseCaveEntrance_C {
	struct UStaticMeshComponent* StaticMesh01; // 0x320(0x08)
};

