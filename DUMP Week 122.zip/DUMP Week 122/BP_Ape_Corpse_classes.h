// BlueprintGeneratedClass BP_Ape_Corpse.BP_Ape_Corpse_C
// Size: 0x780 (Inherited: 0x778)
struct ABP_Ape_Corpse_C : ABP_GOAP_Corpse_C {
	struct UGFurComponent* GFur; // 0x778(0x08)
};

