// BlueprintGeneratedClass BP_DeployablePreview.BP_DeployablePreview_C
// Size: 0x288 (Inherited: 0x230)
struct ABP_DeployablePreview_C : AStaticMeshActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UWidgetComponent* RotatorWidget; // 0x238(0x08)
	struct UBoxComponent* BoundsCollider; // 0x240(0x08)
	struct UStaticMesh* MeshRef; // 0x248(0x08)
	float WidgetDrawSize; // 0x250(0x04)
	enum class EWorldPlacementType PlacementType; // 0x254(0x01)
	char pad_255[0x3]; // 0x255(0x03)
	struct FVector ExtentOffset; // 0x258(0x0c)
	struct FVector OriginOffset; // 0x264(0x0c)
	struct FVector ExtentScale; // 0x270(0x0c)
	bool InitialShowRotator; // 0x27c(0x01)
	bool EnableShelterChecks; // 0x27d(0x01)
	char pad_27E[0x2]; // 0x27e(0x02)
	struct UShelteredModifierComponent* ShelterModifier; // 0x280(0x08)

	void UpdateMaterials(bool ValidPlacement); // Function BP_DeployablePreview.BP_DeployablePreview_C.UpdateMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetInitialRotator(bool Visible); // Function BP_DeployablePreview.BP_DeployablePreview_C.SetInitialRotator // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ToggleRotationIndicator(bool Enabled, bool SnappingAvailable); // Function BP_DeployablePreview.BP_DeployablePreview_C.ToggleRotationIndicator // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UserConstructionScript(); // Function BP_DeployablePreview.BP_DeployablePreview_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_DeployablePreview.BP_DeployablePreview_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_DeployablePreview.BP_DeployablePreview_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_DeployablePreview(int32_t EntryPoint); // Function BP_DeployablePreview.BP_DeployablePreview_C.ExecuteUbergraph_BP_DeployablePreview // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

