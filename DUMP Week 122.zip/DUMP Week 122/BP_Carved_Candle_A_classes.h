// BlueprintGeneratedClass BP_Carved_Candle_A.BP_Carved_Candle_A_C
// Size: 0x7a0 (Inherited: 0x790)
struct ABP_Carved_Candle_A_C : ABP_Light_Fire_Base_C {
	struct UNiagaraComponent* NS_Candle_FX; // 0x790(0x08)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x798(0x08)
};

