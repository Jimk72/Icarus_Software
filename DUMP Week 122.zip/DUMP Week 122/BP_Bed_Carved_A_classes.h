// BlueprintGeneratedClass BP_Bed_Carved_A.BP_Bed_Carved_A_C
// Size: 0x798 (Inherited: 0x798)
struct ABP_Bed_Carved_A_C : ABP_Bed_Wood_C {
};

