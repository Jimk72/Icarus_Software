// BlueprintGeneratedClass BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C
// Size: 0x7a8 (Inherited: 0x751)
struct ABP_BasicOxiteDissolver_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	struct UStaticMeshComponent* Balloon; // 0x760(0x08)
	struct UNiagaraComponent* Niagara; // 0x768(0x08)
	struct UFMODAudioComponent* FMOD_Active_Audio; // 0x770(0x08)
	bool RequiresUpdate; // 0x778(0x01)
	char pad_779[0x3]; // 0x779(0x03)
	int32_t UnitsToTransfer; // 0x77c(0x04)
	struct UInventory* GeneralInventory; // 0x780(0x08)
	float FillScale; // 0x788(0x04)
	int32_t StoredUnits; // 0x78c(0x04)
	int32_t MaximumStoredUnits; // 0x790(0x04)
	char pad_794[0x4]; // 0x794(0x04)
	struct UFMODEvent* ConsumeOxygenSound; // 0x798(0x08)
	struct UFMODEvent* ActiveSound; // 0x7a0(0x08)

	void GetWidgetClass(struct UUserWidget*& Widget); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.GetWidgetClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GeneratorStateUpdate(bool Active); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.GeneratorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Update_FmodParameters(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Update_FmodParameters // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Deployable_Pickup(struct AActor* Instigator, bool& PickedUp); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Deployable_Pickup // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Leak(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Leak // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_FillScale(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.OnRep_FillScale // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void FillableUnitsUpdated(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.FillableUnitsUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnInventoryItemAdded(struct UInventory* Inventory, int32_t Location); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.OnInventoryItemAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Multi_OnConsumeOxygen(struct AIcarusPlayerCharacter* Instigator); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.Multi_OnConsumeOxygen // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void DeployableTick(float DeltaSeconds); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_BasicOxiteDissolver(int32_t EntryPoint); // Function BP_BasicOxiteDissolver.BP_BasicOxiteDissolver_C.ExecuteUbergraph_BP_BasicOxiteDissolver // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

