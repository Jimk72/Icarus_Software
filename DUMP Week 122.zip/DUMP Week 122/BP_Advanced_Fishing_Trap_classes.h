// BlueprintGeneratedClass BP_Advanced_Fishing_Trap.BP_Advanced_Fishing_Trap_C
// Size: 0x7b0 (Inherited: 0x7a1)
struct ABP_Advanced_Fishing_Trap_C : ABP_Basic_Fishing_Trap_C {
	char pad_7A1[0x7]; // 0x7a1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7a8(0x08)

	void ReceiveBeginPlay(); // Function BP_Advanced_Fishing_Trap.BP_Advanced_Fishing_Trap_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Advanced_Fishing_Trap(int32_t EntryPoint); // Function BP_Advanced_Fishing_Trap.BP_Advanced_Fishing_Trap_C.ExecuteUbergraph_BP_Advanced_Fishing_Trap // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

