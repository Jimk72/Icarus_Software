// BlueprintGeneratedClass BP_Deployable_SpawnBlocker_T4.BP_Deployable_SpawnBlocker_T4_C
// Size: 0x780 (Inherited: 0x76d)
struct ABP_Deployable_SpawnBlocker_T4_C : ABP_Deployable_SpawnBlocker_C {
	char pad_76D[0x3]; // 0x76d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x770(0x08)
	struct UNiagaraComponent* NS_SoundWave; // 0x778(0x08)

	void UpdateSpawnBlockerEffects(); // Function BP_Deployable_SpawnBlocker_T4.BP_Deployable_SpawnBlocker_T4_C.UpdateSpawnBlockerEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Deployable_SpawnBlocker_T4.BP_Deployable_SpawnBlocker_T4_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceOnStateChanged(bool bIsOn); // Function BP_Deployable_SpawnBlocker_T4.BP_Deployable_SpawnBlocker_T4_C.OnDeviceOnStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Deployable_SpawnBlocker_T4(int32_t EntryPoint); // Function BP_Deployable_SpawnBlocker_T4.BP_Deployable_SpawnBlocker_T4_C.ExecuteUbergraph_BP_Deployable_SpawnBlocker_T4 // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

