// BlueprintGeneratedClass BP_AnimalTrap_Small.BP_AnimalTrap_Small_C
// Size: 0x780 (Inherited: 0x778)
struct ABP_AnimalTrap_Small_C : ABP_AnimalTrap_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x778(0x08)

	void ReceiveBeginPlay(); // Function BP_AnimalTrap_Small.BP_AnimalTrap_Small_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_AnimalTrap_Small(int32_t EntryPoint); // Function BP_AnimalTrap_Small.BP_AnimalTrap_Small_C.ExecuteUbergraph_BP_AnimalTrap_Small // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

