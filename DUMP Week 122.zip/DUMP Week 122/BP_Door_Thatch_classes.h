// BlueprintGeneratedClass BP_Door_Thatch.BP_Door_Thatch_C
// Size: 0x7a0 (Inherited: 0x794)
struct ABP_Door_Thatch_C : ABP_Door_Base_C {
	char pad_794[0x4]; // 0x794(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x798(0x08)

	void ReceiveBeginPlay(); // Function BP_Door_Thatch.BP_Door_Thatch_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Door_Thatch(int32_t EntryPoint); // Function BP_Door_Thatch.BP_Door_Thatch_C.ExecuteUbergraph_BP_Door_Thatch // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

