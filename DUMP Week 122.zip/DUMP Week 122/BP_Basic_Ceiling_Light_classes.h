// BlueprintGeneratedClass BP_Basic_Ceiling_Light.BP_Basic_Ceiling_Light_C
// Size: 0x808 (Inherited: 0x7fc)
struct ABP_Basic_Ceiling_Light_C : ABP_Light_Electric_Base_C {
	char pad_7FC[0x4]; // 0x7fc(0x04)
	struct UBP_IcarusPointLight_C* BP_IcarusPointLight; // 0x800(0x08)
};

