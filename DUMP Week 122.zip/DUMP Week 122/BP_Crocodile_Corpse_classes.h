// BlueprintGeneratedClass BP_Crocodile_Corpse.BP_Crocodile_Corpse_C
// Size: 0x778 (Inherited: 0x778)
struct ABP_Crocodile_Corpse_C : ABP_GOAP_Corpse_C {
};

