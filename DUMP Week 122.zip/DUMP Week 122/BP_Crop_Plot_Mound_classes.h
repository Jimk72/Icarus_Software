// BlueprintGeneratedClass BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C
// Size: 0x830 (Inherited: 0x811)
struct ABP_Crop_Plot_Mound_C : ABP_Crop_Plot_Base_C {
	char pad_811[0x7]; // 0x811(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x818(0x08)
	struct UFarmableComponent* Farmable; // 0x820(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x828(0x08)

	void SetSoilState(bool bWet); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.SetSoilState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HarvestResource(struct AActor* HarvestActor, struct UStaticMeshComponent*& StaticMeshComponent, bool bUsingSickle, struct UInventory* NonPlayerInventory, bool& Harvested); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.HarvestResource // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Crop_Plot_Mound(int32_t EntryPoint); // Function BP_Crop_Plot_Mound.BP_Crop_Plot_Mound_C.ExecuteUbergraph_BP_Crop_Plot_Mound // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

