// BlueprintGeneratedClass BP_DryingRack.BP_DryingRack_C
// Size: 0xa20 (Inherited: 0x9b0)
struct ABP_DryingRack_C : ABP_ProcessorBase_C {
	struct UStaticMeshComponent* SM_ITM_Leather_Upgraded; // 0x9b0(0x08)
	struct UStaticMeshComponent* SM_ITM_Leather; // 0x9b8(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Prime_Dried; // 0x9c0(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Prime_Raw; // 0x9c8(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_White_Dried; // 0x9d0(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_White_Raw; // 0x9d8(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Soft_Dried; // 0x9e0(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Soft_Raw; // 0x9e8(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_TBone_Dried; // 0x9f0(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_TBone_Raw; // 0x9f8(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Stringy_Dried; // 0xa00(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Stringy_Raw; // 0xa08(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Gamey_Dried; // 0xa10(0x08)
	struct UStaticMeshComponent* SM_ITM_Meat_Gamey_Raw; // 0xa18(0x08)

	void UserConstructionScript(); // Function BP_DryingRack.BP_DryingRack_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

