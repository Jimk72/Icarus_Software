// BlueprintGeneratedClass BP_Building_Wall_Diagonal_Curved_Stone.BP_Building_Wall_Diagonal_Curved_Stone_C
// Size: 0xbd0 (Inherited: 0xbd0)
struct ABP_Building_Wall_Diagonal_Curved_Stone_C : ABP_Building_Wall_Diagonal_Curved_C {
};

