// BlueprintGeneratedClass BP_Anvil_Bench_T4.BP_Anvil_Bench_T4_C
// Size: 0xa10 (Inherited: 0x9d4)
struct ABP_Anvil_Bench_T4_C : ABP_ResourceNetworkProcessor_C {
	char pad_9D4[0x4]; // 0x9d4(0x04)
	struct UFMODAudioComponent* PoweredAudio; // 0x9d8(0x08)
	struct UStaticMeshComponent* Output3; // 0x9e0(0x08)
	struct UStaticMeshComponent* Output2; // 0x9e8(0x08)
	struct UStaticMeshComponent* Output1; // 0x9f0(0x08)
	struct UStaticMeshComponent* Input3; // 0x9f8(0x08)
	struct UStaticMeshComponent* Input2; // 0xa00(0x08)
	struct UStaticMeshComponent* Input1; // 0xa08(0x08)

	void UpdateEffects(bool EnergyFlowChanged, bool ProcessorActiveChanged); // Function BP_Anvil_Bench_T4.BP_Anvil_Bench_T4_C.UpdateEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

