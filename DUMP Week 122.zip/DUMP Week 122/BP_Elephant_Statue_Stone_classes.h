// BlueprintGeneratedClass BP_Elephant_Statue_Stone.BP_Elephant_Statue_Stone_C
// Size: 0x760 (Inherited: 0x751)
struct ABP_Elephant_Statue_Stone_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)

	void ReceiveBeginPlay(); // Function BP_Elephant_Statue_Stone.BP_Elephant_Statue_Stone_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Elephant_Statue_Stone(int32_t EntryPoint); // Function BP_Elephant_Statue_Stone.BP_Elephant_Statue_Stone_C.ExecuteUbergraph_BP_Elephant_Statue_Stone // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

