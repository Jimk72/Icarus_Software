// BlueprintGeneratedClass BP_Advanced_Aquarium.BP_Advanced_Aquarium_C
// Size: 0x840 (Inherited: 0x840)
struct ABP_Advanced_Aquarium_C : ABP_Aquarium_C {
};

