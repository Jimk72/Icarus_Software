// BlueprintGeneratedClass BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C
// Size: 0x3ac (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Scanner_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct AIcarusPlayerCharacterSurvival* BehaviourOwner; // 0x318(0x08)
	struct AIcarusItem* IcarusItem; // 0x320(0x08)
	float ScanningIntensity; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)
	struct TArray<struct AActor*> NearbyActors; // 0x330(0x10)
	float MaxScanningRange; // 0x340(0x04)
	bool UseDistance; // 0x344(0x01)
	char pad_345[0x3]; // 0x345(0x03)
	struct UCurveFloat* ProximityItensityCurve; // 0x348(0x08)
	bool UseDirection; // 0x350(0x01)
	char pad_351[0x7]; // 0x351(0x07)
	struct UCurveFloat* DirectionIntensityCurve; // 0x358(0x08)
	struct FTimerHandle NearbyActorsHandle; // 0x360(0x08)
	float NearbyActorsFrequency; // 0x368(0x04)
	char pad_36C[0x4]; // 0x36c(0x04)
	struct AActor* ClassToScan; // 0x370(0x08)
	float MaxDirectionAngle; // 0x378(0x04)
	bool ShowClosestAngle; // 0x37c(0x01)
	char pad_37D[0x3]; // 0x37d(0x03)
	struct UCurveFloat* ClosestAngleOffsetCurve; // 0x380(0x08)
	float ClosestAngle; // 0x388(0x04)
	float MaxExtraNoiseMultiplier; // 0x38c(0x04)
	float ClosestAngleNoise; // 0x390(0x04)
	float MaxAngleOffset; // 0x394(0x04)
	struct FVector2D AngleOffsetDelayFrequency; // 0x398(0x08)
	struct UCurveFloat* BeepingCurve; // 0x3a0(0x08)
	float BeepingIntensity; // 0x3a8(0x04)

	struct TArray<struct AActor*> ExtraNearbyFilter(struct TArray<struct AActor*>& InNearbyActors); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.ExtraNearbyFilter // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void LocalOrServer(bool& Local, bool& Server); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.LocalOrServer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateScanningIntensity(); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.UpdateScanningIntensity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateNearbyActors(); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.UpdateNearbyActors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Scanner(int32_t EntryPoint); // Function BP_ActionableBehaviour_Scanner.BP_ActionableBehaviour_Scanner_C.ExecuteUbergraph_BP_ActionableBehaviour_Scanner // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

