// BlueprintGeneratedClass BP_Carved_ChairDining_A.BP_Carved_ChairDining_A_C
// Size: 0x7c8 (Inherited: 0x7c8)
struct ABP_Carved_ChairDining_A_C : ABP_ChairBase_C {
};

