// BlueprintGeneratedClass BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C
// Size: 0x7a8 (Inherited: 0x76d)
struct ABP_Deployable_SpawnBlocker_T3_C : ABP_Deployable_SpawnBlocker_C {
	char pad_76D[0x3]; // 0x76d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x770(0x08)
	struct UFMODAudioComponent* PoweredAudioLoop; // 0x778(0x08)
	struct UNiagaraComponent* NS_Spray3; // 0x780(0x08)
	struct UNiagaraComponent* NS_Spray2; // 0x788(0x08)
	struct UNiagaraComponent* NS_Spray1; // 0x790(0x08)
	struct UNiagaraComponent* NS_Spray; // 0x798(0x08)
	struct UCameraComponent* Camera; // 0x7a0(0x08)

	void CheckBlockerActive(); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.CheckBlockerActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateSpawnBlockerEffects(); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.UpdateSpawnBlockerEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GeneratorStateUpdate(bool Active); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.GeneratorStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnFuelInventoryUpdated(struct UInventory* Inventory, int32_t Location); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.OnFuelInventoryUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceOnStateChanged(bool bIsOn); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.OnDeviceOnStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OutOfFuelCheck(); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.OutOfFuelCheck // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Deployable_SpawnBlocker_T3(int32_t EntryPoint); // Function BP_Deployable_SpawnBlocker_T3.BP_Deployable_SpawnBlocker_T3_C.ExecuteUbergraph_BP_Deployable_SpawnBlocker_T3 // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

