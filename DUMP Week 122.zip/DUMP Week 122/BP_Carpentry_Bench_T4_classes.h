// BlueprintGeneratedClass BP_Carpentry_Bench_T4.BP_Carpentry_Bench_T4_C
// Size: 0xa08 (Inherited: 0x9d4)
struct ABP_Carpentry_Bench_T4_C : ABP_ResourceNetworkProcessor_C {
	char pad_9D4[0x4]; // 0x9d4(0x04)
	struct UPointLightComponent* PointLight; // 0x9d8(0x08)
	struct UStaticMeshComponent* SM_DEP_Carpentry_BenchT4_Proxy4; // 0x9e0(0x08)
	struct UStaticMeshComponent* SM_DEP_Carpentry_BenchT4_Proxy3; // 0x9e8(0x08)
	struct UStaticMeshComponent* SM_DEP_Carpentry_BenchT4_Proxy2; // 0x9f0(0x08)
	struct UStaticMeshComponent* SM_DEP_Carpentry_BenchT4_Proxy1; // 0x9f8(0x08)
	struct USceneComponent* Proxy_Wood; // 0xa00(0x08)

	void UpdateEffects(bool EnergyFlowChanged, bool ProcessorActiveChanged); // Function BP_Carpentry_Bench_T4.BP_Carpentry_Bench_T4_C.UpdateEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

