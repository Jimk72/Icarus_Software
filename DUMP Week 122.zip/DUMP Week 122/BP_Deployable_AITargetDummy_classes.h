// BlueprintGeneratedClass BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C
// Size: 0x778 (Inherited: 0x751)
struct ABP_Deployable_AITargetDummy_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	struct UGenericAITargetComponent* GenericAITarget; // 0x760(0x08)
	bool IsMoving; // 0x768(0x01)
	char pad_769[0x3]; // 0x769(0x03)
	struct FVector_NetQuantize10 TargetLocation; // 0x76c(0x0c)

	bool ShouldOverrideTargetNeutrality(struct AActor* TargetActor, bool& bIsTargetHostile); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.ShouldOverrideTargetNeutrality // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	struct TArray<struct FCriticalHitLocation> GetCriticalHitBones(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.GetCriticalHitBones // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	struct FAIRelationshipsRowHandle GetRelationshipData(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.GetRelationshipData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	int32_t GetTargetAlertness(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.GetTargetAlertness // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	struct FVector GetTargetLocation(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.GetTargetLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool IsActorAlive(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.IsActorAlive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool IsCriticalHitDisabled(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.IsCriticalHitDisabled // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool IsHidden(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.IsHidden // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void GetIsMoving(bool& IsMoving); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.GetIsMoving // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void ToggleMovement(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.ToggleMovement // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void DeployableTick(float DeltaSeconds); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.DeployableTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ChooseNewMoveTarget(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.ChooseNewMoveTarget // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Deployable_AITargetDummy(int32_t EntryPoint); // Function BP_Deployable_AITargetDummy.BP_Deployable_AITargetDummy_C.ExecuteUbergraph_BP_Deployable_AITargetDummy // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

