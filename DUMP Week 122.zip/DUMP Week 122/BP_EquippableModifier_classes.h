// BlueprintGeneratedClass BP_EquippableModifier.BP_EquippableModifier_C
// Size: 0xf8 (Inherited: 0xe0)
struct UBP_EquippableModifier_C : UEquippableModifier {
	struct FText ItemName; // 0xe0(0x18)

	bool ItemUnequipped(); // Function BP_EquippableModifier.BP_EquippableModifier_C.ItemUnequipped // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	bool ItemEquipped(); // Function BP_EquippableModifier.BP_EquippableModifier_C.ItemEquipped // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

