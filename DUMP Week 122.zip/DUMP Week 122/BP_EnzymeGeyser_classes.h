// BlueprintGeneratedClass BP_EnzymeGeyser.BP_EnzymeGeyser_C
// Size: 0x370 (Inherited: 0x2e0)
struct ABP_EnzymeGeyser_C : AEnzymeGeyser {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)
	struct UNiagaraComponent* Niagara_EruptionBase; // 0x2e8(0x08)
	struct UNiagaraComponent* Niagara_EruptionTop; // 0x2f0(0x08)
	struct UStaticMeshComponent* SM_Geyser_01; // 0x2f8(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x300(0x08)
	struct UOverlapAudioComponent* Audio_Eruption; // 0x308(0x08)
	struct UOverlapAudioComponent* Audio_Geyser; // 0x310(0x08)
	struct UHighlightableComponent* Highlightable; // 0x318(0x08)
	struct UNiagaraComponent* Niagara_Mist; // 0x320(0x08)
	struct USceneComponent* Scene; // 0x328(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x330(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x338(0x08)
	float Timeline_1_Float_358402384E5111894982969E0920B36F; // 0x340(0x04)
	enum class ETimelineDirection Timeline_1__Direction_358402384E5111894982969E0920B36F; // 0x344(0x01)
	char pad_345[0x3]; // 0x345(0x03)
	struct UTimelineComponent* Timeline_2; // 0x348(0x08)
	float Timeline_0_Float_26493B2345BBE52BA6691B8E5C2FBBC0; // 0x350(0x04)
	enum class ETimelineDirection Timeline_0__Direction_26493B2345BBE52BA6691B8E5C2FBBC0; // 0x354(0x01)
	char pad_355[0x3]; // 0x355(0x03)
	struct UTimelineComponent* Timeline_1; // 0x358(0x08)
	bool HasAttachedAnalyzer; // 0x360(0x01)
	char pad_361[0x7]; // 0x361(0x07)
	struct UStaticMeshComponent* LocatorMesh; // 0x368(0x08)

	void DebugMaxCompletions(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.DebugMaxCompletions // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void DeactivateEruptionFX(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.DeactivateEruptionFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ActivateEruptionFX(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.ActivateEruptionFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateBiome(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.UpdateBiome // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void HideEditorLocator(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.HideEditorLocator // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ShowEditorLocator(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.ShowEditorLocator // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateAudioState(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.UpdateAudioState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_HasAttachedAnalyzer(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.OnRep_HasAttachedAnalyzer // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Timeline_0__FinishedFunc(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0x1f9a5d0
	void Timeline_0__UpdateFunc(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0x1f9a5d0
	void Timeline_1__FinishedFunc(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.Timeline_1__FinishedFunc // (BlueprintEvent) // @ game+0x1f9a5d0
	void Timeline_1__UpdateFunc(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.Timeline_1__UpdateFunc // (BlueprintEvent) // @ game+0x1f9a5d0
	void AddAttachedDeployable(struct ADeployable* Deployable); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.AddAttachedDeployable // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void RemoveAttachedDeployable(struct ADeployable* Deployable); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.RemoveAttachedDeployable // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ActivateEruption(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.ActivateEruption // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void DeactivateEruption(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.DeactivateEruption // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ResetCompletions(); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.ResetCompletions // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_EnzymeGeyser(int32_t EntryPoint); // Function BP_EnzymeGeyser.BP_EnzymeGeyser_C.ExecuteUbergraph_BP_EnzymeGeyser // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

