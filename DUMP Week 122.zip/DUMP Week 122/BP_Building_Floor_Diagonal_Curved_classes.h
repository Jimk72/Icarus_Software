// BlueprintGeneratedClass BP_Building_Floor_Diagonal_Curved.BP_Building_Floor_Diagonal_Curved_C
// Size: 0xbe0 (Inherited: 0xbe0)
struct ABP_Building_Floor_Diagonal_Curved_C : ABP_Building_Floor_C {
};

