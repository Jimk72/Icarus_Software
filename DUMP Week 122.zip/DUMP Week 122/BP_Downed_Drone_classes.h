// BlueprintGeneratedClass BP_Downed_Drone.BP_Downed_Drone_C
// Size: 0x36a (Inherited: 0x311)
struct ABP_Downed_Drone_C : ABP_WorldObject_C {
	char pad_311[0x7]; // 0x311(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct UFMODAudioComponent* ExplosionAudio; // 0x320(0x08)
	struct UParticleSystemComponent* Explode_Particle; // 0x328(0x08)
	struct UFMODAudioComponent* AlarmAudio; // 0x330(0x08)
	struct UGenericAITargetComponent* GenericAITarget; // 0x338(0x08)
	struct UIcarusMapIconComponent* IcarusMapIcon; // 0x340(0x08)
	struct UParticleSystemComponent* Sparks_Particle; // 0x348(0x08)
	struct UParticleSystemComponent* Smoke_Particle; // 0x350(0x08)
	struct UStaticMeshComponent* SM_ObjectMesh1; // 0x358(0x08)
	struct UNiagaraComponent* Smoke; // 0x360(0x08)
	bool PlayAlarm; // 0x368(0x01)
	bool Explode; // 0x369(0x01)

	void OnRep_Explode(); // Function BP_Downed_Drone.BP_Downed_Drone_C.OnRep_Explode // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_PlayAlarm(); // Function BP_Downed_Drone.BP_Downed_Drone_C.OnRep_PlayAlarm // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void WorldObject_Interact(struct AActor* Instigator); // Function BP_Downed_Drone.BP_Downed_Drone_C.WorldObject_Interact // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Downed_Drone.BP_Downed_Drone_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Downed_Drone(int32_t EntryPoint); // Function BP_Downed_Drone.BP_Downed_Drone_C.ExecuteUbergraph_BP_Downed_Drone // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

