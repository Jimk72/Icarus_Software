// WidgetBlueprintGeneratedClass AfflictionRow.AfflictionRow_C
// Size: 0x290 (Inherited: 0x260)
struct UAfflictionRow_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UTextBlock* RowText; // 0x268(0x08)
	struct FName RowName; // 0x270(0x08)
	struct FName DisplayName; // 0x278(0x08)
	struct FString RowNameStr; // 0x280(0x10)

	bool LessThan(struct UObject* Other); // Function AfflictionRow.AfflictionRow_C.LessThan // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void Set Row(struct FName RowName); // Function AfflictionRow.AfflictionRow_C.Set Row // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_AfflictionRow(int32_t EntryPoint); // Function AfflictionRow.AfflictionRow_C.ExecuteUbergraph_AfflictionRow // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

