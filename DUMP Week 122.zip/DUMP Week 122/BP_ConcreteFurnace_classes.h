// BlueprintGeneratedClass BP_ConcreteFurnace.BP_ConcreteFurnace_C
// Size: 0xa00 (Inherited: 0x9e0)
struct ABP_ConcreteFurnace_C : ABP_FireProcessorBase_C {
	struct UPointLightComponent* PointLight; // 0x9e0(0x08)
	struct USpotLightComponent* SpotLight; // 0x9e8(0x08)
	struct USceneComponent* Scene_Lights; // 0x9f0(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x9f8(0x08)

	void UpdateEffects(bool Active); // Function BP_ConcreteFurnace.BP_ConcreteFurnace_C.UpdateEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

