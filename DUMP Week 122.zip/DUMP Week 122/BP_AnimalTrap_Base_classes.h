// BlueprintGeneratedClass BP_AnimalTrap_Base.BP_AnimalTrap_Base_C
// Size: 0x778 (Inherited: 0x751)
struct ABP_AnimalTrap_Base_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	struct UBoxComponent* Box; // 0x760(0x08)
	float AttractionRadius; // 0x768(0x04)
	bool IsTrapOccupied; // 0x76c(0x01)
	char pad_76D[0x3]; // 0x76d(0x03)
	struct UInventory* InventoryRef; // 0x770(0x08)

	void Deployable_Interact(struct AActor* Interactor); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnAnimalTrapped(struct FItemsStaticRowHandle Item Static Data); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.OnAnimalTrapped // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Setup(); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1f9a5d0
	void OnItemRemoved(struct UInventory* Inventory, int32_t Location); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.OnItemRemoved // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnItemAdded(struct UInventory* Inventory, int32_t Location); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.OnItemAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Multi_TrapTriggered(bool ItemAdded); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.Multi_TrapTriggered // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_AnimalTrap_Base(int32_t EntryPoint); // Function BP_AnimalTrap_Base.BP_AnimalTrap_Base_C.ExecuteUbergraph_BP_AnimalTrap_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

