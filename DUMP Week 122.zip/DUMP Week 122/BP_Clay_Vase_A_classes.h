// BlueprintGeneratedClass BP_Clay_Vase_A.BP_Clay_Vase_A_C
// Size: 0x760 (Inherited: 0x751)
struct ABP_Clay_Vase_A_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)

	void ReceiveBeginPlay(); // Function BP_Clay_Vase_A.BP_Clay_Vase_A_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Clay_Vase_A(int32_t EntryPoint); // Function BP_Clay_Vase_A.BP_Clay_Vase_A_C.ExecuteUbergraph_BP_Clay_Vase_A // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

