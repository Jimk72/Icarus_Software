// BlueprintGeneratedClass BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C
// Size: 0xe28 (Inherited: 0xe18)
struct UBP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C : UBP_ActionableBehaviour_Firearm_AmmoController_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe18(0x08)
	struct AIcarusItem* PreviewItem; // 0xe20(0x08)

	void RefundAmmo(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.RefundAmmo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetupPlayer(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.SetupPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ConsumeAmmo(int32_t Amount); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.ConsumeAmmo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void AttachPreviewItem(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.AttachPreviewItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetPreviewItem(struct AIcarusItem* NewPreviewItem); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.SetPreviewItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdatePreviewItem(bool Show); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.UpdatePreviewItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CleanupPreviewItem(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.CleanupPreviewItem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	int32_t GetAmmoCapacity(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.GetAmmoCapacity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void SetPreviewItemVisible(bool Visible); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.SetPreviewItemVisible // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnReloadStart(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.OnReloadStart // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnAmmoTypeChanged(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.OnAmmoTypeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnWeaponFired(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.OnWeaponFired // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnAmmoUnloaded(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.OnAmmoUnloaded // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnWeaponInventoryUpdated(); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.OnWeaponInventoryUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile(int32_t EntryPoint); // Function BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile.BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile_C.ExecuteUbergraph_BP_ActionableBehaviour_Firearm_AmmoController_VisibleProjectile // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

