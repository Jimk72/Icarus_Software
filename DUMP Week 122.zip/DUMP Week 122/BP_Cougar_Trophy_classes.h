// BlueprintGeneratedClass BP_Cougar_Trophy.BP_Cougar_Trophy_C
// Size: 0x760 (Inherited: 0x751)
struct ABP_Cougar_Trophy_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct UGFurComponent* GFur; // 0x758(0x08)
};

