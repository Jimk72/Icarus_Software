// BlueprintGeneratedClass BP_Composter.BP_Composter_C
// Size: 0x9d4 (Inherited: 0x9d4)
struct ABP_Composter_C : ABP_ResourceNetworkProcessor_C {
};

