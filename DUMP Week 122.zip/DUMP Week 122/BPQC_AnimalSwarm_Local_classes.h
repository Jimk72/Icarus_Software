// BlueprintGeneratedClass BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C
// Size: 0x170 (Inherited: 0x164)
struct UBPQC_AnimalSwarm_Local_C : UBPQC_AnimalSwarm_C {
	char pad_164[0x4]; // 0x164(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x168(0x08)

	void GetCreatureToSpawnFromAtmosphere(struct FAtmospheresEnum Atmosphere, struct FAISetupRowHandle& OutCreature); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.GetCreatureToSpawnFromAtmosphere // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ModifyTimeByAttraction(float RawValue, float& ModifiedValue); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.ModifyTimeByAttraction // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void GetFallbackCreature(struct FAISetupRowHandle& CreatureToSpawn); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.GetFallbackCreature // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ModifyAmountByAttraction(int32_t RawValue, int32_t& ModifiedValue); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.ModifyAmountByAttraction // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	bool CanSpawn(); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.CanSpawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void Select AITo Spawn(struct FAISetupRowHandle& Output); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.Select AITo Spawn // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void SpawnCreature(); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.SpawnCreature // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BPQC_AnimalSwarm_Local(int32_t EntryPoint); // Function BPQC_AnimalSwarm_Local.BPQC_AnimalSwarm_Local_C.ExecuteUbergraph_BPQC_AnimalSwarm_Local // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

