// BlueprintGeneratedClass BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C
// Size: 0x320 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Shield_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct AIcarusPlayerCharacter* Owning Player; // 0x318(0x08)

	void Setup(struct AActor* Owning Actor); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void StopBlocking(); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.StopBlocking // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Shield(int32_t EntryPoint); // Function BP_ActionableBehaviour_Shield.BP_ActionableBehaviour_Shield_C.ExecuteUbergraph_BP_ActionableBehaviour_Shield // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

