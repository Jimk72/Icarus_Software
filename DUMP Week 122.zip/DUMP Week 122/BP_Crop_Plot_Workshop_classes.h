// BlueprintGeneratedClass BP_Crop_Plot_Workshop.BP_Crop_Plot_Workshop_C
// Size: 0x811 (Inherited: 0x811)
struct ABP_Crop_Plot_Workshop_C : ABP_Crop_Plot_Base_C {
};

