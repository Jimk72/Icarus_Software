// BlueprintGeneratedClass BP_BallisticBehaviour_DropshipFlare.BP_BallisticBehaviour_DropshipFlare_C
// Size: 0x7bc (Inherited: 0x7bc)
struct UBP_BallisticBehaviour_DropshipFlare_C : UBP_BallisticBehaviour_FlareArrow_C {
};

