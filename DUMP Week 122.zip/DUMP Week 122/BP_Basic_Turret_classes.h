// BlueprintGeneratedClass BP_Basic_Turret.BP_Basic_Turret_C
// Size: 0x878 (Inherited: 0x761)
struct ABP_Basic_Turret_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UStaticMeshComponent* PlacementSegment; // 0x770(0x08)
	struct UBP_UIProjectionLocation_C* BP_UIProjectionLocation; // 0x778(0x08)
	struct UStaticMeshComponent* Bracket; // 0x780(0x08)
	struct USceneComponent* YawPivot; // 0x788(0x08)
	struct USceneComponent* PitchPivot; // 0x790(0x08)
	struct UWidgetComponent* Widget_TurretInterface; // 0x798(0x08)
	struct UPointLightComponent* StatusLight; // 0x7a0(0x08)
	struct UGenericAITargetComponent* GenericAITarget; // 0x7a8(0x08)
	struct UCameraComponent* Camera; // 0x7b0(0x08)
	struct UArrowComponent* Arrow; // 0x7b8(0x08)
	struct USceneComponent* Muzzle; // 0x7c0(0x08)
	struct UStaticMeshComponent* Gun; // 0x7c8(0x08)
	struct UNiagaraSystem* FireParticle; // 0x7d0(0x08)
	struct TArray<struct AActor*> TargetsInRange; // 0x7d8(0x10)
	struct AActor* SelectedTarget; // 0x7e8(0x08)
	bool HasAmmo; // 0x7f0(0x01)
	bool HasTarget; // 0x7f1(0x01)
	bool HasLock; // 0x7f2(0x01)
	bool NoTargetsInRange; // 0x7f3(0x01)
	bool HasPower; // 0x7f4(0x01)
	char pad_7F5[0x3]; // 0x7f5(0x03)
	struct FRotator CurrentTurrentRotation; // 0x7f8(0x0c)
	struct FRotator TargetTurrentRotation; // 0x804(0x0c)
	int32_t ShotsToFire; // 0x810(0x04)
	float MuzzleFireCoolDownTime; // 0x814(0x04)
	float MuzzleIndividualShotCoolDown; // 0x818(0x04)
	int32_t InventoryAmmoAmount; // 0x81c(0x04)
	struct TArray<struct FItemsStaticRowHandle> ValidAmmoTypes; // 0x820(0x10)
	struct UMaterialInstanceDynamic* PlacementSegmentMaterial; // 0x830(0x08)
	struct FTurretRowHandle TURRET_ROW_HANDLE; // 0x838(0x18)
	float MAX_MUZZLE_PITCH; // 0x850(0x04)
	float MIN_MUZZLE_PITCH; // 0x854(0x04)
	float MAX_MUZZLE_YAW; // 0x858(0x04)
	float MUZZLE_MOVE_SPEED; // 0x85c(0x04)
	float MUZZLE_RETURN_SPEED; // 0x860(0x04)
	float PERMIT_BEGIN_FIRE_ANGLE; // 0x864(0x04)
	int32_t MUZZLE_BURST_FIRE_SHOTS; // 0x868(0x04)
	float MUZZLE_TARGET_CHECK_TIME; // 0x86c(0x04)
	float MUZZLE_COOL_DOWN_PERIOD; // 0x870(0x04)
	float MUZZLE_BURST_FIRE_RATE; // 0x874(0x04)

	bool IsSlotValidForItem(struct UInventoryComponent* Inventory, struct FInventoryIDEnum InventoryID, struct FItemData Item, int32_t SlotIndex); // Function BP_Basic_Turret.BP_Basic_Turret_C.IsSlotValidForItem // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool ShouldOverrideTargetNeutrality(struct AActor* TargetActor, bool& bIsTargetHostile); // Function BP_Basic_Turret.BP_Basic_Turret_C.ShouldOverrideTargetNeutrality // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	struct TArray<struct FCriticalHitLocation> GetCriticalHitBones(); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetCriticalHitBones // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	struct FAIRelationshipsRowHandle GetRelationshipData(); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetRelationshipData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	int32_t GetTargetAlertness(); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetTargetAlertness // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	struct FVector GetTargetLocation(); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetTargetLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool IsActorAlive(); // Function BP_Basic_Turret.BP_Basic_Turret_C.IsActorAlive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool IsCriticalHitDisabled(); // Function BP_Basic_Turret.BP_Basic_Turret_C.IsCriticalHitDisabled // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	bool IsHidden(); // Function BP_Basic_Turret.BP_Basic_Turret_C.IsHidden // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void EnergyNetworkStateUpdate(bool Active); // Function BP_Basic_Turret.BP_Basic_Turret_C.EnergyNetworkStateUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PlayLockOnTargetAudio(); // Function BP_Basic_Turret.BP_Basic_Turret_C.PlayLockOnTargetAudio // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Rotate(struct USceneComponent* Component, bool YawRotation, float DeltaTime); // Function BP_Basic_Turret.BP_Basic_Turret_C.Rotate // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Rebind Turret Stats(); // Function BP_Basic_Turret.BP_Basic_Turret_C.Rebind Turret Stats // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void RandomlyAdjustForPerProjectileAccuracy(struct FVector2D InAccuracy, struct FRotator InRotator, struct FRotator& ModRotator); // Function BP_Basic_Turret.BP_Basic_Turret_C.RandomlyAdjustForPerProjectileAccuracy // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetValidAmmoTypes(struct TArray<struct FItemsStaticRowHandle>& ValidAmmoTypes); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetValidAmmoTypes // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetInventoryAmmoType(struct FItemsStaticRowHandle& ItemType); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetInventoryAmmoType // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_InventoryAmmoAmount(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnRep_InventoryAmmoAmount // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetInventoryAmmoCount(int32_t& OutAmmoCount); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetInventoryAmmoCount // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateInterfaceText(); // Function BP_Basic_Turret.BP_Basic_Turret_C.UpdateInterfaceText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Client_UpdateTurretRotation(float DeltaTime); // Function BP_Basic_Turret.BP_Basic_Turret_C.Client_UpdateTurretRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_HasLock(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnRep_HasLock // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_HasTarget(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnRep_HasTarget // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnRep_HasAmmo(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnRep_HasAmmo // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ConditionalRepTargetRotation(struct FRotator NewRotation); // Function BP_Basic_Turret.BP_Basic_Turret_C.ConditionalRepTargetRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateStatusLight(); // Function BP_Basic_Turret.BP_Basic_Turret_C.UpdateStatusLight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ConditionalFire(); // Function BP_Basic_Turret.BP_Basic_Turret_C.ConditionalFire // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetHasLock(bool& Lock); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetHasLock // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateHasAmmo(); // Function BP_Basic_Turret.BP_Basic_Turret_C.UpdateHasAmmo // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetPercentActorHealth(struct AActor* Actor, int32_t& HealthPercentOut); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetPercentActorHealth // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetMaxAngleToTarget(struct AActor* InTarget, float& MaxAngleOut); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetMaxAngleToTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ApplySpread(struct FRotator BaseDirection, struct FRotator& OutSpreadDirection); // Function BP_Basic_Turret.BP_Basic_Turret_C.ApplySpread // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ConsumeAmmo(); // Function BP_Basic_Turret.BP_Basic_Turret_C.ConsumeAmmo // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IsTargetableFromMaxRotation(bool Location); // Function BP_Basic_Turret.BP_Basic_Turret_C.IsTargetableFromMaxRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Deployable_Interact(struct AActor* Interactor); // Function BP_Basic_Turret.BP_Basic_Turret_C.Deployable_Interact // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void FireAtTarget(); // Function BP_Basic_Turret.BP_Basic_Turret_C.FireAtTarget // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PickTarget(); // Function BP_Basic_Turret.BP_Basic_Turret_C.PickTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetAvailableTargets(); // Function BP_Basic_Turret.BP_Basic_Turret_C.GetAvailableTargets // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateShotTimers(float DeltaTime); // Function BP_Basic_Turret.BP_Basic_Turret_C.UpdateShotTimers // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void UpdateTurretRotation(float DeltaTime); // Function BP_Basic_Turret.BP_Basic_Turret_C.UpdateTurretRotation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnLoaded_CF4FB6C84552BC45838031BE1D8C4A99(struct UObject* Loaded); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnLoaded_CF4FB6C84552BC45838031BE1D8C4A99 // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnInventoryItemChanged(struct UInventory* Inventory, int32_t Location); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnInventoryItemChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_Basic_Turret.BP_Basic_Turret_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void PickNewTarget(); // Function BP_Basic_Turret.BP_Basic_Turret_C.PickNewTarget // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_Basic_Turret.BP_Basic_Turret_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void Multicast_PlayEffects(); // Function BP_Basic_Turret.BP_Basic_Turret_C.Multicast_PlayEffects // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void DoUpdateStatusLight(); // Function BP_Basic_Turret.BP_Basic_Turret_C.DoUpdateStatusLight // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDoRebind(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnDoRebind // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnHighlightChanged(struct UHighlightableComponent* Highlightable, struct UPrimitiveComponent* Component, bool bHighlighted); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnHighlightChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void MultiPlayAddAmmoAudio(); // Function BP_Basic_Turret.BP_Basic_Turret_C.MultiPlayAddAmmoAudio // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStartRunning(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStopRunning(); // Function BP_Basic_Turret.BP_Basic_Turret_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Basic_Turret(int32_t EntryPoint); // Function BP_Basic_Turret.BP_Basic_Turret_C.ExecuteUbergraph_BP_Basic_Turret // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

