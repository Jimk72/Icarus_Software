// BlueprintGeneratedClass BP_Anvil_Bench.BP_Anvil_Bench_C
// Size: 0x9b8 (Inherited: 0x9b0)
struct ABP_Anvil_Bench_C : ABP_ProcessorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9b0(0x08)

	void ReceiveBeginPlay(); // Function BP_Anvil_Bench.BP_Anvil_Bench_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Anvil_Bench(int32_t EntryPoint); // Function BP_Anvil_Bench.BP_Anvil_Bench_C.ExecuteUbergraph_BP_Anvil_Bench // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

