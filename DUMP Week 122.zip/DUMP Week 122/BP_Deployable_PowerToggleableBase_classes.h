// BlueprintGeneratedClass BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C
// Size: 0x761 (Inherited: 0x751)
struct ABP_Deployable_PowerToggleableBase_C : ABP_DeployableBase_C {
	char pad_751[0x7]; // 0x751(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x758(0x08)
	bool bIsDeviceRunning; // 0x760(0x01)

	void OnRep_IsDeviceRunning(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnRep_IsDeviceRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IsDeviceRunning(bool& DeviceIsRunning); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.IsDeviceRunning // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1f9a5d0
	void CheckDeviceRunning(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.CheckDeviceRunning // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CalculateIsDeviceRunning(bool& IsRunning); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.CalculateIsDeviceRunning // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceOnStateChanged(bool bIsOn); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnDeviceOnStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceTurnedOn(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnDeviceTurnedOn // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceTurnedOff(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnDeviceTurnedOff // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnBrownOutStrengthChanged(enum class EIcarusResourceType ResourceType, int32_t NewBrownOutStrength); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnBrownOutStrengthChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnResourceNetworkUpdated(enum class EIcarusResourceType ResourceType, bool bConnected); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnResourceNetworkUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStartRunning(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStopRunning(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void IcarusBeginPlay(); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.IcarusBeginPlay // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Deployable_PowerToggleableBase(int32_t EntryPoint); // Function BP_Deployable_PowerToggleableBase.BP_Deployable_PowerToggleableBase_C.ExecuteUbergraph_BP_Deployable_PowerToggleableBase // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

