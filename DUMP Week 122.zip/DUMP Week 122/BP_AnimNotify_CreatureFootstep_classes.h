// BlueprintGeneratedClass BP_AnimNotify_CreatureFootstep.BP_AnimNotify_CreatureFootstep_C
// Size: 0x3a (Inherited: 0x38)
struct UBP_AnimNotify_CreatureFootstep_C : UAnimNotify {
	enum class ECreatureFootstepType Type; // 0x38(0x01)
	enum class ECreatureFootstepDirection Direction; // 0x39(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimNotify_CreatureFootstep.BP_AnimNotify_CreatureFootstep_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
	struct FString GetNotifyName(); // Function BP_AnimNotify_CreatureFootstep.BP_AnimNotify_CreatureFootstep_C.GetNotifyName // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
};

