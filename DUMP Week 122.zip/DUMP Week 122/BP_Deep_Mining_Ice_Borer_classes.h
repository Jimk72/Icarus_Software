// BlueprintGeneratedClass BP_Deep_Mining_Ice_Borer.BP_Deep_Mining_Ice_Borer_C
// Size: 0x7d8 (Inherited: 0x7c2)
struct ABP_Deep_Mining_Ice_Borer_C : ABP_Drill_Base_C {
	char pad_7C2[0x6]; // 0x7c2(0x06)
	struct UNiagaraComponent* NS_BiofuelBurn; // 0x7c8(0x08)
	struct UNiagaraComponent* NS_DeepDrilling; // 0x7d0(0x08)

	void ActiveStateUpdated(); // Function BP_Deep_Mining_Ice_Borer.BP_Deep_Mining_Ice_Borer_C.ActiveStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

