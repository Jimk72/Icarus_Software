// BlueprintGeneratedClass BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C
// Size: 0x368 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Hold_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct AIcarusPlayerCharacter* OwningPlayer; // 0x318(0x08)
	float HoldTimeStamp; // 0x320(0x04)
	char pad_324[0x4]; // 0x324(0x04)
	struct FMulticastInlineDelegate HoldCompleted; // 0x328(0x10)
	float HoldLength; // 0x338(0x04)
	bool AutoEnd; // 0x33c(0x01)
	bool NewVar_0_1; // 0x33d(0x01)
	char pad_33E[0x2]; // 0x33e(0x02)
	int32_t ModifierUID; // 0x340(0x04)
	struct FModifierStatesRowHandle HoldModifier; // 0x344(0x18)
	char pad_35C[0x4]; // 0x35c(0x04)
	struct AActor* HoldingOnActor; // 0x360(0x08)

	struct USkeletalMeshComponent* GetAnimatingMesh(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetAnimatingMesh // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetHoldLength(float& HeldTime); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetHoldLength // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void RemovePlayerModifier(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.RemovePlayerModifier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void AddPlayerModifier(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.AddPlayerModifier // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	float GetHoldProgress(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetHoldProgress // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	bool IsHoldFinished(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.IsHoldFinished // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void GetPlayer(struct AIcarusPlayerCharacter*& OwningPlayer); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetPlayer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void LocalOrServer(bool& Local, bool& Server); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.LocalOrServer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	bool IsHolding(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.IsHolding // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void EndHold(bool Success); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.EndHold // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void StartHold(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.StartHold // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetHeldData(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetHeldData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	float GetRemainingTime(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetRemainingTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	float GetHeldTime(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.GetHeldTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	bool CanHold(); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.CanHold // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void Server_StartHold(struct AActor* ActorStatedHoldOn); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.Server_StartHold // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Server_EndHold(bool Success, struct AActor* ActorEndedHoldOn); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.Server_EndHold // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CompleteHold(bool Success); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.CompleteHold // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void OnActionAborted(enum class EActionableEventType EventType); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.OnActionAborted // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformActionFromMenu(struct AActor* InvokingActor); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.PerformActionFromMenu // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Hold(int32_t EntryPoint); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.ExecuteUbergraph_BP_ActionableBehaviour_Hold // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
	void HoldCompleted__DelegateSignature(bool Success); // Function BP_ActionableBehaviour_Hold.BP_ActionableBehaviour_Hold_C.HoldCompleted__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

