// BlueprintGeneratedClass BP_DeerDesertLarge_Corpse.BP_DeerDesertLarge_Corpse_C
// Size: 0x780 (Inherited: 0x778)
struct ABP_DeerDesertLarge_Corpse_C : ABP_GOAP_Corpse_C {
	struct UGFurComponent* GFur; // 0x778(0x08)

	void OnSkinnedStateUpdated(); // Function BP_DeerDesertLarge_Corpse.BP_DeerDesertLarge_Corpse_C.OnSkinnedStateUpdated // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
};

