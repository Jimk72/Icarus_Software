// BlueprintGeneratedClass BP_AnimNotify_SwimStroke.BP_AnimNotify_SwimStroke_C
// Size: 0x38 (Inherited: 0x38)
struct UBP_AnimNotify_SwimStroke_C : UAnimNotify {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function BP_AnimNotify_SwimStroke.BP_AnimNotify_SwimStroke_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1f9a5d0
};

