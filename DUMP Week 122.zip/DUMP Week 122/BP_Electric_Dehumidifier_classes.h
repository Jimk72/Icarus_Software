// BlueprintGeneratedClass BP_Electric_Dehumidifier.BP_Electric_Dehumidifier_C
// Size: 0x798 (Inherited: 0x761)
struct ABP_Electric_Dehumidifier_C : ABP_Deployable_PowerToggleableBase_C {
	char pad_761[0x7]; // 0x761(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UNiagaraComponent* Niagara2; // 0x770(0x08)
	struct UNiagaraComponent* Niagara1; // 0x778(0x08)
	struct USceneComponent* Scene_Niagara; // 0x780(0x08)
	struct UFMODAudioComponent* FMOD_Active_Audio; // 0x788(0x08)
	struct UInventory* GeneralInventory; // 0x790(0x08)

	void UpdateEffects(bool ReceivingPower); // Function BP_Electric_Dehumidifier.BP_Electric_Dehumidifier_C.UpdateEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStartRunning(); // Function BP_Electric_Dehumidifier.BP_Electric_Dehumidifier_C.OnDeviceStartRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void OnDeviceStopRunning(); // Function BP_Electric_Dehumidifier.BP_Electric_Dehumidifier_C.OnDeviceStopRunning // (BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_Electric_Dehumidifier(int32_t EntryPoint); // Function BP_Electric_Dehumidifier.BP_Electric_Dehumidifier_C.ExecuteUbergraph_BP_Electric_Dehumidifier // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

