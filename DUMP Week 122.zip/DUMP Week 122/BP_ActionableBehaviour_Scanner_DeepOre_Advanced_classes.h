// BlueprintGeneratedClass BP_ActionableBehaviour_Scanner_DeepOre_Advanced.BP_ActionableBehaviour_Scanner_DeepOre_Advanced_C
// Size: 0x3e0 (Inherited: 0x3ac)
struct UBP_ActionableBehaviour_Scanner_DeepOre_Advanced_C : UBP_ActionableBehaviour_Scanner_DeepOre_C {
	char pad_3AC[0x4]; // 0x3ac(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b0(0x08)
	struct FOreDepositRowHandle SelectedOreType; // 0x3b8(0x18)
	struct TArray<struct FOreDepositRowHandle> OreTypes; // 0x3d0(0x10)

	struct TArray<struct AActor*> ExtraNearbyFilter(struct TArray<struct AActor*>& InNearbyActors); // Function BP_ActionableBehaviour_Scanner_DeepOre_Advanced.BP_ActionableBehaviour_Scanner_DeepOre_Advanced_C.ExtraNearbyFilter // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void CycleOreType(bool Forward); // Function BP_ActionableBehaviour_Scanner_DeepOre_Advanced.BP_ActionableBehaviour_Scanner_DeepOre_Advanced_C.CycleOreType // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Scanner_DeepOre_Advanced.BP_ActionableBehaviour_Scanner_DeepOre_Advanced_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Scanner_DeepOre_Advanced.BP_ActionableBehaviour_Scanner_DeepOre_Advanced_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Scanner_DeepOre_Advanced(int32_t EntryPoint); // Function BP_ActionableBehaviour_Scanner_DeepOre_Advanced.BP_ActionableBehaviour_Scanner_DeepOre_Advanced_C.ExecuteUbergraph_BP_ActionableBehaviour_Scanner_DeepOre_Advanced // (Final|UbergraphFunction|HasDefaults) // @ game+0x1f9a5d0
};

