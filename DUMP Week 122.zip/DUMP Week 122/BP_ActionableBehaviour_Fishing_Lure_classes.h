// BlueprintGeneratedClass BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C
// Size: 0x658 (Inherited: 0x30a)
struct UBP_ActionableBehaviour_Fishing_Lure_C : UBP_ActionableBehaviour_Base_C {
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct ABP_IcarusPlayerCharacterSurvival_C* OwningPlayer; // 0x318(0x08)
	struct AContextMenuFactory* Context Menu; // 0x320(0x08)
	struct AIcarusActor* Owning Actor; // 0x328(0x08)
	struct UContextMenuWidget* CurrentContextMenu; // 0x330(0x08)
	bool RadialOpen; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)
	struct TArray<struct FFindAllStacksResult> All Lure Types; // 0x340(0x10)
	struct TArray<struct FItemsStaticRowHandle> Lure Types; // 0x350(0x10)
	struct FName Backpack Inventory Action Id; // 0x360(0x08)
	struct FName Quickbar Inventory Action Id; // 0x368(0x08)
	struct UInventory* Inventory; // 0x370(0x08)
	struct FItemableData Itemable; // 0x378(0xe8)
	struct AIcarusItem* As Icarus Item; // 0x460(0x08)
	struct FItemData ItemData; // 0x468(0x1f0)

	void RemoveLure(); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.RemoveLure // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void QuickReel(); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.QuickReel // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void SetLure(struct UInventory* Inventory, int32_t Slot); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.SetLure // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void GetLure(struct FItemData& LureItem); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.GetLure // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	struct UInventory* GetInventoryFromName(struct FName Inventory Name); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.GetInventoryFromName // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ContextMenu_SetLure(struct FName ItemIdentifier, int32_t ItemPayload); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ContextMenu_SetLure // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	struct FName Get Name for Inventory(struct UInventory* Inventory); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.Get Name for Inventory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1f9a5d0
	void ContextMenu_RemoveLure(struct FName ItemIdentifier, int32_t ItemPayload); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ContextMenu_RemoveLure // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ContextMenu_OpenForLure(bool AsRadial, bool& Opened); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ContextMenu_OpenForLure // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void LocalOrServer(bool& Local, bool& Server); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.LocalOrServer // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void Setup(struct AActor* OwningActor); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveTick(float DeltaSeconds); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void PerformAction(struct AActor* InvokingActor, enum class EActionableEventType OnActionType, enum class EActionableTrigger ActionTrigger); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.PerformAction // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveBeginPlay(); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x1f9a5d0
	void Server_RequestSetLure(struct UInventory* Inventory, int32_t Slot); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.Server_RequestSetLure // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x1f9a5d0
	void ExecuteUbergraph_BP_ActionableBehaviour_Fishing_Lure(int32_t EntryPoint); // Function BP_ActionableBehaviour_Fishing_Lure.BP_ActionableBehaviour_Fishing_Lure_C.ExecuteUbergraph_BP_ActionableBehaviour_Fishing_Lure // (Final|UbergraphFunction) // @ game+0x1f9a5d0
};

