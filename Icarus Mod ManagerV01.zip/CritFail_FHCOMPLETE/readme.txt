CRAFTING: (included with FHComplete and FHCraft)

Lantern and Biofuel Lamp - now require fuel to craft, but come fully filled with fuel (50% of a full tank to craft, but 100% full result)
High-use item recipes changed to craft in x5 quantities (arrows, epoxy, concrete, etc.)
All meats given a bulk recipe of x5 added to Potbelly Stove and Kitchen Stove
Sticks from Wood recipe added to Mortar and Material Processor
Electronics recipe changed to x5, and a x10 recipe added at a 10% discount
Fuel can cost reduced from 25 ingots to 10
Recipe cost reductions for various T4 crafting stations and items (mostly less Electronics)
New recipes for Composite Paste to use Ingots instead of ore (in case you already smelted it all)
New recipes using Fur! Now you can use your extra Fur to craft: fiber, rope, fertilizer and organic resin!
New Biofuel recipe using Exotic Ore! Completely fill a 20L biofuel can in only 8 ticks with Exotic Ore and Oxygen Buff Paste
Adjusted some of the Pastes at the Herbalism Bench to no longer require Sponges and instead use more Oxite
Larkwell Arrows - can be crafted in-game in x25 stacks using Exotics and some other craftable materials
ITEM REWARDS: (included with FHComplete and FHCrops&Carcasses)

Grown crop yields increased
Meat drop chance increased from 10% to 50%
NEW! - some animals have a rare chance to drop items beyond their typical resources!
FOOD BUFFS: (included in FHComplete and FHFoodBuffs)

Buffs that were 600sec are now 900sec
Buffs that were 900sec are now 1200sec
Drinkables are improved (tea, coffee, etc.)
Workshop buff items are improved (gel, ration, etc.)
ITEM STACK SIZES: (included in FHComplete and FHStacks)

Stacks to 500 - Fiber, Sticks, Charcoal, Tree Sap, Rope, Epoxy, Gunpowder, Flour, Wheat, Crushed Bone
Stacks to 200 - Stone, Wood, Leather, Fur, Concrete Mix, Nails/Screws/Rebar, all ammunition
Stacks to 100 - Ore, Ingots, Crops, Meat, Food
POWER NETWORK & FUEL: (included in FHComplete and FHStacks)

Biofuel Generator and Solar Panel both support a power network of 20,000 (up from 5,000)
Fuel Can capacity increased to 20L (was 10)
NEW Early Game Biofuel production - Wood Composter has sticks/tree sap recipe to generate biofuel (though at a slow rate compared to T3 composter)
Biofuel Lantern capacity increased to 2.5L (was 1)
Biofuel Lamp capacity increased to 5L (was 2)
> The following improvements are ONLY included in FHComplete

DEEP VEIN DRILL SPEED INCREASED

DROPSHIP LOADOUT INCREASED TO 34 SLOTS

HORDE MODE:

Exotic rewards for each wave increased, up to a maximum potential payout of 450 Exotics for completing all 3 waves
Timers between waves decreased - hold onto your butts!
WORKSHOP ITEMS:

O2 tank and canteen come pre-filled
Workshop Biofuel can has 30L of fuel
Workshop tools now match or exceed the health of their crafted equivalents
Larkwell items buffed to 75k health
WEAPONS AND DAMAGE

Firearms and Bows do more damage now
Arrows fly much faster - similar to what you would expect from a compound bow in real life
Combine with Larkwell backpack for even more damage (plus 100% ammo capacity on rifles!)